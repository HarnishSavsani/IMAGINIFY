import requests
from requests.auth import HTTPBasicAuth
import time
import urllib3
import uuid
import asyncio


# Disable warnings for self-signed certificates
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


def trigger_process(job_id,processName, processConfigset,username,password,url):
    

    payload = {"jobId": job_id,
               "processName":processName,
               "processDomain":processConfigset,
               "processConfigSet":processConfigset}
    headers = {
        'accept': 'application/json;charset=utf-8',
        'Content-Type': 'application/json;charset=utf-8',
        'X-CSRF': 'null'
    }

    with requests.Session() as session:
        session.auth = (username,password)
        response = session.post(url, json=payload, headers=headers, verify=False)
        response.raise_for_status()
                
        data = response.json()

        print("Response status code",response.status_code)
        print("Response data",data)
        return response.status_code




async def monitor_job_progress(job_id, url, username, password, interval=4):
    payload = {"jobId": job_id}
    headers = {
        'accept': 'application/json;charset=utf-8',
        'Content-Type': 'application/json;charset=utf-8',
        'X-CSRF': 'null'
    }
    

    # Use a Session for connection persistence
    with requests.Session() as session:
        # Attach the credentials to the session so every request is authenticated
        session.auth = (username, password)
        
        print(f"Monitoring Job: {job_id}...")
        
        while True:
            try:
                # verify=False is often needed for internal :8443 endpoints with self-signed certs
                await asyncio.sleep(interval)  # Wait before making the next request
                response = session.post(url, json=payload, headers=headers, verify=False)
                response.raise_for_status()
                
                data = response.json()
                jobs = data.get("jobProgressList", [])
                print("jobs",jobs)
                target_job = next((j for j in jobs if j["jobId"] == job_id), None)

                print(f"Target Job: {target_job}")

                if target_job:
                    succeeded = target_job["numberSucceededTasks"]
                    total = target_job["initialTaskCount"]
                    status = target_job["jobStatus"]
                    failed = target_job["numberFailedTasks"]
                    
                    # Simple calculation: (Completed Tasks / Total Tasks) * 100
                    progress = ((succeeded + failed)/ total * 100) if total > 0 else 0

                    
                    
                    print(f"Status: {status} | Progress: {progress:.1f}% ({succeeded}/{total})")


                    # If status is no longer 3 (Running), exit the loop
                    if status != 3:
                        print("Job Finished.")
                        return{
                            "status": "COMPLETED",
                            "progress": "100.0",
                            "total": total,
                            "succeeded": succeeded,
                            "failed": failed
                        }
                    return {
                        "status": "RUNNING",
                        "progress": f"{progress:.1f}",
                        "total": total,
                        "succeeded": succeeded,
                        "failed": failed
                    }

                    
                else:
                    print("Job ID not found in list.")
                    return {
                        "status":"NOT_FOUND",
                        "progress":0
                    }

            except requests.exceptions.HTTPError as err:
                if err.response.status_code == 401:
                    print("Auth Error: Invalid username or password.")
                    break
                print(f"HTTP Error: {err}")
            except Exception as e:
                print(f"Monitor Job Error: {e}")
            
            await asyncio.sleep(interval)



def validate_job_process(processName, processConfigset,username,password,url):
    payload = {"jobId": "string"}
    headers = {
        'accept': 'application/json;charset=utf-8',
        'Content-Type': 'application/json;charset=utf-8',
        'X-CSRF': 'null'
    }


    with requests.Session() as session:
        session.auth = (username,password)
        response = session.post(url, json=payload, headers=headers, verify=False)
        response.raise_for_status()
                
        data = response.json()
        print("response data size",len(data['jobProgressList']))
        print("response data",data)

        noOfProcess = len(data['jobProgressList'])
        if noOfProcess > 4:
            print("process are running more than 4 and the exchange can't be triggered")
            return{
                "status_code": 403,
                "msg": "Currently there are more than 4 process are running and the exchange can't be triggered now"
            }

        
        # Iterate through the list of jobs
        for task in data['jobProgressList']:
            # Condition: Check if BOTH keys exist in the current job dictionary
            if task.get('projectName') == processConfigset and task.get('processName') == processName:
                print(f"Job {task['jobId']} passes! Project: {task['projectName']}, Process: {task['processName']}")
                return{
                    "status_code":403,
                    "msg":"Already the same process is been running currently and the exchange can't be triggered now"
                }
            
        print(f"job can be triggered")
        return {
            "status_code":200,
            "msg":"The exchange can be triggered now"
        }

