
from uuid import uuid4
from app.exchange_trigger.process_service import ProcessService
from app.exchange_trigger.connection_manager import ConnectionManager

manager = ConnectionManager()
process_service = ProcessService(
    manager
)



origins = [
    "http://localhost:8080",
    "http://127.0.0.1:8080",
    "http://localhost:8001", 
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # Change to `origins` if you want to restrict it later
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)



# main.py
@app.get("/trigger-options")
def get_trigger_options():
    # Replace these lists with your actual database query results
    processes_list = trigger_service.get_process_list()
    # print("Processes for trigger options:", processes_list)  # Debugging log

    oems = processes_list.get("oems", [])
    projects = processes_list.get("projects", [])
    processes = processes_list.get("processes", [])
    
    

    return {
       "oems": oems,
       "projects": projects,
       "processes": processes
    }

@app.post("/trigger")
def trigger_exchange(
    oemId: str = Body(...),
    projectId: str = Body(...),
    process: dict = Body(...),
    defectIds: Optional[Union[str,list]] = Body(None)
):
    # Debugging logs
    print(f"Received trigger request for oemId: {oemId}, projectId: {projectId}, process: {process}")
    print(f"Defect IDs received: {defectIds}")
    processName = process.get("name") if isinstance(process, dict) else str(process)
    return trigger_service.trigger(oemId, projectId, process, defectIds)



@app.post("/process/start")
async def start_process(
        request: ProcessRequest):

    job_id = str(uuid4())

    validate_response = process_service.validate_process(
        request.oemId,
        request.projectId,
        request.process,
        request.defectIds
    )

    print("Validate Response: ",validate_response)
    if validate_response['status_code'] != 200:
        return validate_response

    await process_service.start_process(
        job_id,
        request.oemId,
        request.projectId,
        request.process,
        request.defectIds
    )

    return {
        "job_id": job_id
    }

@app.websocket("/ws/{job_id}")
async def websocket_endpoint(
        websocket: WebSocket,
        job_id: str):

    await manager.connect(
        job_id,
        websocket
    )

    try:

        while True:
            await websocket.receive_text()

    except WebSocketDisconnect:

        manager.disconnect(
            job_id,
            websocket
        )