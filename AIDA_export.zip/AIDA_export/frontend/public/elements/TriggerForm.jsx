import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";

export default function TriggerForm() {
    
    // Extract full arrays from props (Restored exactly to your original working state)
    const allOems = props?.oems || [];
    const allProjects = props?.projects || [];
    const allProcesses = props?.processes || [];

    // State for the form (Swapped processName string for process object)
    const [values, setValues] = useState({
        oemId: '',
        projectId: '',
        process: null, // Holds the full selected process object instead of just a name string
        defectIds: '' 
    });

    const handleChange = (id, val) => {
        setValues(v => ({ ...v, [id]: val }));
    };

    // --- CASCADING LOGIC ---
    const handleOemChange = (newOemId) => {
        const filteredProjs = allProjects.filter(p => p.oem_id.toString() === newOemId.toString());
        const firstProjId = filteredProjs.length > 0 ? filteredProjs[0].id.toString() : '';

        const filteredProcs = allProcesses.filter(p => p.project_id.toString() === firstProjId);
        const firstProcObj = filteredProcs.length > 0 ? filteredProcs[0] : null;

        setValues(v => ({
            ...v,
            oemId: newOemId,
            projectId: firstProjId,
            process: firstProcObj
        }));
    };

    const handleProjectChange = (newProjectId) => {
        const filteredProcs = allProcesses.filter(p => p.project_id.toString() === newProjectId.toString());
        const firstProcObj = filteredProcs.length > 0 ? filteredProcs[0] : null;

        setValues(v => ({
            ...v,
            projectId: newProjectId,
            process: firstProcObj
        }));
    };

    // Initialize defaults on first load
    useEffect(() => {
        if (allOems.length > 0 && !values.oemId) {
            handleOemChange(allOems[0].id.toString());
        }
    }, [allOems]);

    // --- DERIVED STATE FOR RENDERING DROPDOWNS ---
    const availableProjects = allProjects.filter(p => p.oem_id.toString() === values.oemId?.toString());
    const availableProcesses = allProcesses.filter(p => p.project_id.toString() === values.projectId?.toString());

    // Shared Tailwind styles for form elements
    const selectClassName = "flex h-10 w-full items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50";
    const textareaClassName = "flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50";

    return (
        <Card className="w-full max-w-md mt-4">
            <CardHeader>
                <CardTitle>Trigger Process</CardTitle>
                <CardDescription>Select the hierarchy and provide defect IDs to sync.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
                
                {/* 1. OEM DROPDOWN */}
                <div className="space-y-2">
                    <Label htmlFor="oemId">OEM</Label>
                    <select 
                        id="oemId" 
                        className={selectClassName}
                        value={values.oemId}
                        onChange={(e) => handleOemChange(e.target.value)}
                    >
                        {allOems.map((oem) => (
                            <option key={oem.id} value={oem.id}>{oem.name}</option>
                        ))}
                    </select>
                </div>

                {/* 2. PROJECT DROPDOWN */}
                <div className="space-y-2">
                    <Label htmlFor="projectId">Project</Label>
                    <select 
                        id="projectId" 
                        className={selectClassName}
                        value={values.projectId}
                        onChange={(e) => handleProjectChange(e.target.value)}
                        disabled={availableProjects.length === 0}
                    >
                        {availableProjects.length === 0 && <option value="">No projects available</option>}
                        {availableProjects.map((proj) => (
                            <option key={proj.id} value={proj.id}>{proj.project_name}</option>
                        ))}
                    </select>
                </div>

                {/* 3. PROCESS DROPDOWN */}
                <div className="space-y-2">
                    <Label htmlFor="processSelect">Process Name</Label>
                    <select 
                        id="processSelect" 
                        className={selectClassName}
                        // Bind select to the unique ID of the process object
                        value={values.process?.id || ''} 
                        onChange={(e) => {
                            // Find the full object inside availableProcesses matching the chosen ID string
                            const selectedProcessObj = availableProcesses.find(proc => proc.id.toString() === e.target.value.toString());
                            handleChange('process', selectedProcessObj || null);
                        }}
                        disabled={availableProcesses.length === 0}
                    >
                        {availableProcesses.length === 0 && <option value="">No processes available</option>}
                        {availableProcesses.map((proc) => (
                            <option key={proc.id} value={proc.id}>{proc.process_name}</option>
                        ))}
                    </select>
                </div>

                {/* 4. DEFECT IDS (TEXTAREA) */}
                <div className="space-y-2">
                    <Label htmlFor="defectIds">Defect IDs (Comma separated)</Label>
                    <textarea 
                        id="defectIds" 
                        className={textareaClassName}
                        placeholder="e.g. DEF-123, DEF-456"
                        value={values.defectIds}
                        onChange={(e) => handleChange('defectIds', e.target.value)}
                    />
                </div>
                
            </CardContent>
            <CardFooter className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => cancelElement()}>Cancel</Button>
                <Button onClick={() => submitElement({ submitted: true, data: values })}>Submit</Button>
            </CardFooter>
        </Card>
    );
}