


BACKEND_URL = "http://localhost:8001"  # adjust if needed
WS_URL = "ws://localhost:8001"





@cl.action_callback("trigger_process_form")
async def handle_trigger_form(action: cl.Action):
    
    # 1. Fetch dynamic options from the FastAPI backend
    async with httpx.AsyncClient(timeout=10.0) as client:
        try:
            opt_response = await client.get(f"{BACKEND_URL}/trigger-options")
            opt_response.raise_for_status()
            form_options = opt_response.json()
        except Exception as e:
            await cl.Message(content=f"❌ **Failed to load form options:** {str(e)}").send()
            return

    # 2. Define the custom element
    element = cl.CustomElement(
        name="TriggerForm", 
        display="inline",
        props=form_options
    )
    
    # 3. Pop the form into the chat UI
    res = await cl.AskElementMessage(
        content="Please fill the form:",
        element=element,
        timeout=120 
    ).send()
    # Note: Use `.send()` if you aren't awaiting the message creation directly, 
    # but AskElementMessage returns the response when awaited.

    # 4. Handle the submission and STREAM the logs
    if res and res.get("submitted"):
        payload = res.get("data")
        print(f"Submitting payload to backend: {payload}")  # Debugging log

        # Initialize an empty message that we will dynamically type text into
        stream_msg = cl.Message(content="")
        await stream_msg.send()

        # Now, stream the logs from the backend
        response = requests.post(
        f"{BACKEND_URL}/process/start",
        json=payload )

        print(f"Backend response: {response.text}")  # Debugging log

        if response.status_code != 200:
            await cl.Message(
                content=f"Backend Error:\n{response.text}"
            ).send()
            return

        
        # 2. Safely parse the JSON response body
        try:
            response_data = response.json()
        except ValueError:
            await cl.Message(
                content=f"Backend returned invalid JSON response:\n{response.text}"
            ).send()
            return

        
        # 3. Check for your custom 403 status code inside the JSON payload
        # Note: Your backend returns 403 as an integer, not a string ('403')
        if response_data.get('status_code') == 403:
            await cl.Message(
                content=f"\n{response_data.get('msg')}"
            ).send()
            return

        job_id = response_data.get("job_id")

        await cl.Message(
            content=f"Started Job: {job_id}"
        ).send()

        asyncio.create_task(listen(job_id))


            
    else:
        await cl.Message(content="❌ Form cancelled or timed out.").send()



async def listen(job_id):
    message = cl.Message(content="Waiting for job status...")
    await message.send()

    try:
        async with websockets.connect(f"{WS_URL}/ws/{job_id}") as ws:
            async for payload in ws:
                data = json.loads(payload)
                
                message.content = f"""
Job : {job_id}
Status : {data['status']}
Progress : {data['progress']}%
Total : {data['total']}
Succeeded : {data['succeeded']}
Failed : {data['failed']}
Config Set : {data['configset']}
Process : {data['process']}
"""
                await message.update()

                if data["status"] == "COMPLETED":
                    await cl.Message(content="🎉 Finished").send()
                    break
    except Exception as e:
        message.content = f"❌ **WebSocket Connection Error:** {str(e)}"
        await message.update()
