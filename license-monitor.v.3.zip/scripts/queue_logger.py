import asyncio
import json
from datetime import datetime, timedelta, timezone
from pathlib import Path

from loguru import logger

# 1. Create separate, dedicated queues (our "Message Broker" topics)
log_queues = {
    "lmutil": asyncio.Queue(maxsize=15000),
    "rlmutil": asyncio.Queue(maxsize=5000),
    "http": asyncio.Queue(maxsize=5000),
    "catia": asyncio.Queue(maxsize=5000),
}


async def log_cleanup_worker(base_dir: Path, retention_days: int = 30):
    """
    Dedicated background janitor.
    Wakes up once every 24 hours to delete logs older than retention_days.
    """
    logger.info(f"Started log cleanup worker (Retention: {retention_days} days)")

    while True:
        try:
            cutoff_date = datetime.now(timezone.utc) - timedelta(days=retention_days)
            log_dir = base_dir / "logs"

            if log_dir.exists():
                for log_file in log_dir.rglob("*.jsonl"):
                    try:
                        # This ignores OS modification time which can be skewed by backups
                        date_str = log_file.stem.split("-")[-3:]
                        file_date = datetime.strptime(
                            "-".join(date_str), "%Y-%m-%d"
                        ).replace(tzinfo=timezone.utc)

                        if file_date < cutoff_date:
                            log_file.unlink()
                            logger.info(
                                f"Deleted old log file based on filename: {log_file.name}"
                            )
                    except ValueError:
                        pass  # Ignore files that don't match our strict naming convention

        except Exception as e:
            logger.error(f"Log cleanup task encountered an error: {e}")

        # Go to sleep for 24 hours (86,400 seconds) before checking again
        await asyncio.sleep(86400)


async def file_writer_worker(tool: str, base_dir: Path):
    """
    Dedicated background consumer.
    Because ONLY this single function ever touches this tool's file,
    we completely eliminate 'file in use' and resource locking errors.
    """
    logger.info(f"Started dedicated queue writer for: {tool}")

    while True:
        # Wait for a message to arrive in the queue
        entry = await log_queues[tool].get()

        try:
            # Determine file path (rolls over dynamically at midnight)
            date_str = datetime.now(timezone.utc).strftime("%Y-%m-%d")
            log_dir = base_dir / "logs" / tool
            log_dir.mkdir(parents=True, exist_ok=True)
            log_file = log_dir / f"{tool}-{date_str}.jsonl"

            # Write the single line instantly.
            # We don't need threads here because this worker has an exclusive lock on the logic.
            with log_file.open("a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")

        except Exception as e:
            logger.error(f"Queue write failed for {tool}: {e}")
        finally:
            # Tell the queue the message was successfully processed
            log_queues[tool].task_done()
