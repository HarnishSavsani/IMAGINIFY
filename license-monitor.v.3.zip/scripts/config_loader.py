import sys
from pathlib import Path

import yaml
from loguru import logger


def load_config(base_dir: Path) -> dict:
    config_path = base_dir / "license-monitor-config.yaml"

    if not config_path.is_file():
        logger.error(f"Config not found: {config_path}")
        sys.exit(1)

    with config_path.open(encoding="utf-8") as f:
        try:
            config = yaml.safe_load(f)
        except yaml.YAMLError as e:
            logger.error(f"YAML parsing error: {e}")
            sys.exit(1)

    # Apply defaults if missing
    if "global" not in config:
        config["global"] = {}

    config["global"].setdefault("command_timeout_seconds", 20)
    config["global"].setdefault("max_parallel_queries", 50)

    lm_groups = config.get("lm_family", []) or config.get("util_family", [])
    config["lm_family"] = lm_groups

    config["http_sources"] = config.get("http_sources", [])

    return config
