import os

import redis.asyncio as redis
from loguru import logger

REDIS_PASSWORD = os.environ.get("REDIS_PASSWORD", None)

# Initialize a global connection pool
if REDIS_PASSWORD:
    pool = redis.ConnectionPool(
        host="localhost",
        port=6379,
        password=REDIS_PASSWORD,
        decode_responses=True,
        max_connections=100,  # Cap connections to prevent overwhelming Redis
    )
    logger.info("Redis connection pool initialized WITH authentication.")
else:
    pool = redis.ConnectionPool(
        host="localhost", port=6379, decode_responses=True, max_connections=100
    )
    logger.warning(
        "Redis connection pool initialized WITHOUT authentication (Not recommended for Prod)."
    )

# The singleton client that all modules will share
shared_redis_client = redis.Redis(connection_pool=pool)
