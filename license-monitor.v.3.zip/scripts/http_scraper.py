import asyncio
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional

import httpx
from bs4 import BeautifulSoup
from loguru import logger
from queue_logger import log_queues
from redis_pool import shared_redis_client


async def fetch_tasking_data(url: str, timeout: int) -> str:
    headers = {"User-Agent": "Mozilla/5.0 ELMS-Agent"}
    async with httpx.AsyncClient() as client:
        response = await client.get(url, headers=headers, timeout=timeout)
        response.raise_for_status()
        return response.text


def parse_tasking_html(html: str) -> List[Dict]:
    soup = BeautifulSoup(html, "html.parser")
    features_dict = {}

    tables = soup.find_all("table")
    if not tables:
        return []

    table_1_totals = None
    table_2_users = None

    # 2. Identify tables dynamically by their headers
    for table in tables:
        rows = table.find_all("tr")
        if not rows:
            continue

        headers = [cell.text.strip().lower() for cell in rows[0].find_all(["th", "td"])]

        # Identify Table 1: Totals
        if any("license" in h or "key" in h for h in headers) and any(
            "seat" in h or "total" in h for h in headers
        ):
            table_1_totals = (rows, headers)
        # Identify Table 2: Live Users
        elif (
            any("user" in h for h in headers)
            and any("system" in h for h in headers)
            and any("in use since" in h for h in headers)
        ):
            table_2_users = (rows, headers)

    # 3. Parse Table 1: Extract License Totals
    if table_1_totals:
        rows, headers = table_1_totals
        for row in rows[1:]:
            cols = [td.text.strip() for td in row.find_all("td")]
            if len(cols) == len(headers):
                row_data = dict(zip(headers, cols))

                license_key = next(
                    (v for k, v in row_data.items() if "license" in k or "key" in k), ""
                ).strip()
                if not license_key:
                    continue

                valid_from = next(
                    (v for k, v in row_data.items() if "valid" in k or "from" in k), "—"
                )
                expiry = next((v for k, v in row_data.items() if "expir" in k), "—")
                seats = next(
                    (v for k, v in row_data.items() if "seat" in k or "total" in k), "0"
                )
                in_use = next((v for k, v in row_data.items() if "use" in k), "0")

                try:
                    seats = int(seats)
                    in_use = int(in_use)
                except ValueError:
                    pass

                features_dict[license_key] = {
                    "feature": license_key,
                    "valid_from": valid_from,
                    "expiry": expiry,
                    "total_issued": seats,
                    "in_use": in_use,
                    "active_users": [],
                }

    # 4. Parse Table 2: Extract Live Users (if it exists)
    if table_2_users:
        rows, headers = table_2_users
        current_license_key = None

        for row in rows[1:]:
            cols = [td.text.strip() for td in row.find_all("td")]

            if len(cols) == len(headers):
                row_data = dict(zip(headers, cols))

                # Extract row license key
                row_lic_key = next(
                    (v for k, v in row_data.items() if "license key" in k), ""
                ).strip()

                # INHERIT KEY: If the current row's key is blank (e.g., secondary user), use the last seen key
                if row_lic_key:
                    current_license_key = row_lic_key

                if not current_license_key or current_license_key not in features_dict:
                    continue

                user = next((v for k, v in row_data.items() if "user" == k), "—")
                system = next((v for k, v in row_data.items() if "system" == k), "—")
                in_use_since = next(
                    (v for k, v in row_data.items() if "in use since" == k), "—"
                )

                features_dict[current_license_key]["active_users"].append(
                    {
                        "username": user,
                        "hostname": system,
                        "checkout_time": in_use_since,
                        "licenses_used": 1,
                    }
                )

    return list(features_dict.values())


# 5. Convert to an ASYNC function so we can push to Redis
async def save_http_log(
    base_dir: Path, source: dict, features: list, status: str, error_msg: str = None
):
    ts_str = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    group_name = source.get("name", "Unknown")
    region = source.get("region", "—")

    if status == "ok" and features:
        for feat in features:
            feature_name = feat.get("feature")
            users_list = feat.pop("active_users", [])

            # Graylog Entry
            entry = {
                "ts": ts_str,
                "group": group_name,
                "tool": "http",
                "url": source.get("url", "—"),
                "region": region,
                "feature": feature_name,
                "total_issued": feat.get("total_issued"),
                "in_use": feat.get("in_use"),
                "status": "ok",
            }
            log_queues["http"].put_nowait(entry)

            # Redis Payload
            cleaned_users = [
                {
                    "Username": u.get("username", "—"),
                    "Hostname": u.get("hostname", "—"),
                    "Timestamp": u.get("checkout_time", "—"),
                }
                for u in users_list
            ]

            redis_key = f"license:live:{group_name}:{feature_name}"
            redis_payload = {
                "Name": group_name,
                "Region": region,
                "Feature": feature_name,
                "Total Issued": feat.get("total_issued", 0),
                "In Use": feat.get("in_use", 0),
                "Last Updated": ts_str,
                "users": cleaned_users,
            }

            try:
                await shared_redis_client.setex(
                    redis_key, 120, json.dumps(redis_payload)
                )
            except Exception as e:
                logger.error(f"Failed to push HTTP {redis_key} to Redis: {e}")

    else:
        target_url = source.get("url", "—")
        if status == "error":
            logger.error(
                f"[TOOL: http] | [GROUP: {group_name}] | [URL: {target_url}] -> FAILED: {error_msg}"
            )


async def process_http_server(source: dict, base_dir: Path, timeout: int):
    try:
        html = await fetch_tasking_data(source["url"], timeout)
        features = await asyncio.to_thread(
            parse_tasking_html, html
        )  # BS4 is CPU-bound, keeping in thread is good!

        if not features:
            await save_http_log(
                base_dir, source, [], "error", "No license table found on page"
            )
        else:
            await save_http_log(base_dir, source, features, "ok")

    except Exception as e:
        await save_http_log(base_dir, source, [], "error", str(e))
