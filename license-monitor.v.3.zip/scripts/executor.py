# executor.py
import asyncio
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from license_parser import parse_lm_output
from loguru import logger
from queue_logger import log_queues
from redis_pool import shared_redis_client


class DSManager:
    def __init__(self):
        self.process = None

    async def _read_until_prompt(self):
        output = ""
        try:
            while True:
                line = await asyncio.wait_for(self.process.stdout.readline(), timeout=5)
                if not line:
                    break
                decoded = line.decode(errors="replace")
                output += decoded
                if "admin >" in decoded:
                    break
        except asyncio.TimeoutError:
            pass
        return output

    async def get_session(self, exe_path, host, port):
        if self.process and self.process.returncode is None:
            return self.process

        password = os.environ.get("CATIA_ADMIN_PASSWORD", "")
        if not password:
            logger.error("CATIA_ADMIN_PASSWORD environment variable is missing!")
            raise ValueError("Missing Catia credentials")

        self.process = await asyncio.create_subprocess_exec(
            exe_path,
            "-admin",
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        self.process.stdin.write(f"connect {host} {port}\n".encode())
        await self.process.stdin.drain()
        await asyncio.sleep(1)

        self.process.stdin.write(f"{password}\n".encode())
        await self.process.stdin.drain()
        await self._read_until_prompt()
        return self.process

    async def fetch_usage(self, exe_path, host, port, timeout):
        try:
            proc = await self.get_session(exe_path, host, port)

            # Zombie process probe. If broken pipe, force reconnect.
            proc.stdin.write(b"getLicenseUsage -all\n")
            await proc.stdin.drain()

            output = await self._read_until_prompt()
            return output, None
        except (BrokenPipeError, ConnectionResetError) as e:
            logger.warning(
                f"Catia session died (Zombie process detected). Forcing reconnect: {e}"
            )
            self.process = None
            return None, "Catia session died. Reconnecting..."
        except Exception as e:
            self.process = None
            return None, str(e)


# Global instance
ds_session_manager = DSManager()


def safe_queue_put(queue_name: str, entry: dict):
    try:
        log_queues[queue_name].put_nowait(entry)
    except asyncio.QueueFull:
        logger.warning(
            f"[QUEUE FULL] '{queue_name}' queue is at capacity. "
            f"Dropping entry for group '{entry.get('group', '?')}'. "
            f"Check if disk writes are stalling."
        )


async def save_log(
    base_dir: Path,
    tool: str,
    group_name: str,
    server: dict,
    features: list,
    status: str = "ok",
    error_msg: str = None,
):
    ts_str = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    queue_name = (
        "catia" if tool == "dslicsrv" else ("lmutil" if tool == "lmutilnew" else tool)
    )

    if status == "ok" and features:
        for feat in features:
            users_list = feat.pop("active_users", [])

            # Graylog Entry
            entry = {
                "ts": ts_str,
                "group": group_name,
                "tool": tool,
                "hostname": server.get("hostname", "Unknown"),
                "region": server.get("region", "—"),
                "port": server.get("port", "—"),
                "feature": feat["feature"],
                "total_issued": feat["total_issued"],
                "in_use": feat["in_use"],
                "status": "ok",
            }
            if "region_distribution" in feat:
                entry["region_distribution"] = feat["region_distribution"]

            safe_queue_put(queue_name, entry)

            # Redis Payload
            if tool in ("lmutil", "lmutilnew", "rlmutil", "dslicsrv") and "klock" not in group_name.lower():
                redis_key = f"license:live:{group_name}:{feat['feature']}"
                cleaned_users = [
                    {
                        "Username": u.get("username", "—"),
                        "Hostname": u.get("hostname", "—"),
                        "Timestamp": u.get("checkout_time", "—"),
                    }
                    for u in users_list
                ]

                redis_payload = {
                    "Name": group_name,
                    "Region": server.get("region", "—"),
                    "Feature": feat["feature"],
                    "Total Issued": feat["total_issued"],
                    "In Use": feat["in_use"],
                    "Last Updated": ts_str,
                    "users": cleaned_users,
                }

                try:
                    await shared_redis_client.setex(
                        redis_key, 120, json.dumps(redis_payload)
                    )
                except Exception as e:
                    logger.error(f"Failed to push {redis_key} to Redis: {e}")

    else:
        target_host = server.get("hostname", "Unknown")
        if status == "error":
            clean_err = str(error_msg).replace("\n", " | ").replace("\r", "")
            # Log raw context for better Graylog searching
            logger.error(
                f"[TOOL: {tool}] | [GROUP: {group_name}] | [HOST: {target_host}] -> FAILED: {clean_err}"
            )

            # Send error event to Graylog queue so downtime is tracked
            error_entry = {
                "ts": ts_str,
                "group": group_name,
                "tool": tool,
                "hostname": target_host,
                "status": "error",
                "error_context": clean_err,
            }
            log_queues[queue_name].put_nowait(error_entry)
        else:
            logger.warning(
                f"[TOOL: {tool}] | [GROUP: {group_name}] | [HOST: {target_host}] -> FAILED: No features returned."
            )


async def run_command_safe(
    cmd: List[str], timeout: int, sem: asyncio.Semaphore
) -> Tuple[Optional[str], Optional[str]]:
    async with sem:
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)

            if proc.returncode != 0:
                return None, stderr.decode(errors="replace")
            return stdout.decode(errors="replace"), None
        except asyncio.TimeoutError:
            return None, "Command timed out"
        except Exception as e:
            return None, str(e)


async def run_ds_command_interactive(exe_path, host, port, timeout):
    """Fallback interactive runner for Linux DSLicSrv."""
    password = os.environ.get("CATIA_ADMIN_PASSWORD", "")
    try:
        proc = await asyncio.create_subprocess_exec(
            exe_path,
            "-admin",
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        # Note the '-all' flag is included here to get the users!
        proc.stdin.write(
            f"connect {host} {port}\n{password}\ngetLicenseUsage -all\nexit\n".encode()
        )
        await proc.stdin.drain()
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        return stdout.decode(errors="replace"), None
    except Exception as e:
        return None, str(e)
