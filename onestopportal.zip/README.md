# OSP — OneStop Portal

A premium fullstack enterprise dashboard designed to monitor and manage engineering licenses (FlexLM, RLM, DSLS, Tasking) and track operational health checks for corporate software systems.

---

## 🚀 Key Modules & Functions

### 1. License Live Usage Dashboard
*   **Real-time Monitoring**: Visualizes active license sessions, user checkouts, host names, checkout timestamps, and regional pools.
*   **Dynamic Usage Gauges**: High-performance color scales indicating server capacities (e.g. Critical, Warning, Optimal).
*   **Active Directory Validation**: Interlinks user accounts with company directory information.
*   **Fast Communications Workflow**: Contains a togglable action to copy deduplicated selected user CDSID lists natively formatted for direct Microsoft Outlook emailing (`cdsid1; cdsid2`).

### 2. Applications Health Checker
*   **Real-time Status Tracking**: Background workers verify latency, authorization checkpoints, and network accessibility.
*   **WebSocket State Feeds**: Live visual status updates across the UI without manual page reloads.

### 3. Unified Admin Console
*   **License Maintenance**: Instantly add, edit, or delete monitored licenses.
*   **Role Management**: Manage superadmin rights and audit logs for license notifications.

---

## 🛠️ Technology Stack
*   **Frontend**: React (v19), TypeScript, Vite, Tailwind CSS, Lucide icons, Motion (Framer Motion).
*   **Backend**: Node.js, Express, SQLite (via `better-sqlite3` in high-performance WAL mode).
*   **Realtime**: WebSocket API Server for instant status streams.
*   **Background Jobs**: Node Cron worker routines tracking active engineering systems.

---

## 💻 Local Setup & Development

### Prerequisites
*   Node.js (v18+)
*   npm (v9+)
*   Redis (Required locally or VPN access to the corporate network)

### 1. Install Dependencies
```bash
npm install
```

### 2. Launch Local Dev Servers
Runs both the Vite React frontend (Port 3000) and the Node API/WebSocket Server (Port 3001) concurrently:
```bash
npm run dev:all
```

---

## 🐳 Docker Production Deployment

OSP is configured with an ultra-lightweight Docker design that uses multi-stage builds and pre-compiles TypeScript into pure JavaScript to keep container images tiny (~90MB).

### 1. Create a Production `.env` Config
Create a `.env` file in the project root:

```env
# Server Env
NODE_ENV=production
PORT=3001

# Visteon Active Directory (LDAP) Integration
LDAP_ENABLED=true
LDAP_URL=ldap://vistcorp.ad.visteon.com:389
LDAP_BIND_DN=plmadm@visteon.com
LDAP_BIND_PASSWORD=gbcPLM16
LDAP_BASE_DN=cn=users,dc=vistcorp,dc=ad,dc=visteon,dc=com

# Visteon Mail Server (SMTP) Config
SMTP_ENABLED=true
SMTP_HOST=vistsmtp.visteon.com
SMTP_PORT=25
SMTP_FROM_ADDRESS=EIT_OSP@visteon.com
SMTP_FROM_NAME=EIT-OneStopPortal

# External Redis Configuration
REDIS_HOST=10.x.x.x  # Set to your 24/7 independent Redis IP
REDIS_PORT=6379
```

### 2. Run with Docker Compose
To boot the full production stack:
```bash
docker-compose up --build -d
```

*   **View active logs**: `docker logs -f onestopportal-app`
*   **Mounts**: Persistent SQLite records are stored securely in local volume `osp-sqlite-data`.
