import { DbService } from './db.service';
import { config } from '../config';

export class HealthService {
  /**
   * Pings an application endpoint via HTTP and updates status in SQLite
   */
  static async checkApplicationHealth(app: any): Promise<{ id: number; name: string; status: string; health_status: string; latency: number | null }> {
    const startTime = Date.now();
    let status = 'Active';
    let latency: number | null = null;

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), config.APP_MONITOR_TIMEOUT_MS);

      const headers: Record<string, string> = {
        'User-Agent': 'OneStopPortal-HealthCheck/1.0',
      };

      if (app.auth_type === 'bearer' && app.auth_token) {
        headers['Authorization'] = `Bearer ${app.auth_token}`;
      } else if (app.auth_type === 'basic' && app.auth_token) {
        headers['Authorization'] = `Basic ${app.auth_token}`;
      }

      const response = await fetch(app.url, {
        method: 'HEAD',
        signal: controller.signal,
        headers,
      }).catch(async () => {
        // Fallback to GET if HEAD fails
        return await fetch(app.url, {
          method: 'GET',
          signal: controller.signal,
          headers,
        });
      });

      clearTimeout(timeoutId);
      latency = Date.now() - startTime;

      if (response.status === 401 || response.status === 403) {
        status = 'Auth Issue';
        latency = null;
      } else if (!response.ok && response.status >= 500) {
        status = 'Not Active';
        latency = null;
      } else if (latency > config.APP_SLOW_THRESHOLD_MS) {
        status = 'Slow';
      } else {
        status = 'Active';
      }
    } catch (err: any) {
      if (err.name === 'AbortError') {
        status = 'Slow';
        latency = config.APP_MONITOR_TIMEOUT_MS;
      } else {
        status = 'Not Active';
        latency = null;
      }
    }

    DbService.updateApplicationStatus(app.id, status, latency);
    return { id: app.id, name: app.name, status: app.status || 'Active', health_status: status, latency };
  }


  /**
   * Runs health checks for all applications in database
   */
  static async checkAllApplications(): Promise<any[]> {
    const apps = DbService.getAllApplications();
    const results = await Promise.allSettled(
      apps.map(app => this.checkApplicationHealth(app))
    );

    return results.map(r => r.status === 'fulfilled' ? r.value : null).filter(Boolean);
  }

  /**
   * Performs an immediate HTTP probe on an unsaved application configuration
   */
  static async testUrlHealth(url: string, authType = 'none', authToken: string | null = null): Promise<{
    status: string;
    httpStatus: number | null;
    latency: number | null;
    error?: string;
  }> {
    const startTime = Date.now();
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), config.APP_MONITOR_TIMEOUT_MS);

    const headers: Record<string, string> = {
      'User-Agent': 'OneStopPortal-HealthCheck/1.0',
    };

    if (authType === 'bearer' && authToken) {
      headers['Authorization'] = `Bearer ${authToken}`;
    } else if (authType === 'basic' && authToken) {
      headers['Authorization'] = `Basic ${authToken}`;
    }

    try {
      const response = await fetch(url, {
        method: 'HEAD',
        signal: controller.signal,
        headers,
      }).catch(async () => {
        return await fetch(url, {
          method: 'GET',
          signal: controller.signal,
          headers,
        });
      });

      clearTimeout(timeoutId);
      const latency = Date.now() - startTime;
      const httpStatus = response.status;

      let status = 'Active';
      if (httpStatus === 401 || httpStatus === 403) {
        status = 'Auth Issue';
      } else if (!response.ok && httpStatus >= 500) {
        status = 'Not Active';
      } else if (latency > config.APP_SLOW_THRESHOLD_MS) {
        status = 'Slow';
      }

      return { status, httpStatus, latency };
    } catch (err: any) {
      clearTimeout(timeoutId);
      const latency = Date.now() - startTime;
      if (err.name === 'AbortError') {
        return { status: 'Slow', httpStatus: 408, latency: config.APP_MONITOR_TIMEOUT_MS, error: 'Request Timeout' };
      }
      return { status: 'Not Active', httpStatus: null, latency: null, error: err.message };
    }
  }
}

