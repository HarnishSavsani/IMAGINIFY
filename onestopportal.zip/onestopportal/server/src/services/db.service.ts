import { db } from '../database/connection';

export class DbService {
  // --- LICENSES ---
  static getAllLicenses() {
    const rows = db.prepare('SELECT * FROM licenses').all() as any[];
    return rows.map(r => ({
      ...r,
      reg: JSON.parse(r.reg || '[]'),
      aliases: JSON.parse(r.aliases || '[]'),
      subLicenses: r.sub_licenses ? JSON.parse(r.sub_licenses) : undefined
    }));
  }

  static getLicenseById(id: string) {
    const row = db.prepare('SELECT * FROM licenses WHERE id = ?').get(id) as any;
    if (!row) return null;
    return {
      ...row,
      reg: JSON.parse(row.reg || '[]'),
      aliases: JSON.parse(row.aliases || '[]'),
      subLicenses: row.sub_licenses ? JSON.parse(row.sub_licenses) : undefined
    };
  }

  static getLicenseByName(name: string) {
    const row = db.prepare('SELECT * FROM licenses WHERE LOWER(name) = LOWER(?)').get(name) as any;
    if (!row) return null;
    return {
      ...row,
      reg: JSON.parse(row.reg || '[]'),
      aliases: JSON.parse(row.aliases || '[]'),
      subLicenses: row.sub_licenses ? JSON.parse(row.sub_licenses) : undefined
    };
  }

  static createLicense(data: any) {
    const id = data.id || String(Date.now());
    const titleVal = data.title || data.name;
    const aliasesVal = typeof data.aliases === 'string' ? data.aliases : JSON.stringify(data.aliases || [data.name]);
    const subLicensesVal = data.subLicenses && data.subLicenses.length > 0
      ? JSON.stringify(data.subLicenses)
      : null;
    db.prepare(`
      INSERT INTO licenses (id, name, ab, type, port, sv, reg, col, vendor, expiry, status, osType, lingerTime, dashboardUrl, title, aliases, sub_licenses)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      id,
      data.name,
      data.ab || data.name.substring(0, 2).toUpperCase(),
      data.type || 'FlexLM',
      data.port || 27000,
      data.sv || 1,
      JSON.stringify(data.reg || ['Global']),
      data.col || '#2563eb',
      data.vendor || '',
      data.expiry || '2027-12-31',
      data.status || 'Active',
      data.osType || null,
      data.lingerTime || null,
      data.dashboardUrl || null,
      titleVal,
      aliasesVal,
      subLicensesVal
    );
    return this.getLicenseById(id);
  }

  static updateLicense(id: string, data: any) {
    const existing = this.getLicenseById(id) as any;
    if (!existing) return null;

    const titleVal = data.title !== undefined ? data.title : existing.title;
    const aliasesVal = data.aliases !== undefined
      ? (typeof data.aliases === 'string' ? data.aliases : JSON.stringify(data.aliases))
      : (typeof existing.aliases === 'string' ? existing.aliases : JSON.stringify(existing.aliases));

    const subLicensesVal = data.subLicenses !== undefined
      ? (data.subLicenses && data.subLicenses.length > 0 ? JSON.stringify(data.subLicenses) : null)
      : (existing.subLicenses ? JSON.stringify(existing.subLicenses) : null);

    db.prepare(`
      UPDATE licenses SET
        name = ?, ab = ?, type = ?, port = ?, sv = ?, reg = ?, col = ?, vendor = ?, expiry = ?, status = ?, osType = ?, lingerTime = ?, dashboardUrl = ?, title = ?, aliases = ?, sub_licenses = ?
      WHERE id = ?
    `).run(
      data.name ?? existing.name,
      data.ab ?? existing.ab,
      data.type ?? existing.type,
      data.port ?? existing.port,
      data.sv ?? existing.sv,
      JSON.stringify(data.reg ?? existing.reg),
      data.col ?? existing.col,
      data.vendor ?? existing.vendor,
      data.expiry ?? existing.expiry,
      data.status ?? existing.status,
      data.osType ?? existing.osType,
      data.lingerTime ?? existing.lingerTime,
      data.dashboardUrl ?? existing.dashboardUrl,
      titleVal,
      aliasesVal,
      subLicensesVal,
      id
    );
    return this.getLicenseById(id);
  }

  static deleteLicense(id: string) {
    return db.prepare('DELETE FROM licenses WHERE id = ?').run(id).changes > 0;
  }



  // --- ADMINS ---
  static getAllAdmins() {
    return db.prepare('SELECT * FROM admins ORDER BY id ASC').all();
  }

  static createAdmin(cdsid: string, email: string, role = 'admin') {
    const res = db.prepare(`
      INSERT INTO admins (cdsid, email, role, created_at)
      VALUES (?, ?, ?, datetime('now'))
    `).run(cdsid, email, role);
    return db.prepare('SELECT * FROM admins WHERE id = ?').get(res.lastInsertRowid);
  }

  static deleteAdmin(id: number) {
    return db.prepare('DELETE FROM admins WHERE id = ?').run(id).changes > 0;
  }

  // --- NOTIFICATION LOGS (ANTI-SPAM) ---
  static logNotification(senderCdsid: string, targetUsername: string, licenseName: string, feature: string, status: string) {
    db.prepare(`
      INSERT INTO notification_logs (sender_cdsid, target_username, license_name, feature, sent_at, status)
      VALUES (?, ?, ?, ?, datetime('now'), ?)
    `).run(senderCdsid, targetUsername, licenseName, feature, status);
  }

  static isRecentNotificationSent(senderCdsid: string, targetUsername: string, feature: string, windowMinutes = 30): boolean {
    const row = db.prepare(`
      SELECT COUNT(*) as count FROM notification_logs
      WHERE sender_cdsid = ? AND target_username = ? AND feature = ?
      AND sent_at > datetime('now', '-' || ? || ' minutes')
    `).get(senderCdsid, targetUsername, feature, windowMinutes) as any;
    return row.count > 0;
  }
}
