import { Request, Response } from 'express';
import { DbService } from '../services/db.service';
import { HealthService } from '../services/health.service';

export class AppController {
  static getAllApps(req: Request, res: Response) {
    try {
      const apps = DbService.getAllApplications();
      res.json(apps);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  }

  static createApp(req: Request, res: Response) {
    try {
      const created = DbService.createApplication(req.body);
      res.status(201).json(created);
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  }

  static deleteApp(req: Request, res: Response) {
    try {
      const success = DbService.deleteApplication(Number(req.params.id));
      if (!success) {
        return res.status(404).json({ error: 'Application not found' });
      }
      res.json({ message: 'Application deleted successfully' });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  }

  static updateApp(req: Request, res: Response) {
    try {
      const updated = DbService.updateApplication(Number(req.params.id), req.body);
      if (!updated) {
        return res.status(404).json({ error: 'Application not found' });
      }
      res.json(updated);
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  }

  static async triggerHealthCheck(req: Request, res: Response) {
    try {
      const results = await HealthService.checkAllApplications();
      res.json({ message: 'Health checks executed', apps: results });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  }

  static async testConnection(req: Request, res: Response) {
    try {
      const { url, auth_type, auth_token } = req.body;
      if (!url) {
        return res.status(400).json({ error: 'URL is required' });
      }
      const result = await HealthService.testUrlHealth(url, auth_type, auth_token);
      res.json(result);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  }
}

