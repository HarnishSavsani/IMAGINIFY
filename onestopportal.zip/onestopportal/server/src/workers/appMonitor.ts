import cron from 'node-cron';
import { HealthService } from '../services/health.service';
import { WebSocketHandler } from '../websocket/handler';
import { config } from '../config';

export class AppMonitorWorker {
  private static task: cron.ScheduledTask | null = null;

  static start() {
    console.log(`⏱️ Starting App Health Monitor Worker (Cron schedule: ${config.APP_MONITOR_CRON})`);

    // Schedule cron job
    this.task = cron.schedule(config.APP_MONITOR_CRON, () => {
      this.runCheck();
    });
  }

  private static async runCheck() {
    try {
      console.log('🔍 Running scheduled application health checks...');
      const results = await HealthService.checkAllApplications();
      
      // Broadcast updated statuses to WebSocket subscribers
      WebSocketHandler.broadcast({
        type: 'apps_status_update',
        timestamp: new Date().toISOString(),
        apps: results,
      }, 'apps');
      
      console.log(`✅ App Health Checks completed for ${results.length} applications.`);
    } catch (err) {
      console.error('Error running application health check worker:', err);
    }
  }

  static stop() {
    if (this.task) {
      this.task.stop();
      this.task = null;
    }
  }
}
