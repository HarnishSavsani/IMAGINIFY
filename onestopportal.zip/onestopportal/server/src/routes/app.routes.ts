import { Router } from 'express';
import { AppController } from '../controllers/app.controller';

const router = Router();

router.get('/', AppController.getAllApps);
router.post('/', AppController.createApp);
router.put('/:id', AppController.updateApp);
router.delete('/:id', AppController.deleteApp);
router.post('/check', AppController.triggerHealthCheck);
router.post('/test-connection', AppController.testConnection);

export default router;
