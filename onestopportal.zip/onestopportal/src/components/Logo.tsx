export function Logo({ className = "" }: { className?: string }) {
  return (
    <img
      src="/velos.png"
      alt="velos-logo"
      className={`h-8 w-auto object-contain dark:brightness-0 dark:invert ${className}`}
    />
  );
}
