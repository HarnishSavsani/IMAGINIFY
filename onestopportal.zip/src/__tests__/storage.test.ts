/**
 * Tests for StorageService
 * Used for asserting the behavior of our storage abstraction.
 */
import { describe, it, expect, beforeEach, vi, afterEach } from 'vitest';
import { StorageService } from '../utils/storage';

describe('StorageService', () => {
  beforeEach(() => {
    const store = new Map<string, string>();
    vi.stubGlobal('localStorage', {
      getItem: (key: string) => store.get(key) || null,
      setItem: (key: string, value: string) => store.set(key, value),
      removeItem: (key: string) => store.delete(key),
      clear: () => store.clear(),
    });
  });

  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it('should set and get an item correctly', () => {
    StorageService.setItem('test_key', { dummy: true });
    const result = StorageService.getItem('test_key', null);
    expect(result).toEqual({ dummy: true });
  });

  it('should return fallback if item does not exist', () => {
    const result = StorageService.getItem('non_existent', 'fallback');
    expect(result).toBe('fallback');
  });
});

