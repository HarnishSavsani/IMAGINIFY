/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import { useEffect } from "react";
import { Toaster } from "sonner";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Features from "./components/Features";
import Connecting from "./components/Connecting";
import PoweringTeams from "./components/PoweringTeams";
import Journey from "./components/Journey";
import FaqContact from "./components/FaqContact";
import Footer from "./components/Footer";
import Licenses from "./pages/Licenses";
import LicenseView from "./pages/LicenseView";
import Terms from "./pages/Terms";
import Privacy from "./pages/Privacy";
import Login from "./pages/Login";
import NotFound from "./pages/NotFound";

import AdminLayout from "./pages/admin/AdminLayout";
import Dashboard from "./pages/admin/Dashboard";
import AdminLicenses from "./pages/admin/Licenses";
import Applications from "./pages/admin/Applications";
import Admins from "./pages/admin/Admins";
import Graylog from "./pages/Graylog";

import AppsPage from "./pages/Apps";

function PageManager() {
  const { pathname, hash } = useLocation();

  useEffect(() => {
    if (hash) {
      setTimeout(() => {
        const id = hash.replace("#", "");
        const element = document.getElementById(id);
        if (element) {
          element.scrollIntoView({ behavior: "smooth" });
        }
      }, 50);
    } else {
      window.scrollTo(0, 0);
    }

    if (pathname.startsWith('/apps')) {
      document.title = 'OSP - Apps';
    } else if (pathname.startsWith('/licenses/') || pathname.startsWith('/license/')) {
      document.title = 'OSP - License';
    } else if (pathname.startsWith('/licenses')) {
      document.title = 'OSP - Licenses';
    } else if (pathname.startsWith('/admin')) {
      document.title = 'OSP - Admin';
    } else {
      document.title = 'OSP - OneStopPortal';
    }
  }, [pathname, hash]);

  return null;
}

function HomePage() {
  return (
    <main className="pt-16">
      <Hero />
      <PoweringTeams />
      <Features />
      <Connecting />
      <Journey />
      <FaqContact />
    </main>
  );
}

function MainLayout({ children }: { children: import("react").ReactNode }) {
  return (
    <>
      <Navbar />
      {children}
      <Footer />
    </>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <PageManager />
      <div className="min-h-screen bg-background font-sans text-foreground transition-colors duration-300">
        <Routes>
          <Route path="/" element={<MainLayout><HomePage /></MainLayout>} />
          <Route path="/licenses" element={<MainLayout><Licenses /></MainLayout>} />
          <Route path="/licenses/:id" element={<MainLayout><LicenseView /></MainLayout>} />
          <Route path="/terms" element={<MainLayout><Terms /></MainLayout>} />
          <Route path="/privacy" element={<MainLayout><Privacy /></MainLayout>} />
          <Route path="/apps" element={<MainLayout><AppsPage /></MainLayout>} />
          <Route path="/graylog" element={<Graylog />} />
          <Route path="/login" element={<Login />} />
          
          <Route path="/admin" element={<AdminLayout />}>
            <Route path="dashboard" element={<Dashboard />} />
            <Route path="licenses" element={<AdminLicenses />} />
            <Route path="applications" element={<Applications />} />
            <Route path="admins" element={<Admins />} />
          </Route>
          
          {/* 404 Route */}
          <Route path="*" element={<MainLayout><NotFound /></MainLayout>} />
        </Routes>
        <Toaster position="bottom-right" richColors />
      </div>
    </BrowserRouter>
  );
}
