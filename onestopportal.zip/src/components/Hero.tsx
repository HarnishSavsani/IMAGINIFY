import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';


export default function Hero() {
  const frames = useMemo(() => {
    const f = [];
    const currentDate = new Date();
    for (let i = 0; i < 12; i++) {
      const d = new Date(currentDate.getFullYear(), currentDate.getMonth() - i, 1);
      const month = d.toLocaleString('default', { month: 'short' });
      const year = d.getFullYear();
      
      const bars = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => ({
        day,
        h1: 15 + Math.random() * 40,
        h2: 15 + Math.random() * 40
      }));

      const apps = ['Catia', 'Tasking', 'Matlab', 'FlexLm', 'CST'];
      const rawPie = apps.map(() => 10 + Math.random() * 20);
      const sumPie = rawPie.reduce((a, b) => a + b, 0);
      const pieValues = rawPie.map(v => (v / sumPie) * 100);
      
      const pieData = [];
      let offset = 0;
      pieValues.forEach((val, idx) => {
        pieData.push({
          name: apps[idx],
          percent: val,
          offset: -offset,
        });
        offset += val;
      });
      
      f.push({
        label: `Usage ${month} ${year}`,
        bars,
        pieData,
        utilization1: 71 + Math.random() * 28,
        utilization2: 20 + Math.random() * 40,
      });
    }
    return f;
  }, []);

  const [frameIdx, setFrameIdx] = useState(0);
  const [hoveredSlice, setHoveredSlice] = useState<string | null>(null);
  const [tooltip, setTooltip] = useState<{ show: boolean, x: number, y: number, content: React.ReactNode }>({ show: false, x: 0, y: 0, content: null });

  useEffect(() => {
    const interval = setInterval(() => {
      setFrameIdx(prev => (prev + 1) % 12);
    }, 4000); 
    return () => clearInterval(interval);
  }, []);

  const currentFrame = frames[frameIdx];

  return (
    <section className="bg-background py-8 md:py-12 w-full flex items-center min-h-[calc(100vh-4rem)]">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row items-center justify-center gap-8 lg:gap-12 xl:gap-16">
          <div className="max-w-[32rem] text-center lg:text-left">
            <h1 className="text-5xl font-medium text-foreground lg:text-6xl">
              Every license. Always visible.
            </h1>
            <p className="mt-6 text-lg text-muted-foreground">
              Stop running lmstat commands. See live license status and application health, right from your browser.
            </p>
            <div className="mt-11 flex flex-wrap justify-center lg:justify-start gap-5">
              <Link
                to="/licenses"
                className="group flex items-center justify-center gap-2 rounded-full bg-primary px-7 py-4 text-base font-bold leading-none text-primary-foreground hover:bg-primary/80 outline-none focus-visible:ring-3 focus-visible:ring-ring/50 transition-all select-none shadow-sm shadow-primary/20 hover:shadow-md hover:shadow-primary/30"
              >
                <span>Explore</span>
                <span className="transform transition-transform group-hover:translate-x-1.5 duration-300">
                  <ArrowRight className="w-4 h-4" />
                </span>
              </Link>

            </div>
          </div>
          <div className="flex-shrink-0">
            <div className="grid grid-cols-[4rem_4.5rem_9.5rem] grid-rows-[8rem_7.5rem_1rem_3.5rem] gap-[0.5rem] sm:grid-cols-[4.5rem_5.5rem_11rem] sm:grid-rows-[9rem_8.5rem_1rem_4rem] sm:gap-[0.6rem] xl:grid-cols-[6.5rem_7.5rem_15rem] xl:grid-rows-[13rem_12rem_1rem_5rem] xl:gap-[1rem]">
              <div className="col-[2/-1] h-full w-full overflow-hidden rounded-2xl md:rounded-3xl bg-muted relative group">
                <div className="absolute top-3 left-4 xl:top-5 xl:left-6 font-semibold text-[0.6rem] sm:text-xs xl:text-sm text-foreground/80 z-10 hidden sm:block w-40">
                  <AnimatePresence mode="popLayout">
                    <motion.span 
                      key={currentFrame.label}
                      initial={{ opacity: 0, y: -5 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 5 }}
                      transition={{ duration: 0.3 }}
                      className="block"
                    >
                      {currentFrame.label}
                    </motion.span>
                  </AnimatePresence>
                </div>
                
                {/* Simulated Bar Chart */}
                <div className="absolute inset-x-2 sm:inset-x-6 xl:inset-x-8 bottom-3 sm:bottom-4 xl:bottom-6 top-10 xl:top-14 flex items-end justify-between gap-1 sm:gap-2 xl:gap-3">
                  {currentFrame.bars.map((d, i) => (
                    <div 
                      key={i} 
                      className="flex-1 flex flex-col items-center justify-end h-full relative group/bar cursor-pointer"
                      onMouseMove={(e) => {
                        setTooltip({
                          show: true,
                          x: e.clientX,
                          y: e.clientY,
                          content: (
                            <div className="flex flex-col gap-1.5 min-w-[120px]">
                              <div className="font-bold border-b border-gray-100 dark:border-zinc-700 pb-1 mb-1">{d.day}</div>
                              <div className="flex justify-between items-center text-xs">
                                 <div className="flex items-center gap-1.5">
                                   <div className="w-2 h-2 rounded-sm bg-blue-500"></div>
                                   <span>FlexLM</span>
                                 </div>
                                 <span className="font-mono font-medium">{Math.round(d.h2)}%</span>
                              </div>
                              <div className="flex justify-between items-center text-xs">
                                 <div className="flex items-center gap-1.5">
                                   <div className="w-2 h-2 rounded-sm bg-blue-300"></div>
                                   <span>Non FlexLM</span>
                                 </div>
                                 <span className="font-mono font-medium">{Math.round(d.h1)}%</span>
                              </div>
                            </div>
                          )
                        });
                      }}
                      onMouseLeave={() => setTooltip(prev => ({...prev, show: false}))}
                    >
                      <div className="w-full h-full flex flex-col justify-end relative">
                        <motion.div 
                          className="w-full bg-blue-500 rounded-t-[0.2rem] sm:rounded-t-md origin-bottom flex-shrink-0" 
                          animate={{ height: `${d.h2}%` }}
                          transition={{ duration: 1.5, ease: "easeInOut" }}
                        />
                        <motion.div 
                          className="w-full bg-blue-300 rounded-none origin-bottom flex-shrink-0" 
                          animate={{ height: `${d.h1}%` }}
                          transition={{ duration: 1.5, ease: "easeInOut" }}
                        />
                      </div>
                      <span className="text-[0.45rem] sm:text-[0.6rem] xl:text-xs text-muted-foreground mt-1 sm:mt-2">{d.day}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="col-[1/2] row-[1/2] self-end">
                <svg
                  className="w-[3.5rem] fill-muted-foreground xl:w-[6rem]"
                  viewBox="0 0 131 174"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    fillRule="evenodd"
                    clipRule="evenodd"
                    d="M123.385 5.96661C123.548 6.77895 123.021 7.56919 122.209 7.73166C115.896 8.99415 109.63 9.96037 103.486 10.9077C99.0811 11.5869 94.7393 12.2564 90.4886 13.0183C80.1979 14.8631 70.1037 17.2952 59.8744 21.8151C41.5635 29.906 25.0024 41.8876 14.0337 58.7365C8.37592 67.4273 4.29836 78.5442 3.60483 89.504C2.91206 100.452 5.59556 111.123 13.2956 119.15C17.2013 123.222 22.165 126.554 27.7033 129.043C26.3041 123.491 25.7088 117.6 26.1196 111.355C27.0927 96.5641 39.1649 88.8778 52.0447 87.6439C64.8739 86.4148 79.2577 91.4779 85.4762 102.943C88.8209 109.11 89.0032 115.236 86.7021 120.549C84.4187 125.822 79.7615 130.137 73.7 132.917C63.9444 137.39 51.9845 138.282 40.6769 136.184C37.8771 135.664 35.1075 134.96 32.412 134.076C37.8412 148.683 49.141 160.796 61.9724 170.755C62.6268 171.263 62.7456 172.205 62.2377 172.86C61.7298 173.514 60.7875 173.633 60.133 173.125C46.4556 162.51 34.1037 149.186 28.7723 132.754C22.0105 130.053 15.8772 126.176 11.1305 121.227C2.69861 112.436 -0.119486 100.855 0.610818 89.3145C1.34036 77.7856 5.61055 66.1764 11.5195 57.0997C22.8909 39.6323 39.9827 27.3247 58.6619 19.071C69.1997 14.4148 79.5552 11.9305 89.9592 10.0654C94.3905 9.27105 98.7725 8.59677 103.176 7.91915C109.222 6.98883 115.309 6.05221 121.62 4.78992C122.433 4.62745 123.223 5.15427 123.385 5.96661ZM31.2114 130.479C34.4288 131.674 37.7946 132.598 41.2243 133.234C52.0581 135.245 63.3684 134.354 72.4495 130.19C77.9974 127.646 82.0229 123.805 83.9492 119.357C85.8579 114.95 85.7769 109.79 82.8391 104.373C77.3783 94.3052 64.3988 89.4741 52.3308 90.6302C40.3135 91.7815 29.9547 98.7598 29.1131 111.552C28.6714 118.266 29.4591 124.568 31.2114 130.479Z"
                  ></path>
                  <path
                    fillRule="evenodd"
                    clipRule="evenodd"
                    d="M114.056 1.72566C114.207 0.911209 114.99 0.373802 115.805 0.525328C115.89 0.541148 116.012 0.563426 116.166 0.591592C117.344 0.806885 120.403 1.36614 123.271 2.01411C124.885 2.37873 126.488 2.78252 127.676 3.18084C128.255 3.37485 128.823 3.59596 129.256 3.84814C129.46 3.96696 129.753 4.15933 129.988 4.44833C130.241 4.75995 130.578 5.40289 130.28 6.16935C129.856 7.25995 128.921 8.03458 128.094 8.58288C127.232 9.15452 126.215 9.65136 125.335 10.0779L125.264 10.1127C124.363 10.5492 123.633 10.9033 123.11 11.2487C122.902 11.386 122.778 11.4897 122.71 11.5572C122.597 12.2744 121.977 12.8231 121.228 12.8231C120.4 12.8231 119.728 12.1516 119.728 11.3231C119.728 10.6196 120.043 10.064 120.366 9.67844C120.683 9.29947 121.082 8.99272 121.457 8.745C122.152 8.28613 123.048 7.85224 123.862 7.45814C123.917 7.43145 123.972 7.40493 124.026 7.3786C124.936 6.93764 125.77 6.52466 126.436 6.08262C126.489 6.04781 126.539 6.01368 126.587 5.98025C125.557 5.64496 124.135 5.28497 122.61 4.94034C119.811 4.30799 116.823 3.76151 115.632 3.54375C115.473 3.5147 115.346 3.49149 115.256 3.47472C114.442 3.32319 113.904 2.54011 114.056 1.72566ZM127.788 6.46672C127.788 6.46675 127.785 6.46476 127.779 6.46068C127.785 6.46465 127.788 6.46669 127.788 6.46672Z"
                  ></path>
                </svg>
              </div>
              <div className="col-[1/3] overflow-hidden rounded-2xl md:rounded-3xl bg-muted">
                <div className="p-4 xl:p-6">
                  <div className="flex gap-4 xl:gap-6 items-center">
                    <div className="text-4xl leading-none text-foreground xl:text-6xl">
                      60s
                    </div>
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="lucide lucide-history h-8 w-8 stroke-foreground xl:h-12 xl:w-12"
                      aria-hidden="true"
                    >
                      <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/>
                      <path d="M3 3v5h5"/>
                      <path d="M12 7v5l4 2"/>
                    </svg>
                  </div>
                  <p className="mt-2 text-xs text-foreground md:text-sm xl:mt-5 xl:text-lg lg:max-w-40">
                    Live data refresh.{" "}
                    <span className="font-bold text-foreground/60">
                      Always current
                    </span>
                    , never stale.
                  </p>
                </div>
              </div>
              <div className="col-[2/3] row-[-3/-1] flex flex-col h-full w-full items-center justify-center overflow-hidden rounded-2xl md:rounded-3xl bg-muted relative">
                <div className="w-full h-full relative flex flex-col items-center justify-center">
                  <svg viewBox="0 0 100 65" className="w-[85%] sm:w-[80%] h-auto overflow-visible mt-2">
                    <path d="M 15 50 A 35 35 0 0 1 85 50" fill="none" stroke="currentColor" className="text-blue-200 dark:text-blue-900" strokeWidth="12" strokeLinecap="round" />
                    <motion.path d="M 15 50 A 35 35 0 0 1 85 50" fill="none" stroke="currentColor" className="text-blue-600 dark:text-blue-500" strokeWidth="12" strokeLinecap="round" pathLength="100" animate={{ strokeDasharray: `${currentFrame.utilization1} 100` }} transition={{ duration: 1.5, ease: "easeInOut" }} />
                    <text x="50" y="46" textAnchor="middle" dominantBaseline="alphabetic" className="font-bold fill-foreground" style={{ fontSize: '18px' }}>
                       {Math.round(currentFrame.utilization1)}%
                    </text>
                    <text x="50" y="58" textAnchor="middle" dominantBaseline="alphabetic" className="font-bold fill-muted-foreground" style={{ fontSize: '6px', letterSpacing: '0.1em' }}>
                       UTILIZATION
                    </text>
                  </svg>
                </div>
              </div>
              <div className="relative col-[3/4] row-[2/4] rounded-2xl md:rounded-3xl bg-muted overflow-hidden flex items-center justify-center p-2 sm:p-0">
                <svg viewBox="0 0 100 100" className="w-[85%] h-[85%] sm:w-[80%] sm:h-[80%] -rotate-90 overflow-visible">
                  {currentFrame.pieData.map((slice, i) => {
                    const pieColors = ["text-blue-500", "text-blue-300", "text-blue-700", "text-blue-800", "text-blue-600"];
                    const bgColors = ["bg-blue-500", "bg-blue-300", "bg-blue-700", "bg-blue-800", "bg-blue-600"];
                    const isPopped = hoveredSlice === slice.name;
                    return (
                      <motion.circle
                        key={slice.name}
                        cx="50" cy="50" r="32"
                        fill="none" stroke="currentColor"
                        className={`${pieColors[i]} cursor-pointer outline-none ${isPopped ? 'relative z-10 drop-shadow-md' : ''}`}
                        initial={false}
                        animate={{ 
                          strokeDasharray: `${slice.percent} 100`,
                          strokeDashoffset: slice.offset,
                          strokeWidth: isPopped ? 28 : 22
                        }}
                        pathLength="100"
                        transition={{ duration: 1.5, ease: "easeInOut", strokeWidth: { duration: 0.2 } }}
                        onMouseEnter={() => setHoveredSlice(slice.name)}
                        onMouseMove={(e) => {
                          setTooltip({
                            show: true,
                            x: e.clientX,
                            y: e.clientY,
                            content: (
                              <div className="flex items-center gap-2">
                                <div className={`w-3 h-3 rounded-sm ${bgColors[i]}`}></div>
                                <span className="font-medium">{slice.name}</span>
                                <span className="ml-2 font-mono font-semibold">{Math.round(slice.percent)}%</span>
                              </div>
                            )
                          });
                        }}
                        onMouseLeave={() => {
                          setHoveredSlice(null);
                          setTooltip(prev => ({...prev, show: false}));
                        }}
                      />
                    );
                  })}
                </svg>
              </div>
              <div className="col-[-2/-1] row-[-1/-2] hidden">
              </div>
            </div>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {tooltip.show && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.15 }}
            className="fixed z-[100] pointer-events-none bg-white dark:bg-zinc-800 shadow-xl rounded-lg border border-gray-100 dark:border-zinc-700 px-3 py-2 text-sm text-gray-700 dark:text-zinc-200"
            style={{ left: tooltip.x + 12, top: tooltip.y + 12 }}
          >
            {tooltip.content}
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
