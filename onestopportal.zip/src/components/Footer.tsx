import { Facebook, Instagram, Linkedin, Twitter, Youtube } from "lucide-react";
import { Link } from "react-router-dom";
import { Logo } from "./Logo";

export default function Footer() {
  const handleNavClick = (e: import("react").MouseEvent<HTMLAnchorElement>, hash: string) => {
    if (window.location.pathname === "/") {
      const element = document.getElementById(hash.replace("#", ""));
      if (element) {
        e.preventDefault();
        element.scrollIntoView({ behavior: "smooth" });
        window.history.pushState(null, "", hash);
      }
    }
  };

  const handleHomeClick = (e: import("react").MouseEvent<HTMLAnchorElement>) => {
    if (window.location.pathname === "/") {
      e.preventDefault();
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  const links = [
    { label: "Home", to: "/", isHome: true },
    { label: "Features", to: "/#features", hash: "#features" },
    { label: "Licenses", to: "/licenses" },
    { label: "Apps", to: "/apps" },
    { label: "Contact", to: "/#faq-contact", hash: "#faq-contact" }
  ];
  
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-white dark:bg-[#0a0a0a] border-t border-gray-100 dark:border-zinc-800 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-8 mb-16">
          <Link to="/" onClick={handleHomeClick} className="flex items-center gap-2">
            <Logo className="text-xl" />
          </Link>

          <ul className="flex flex-wrap justify-center items-center gap-6 md:gap-8">
            {links.map((link) => (
               <li key={link.label}>
                 {link.isHome ? (
                   <Link 
                     to={link.to} 
                     onClick={handleHomeClick}
                     className="flex hover:text-gray-900 dark:hover:text-zinc-300 text-gray-500 dark:text-zinc-500 font-medium transition-colors"
                   >
                     {link.label}
                   </Link>
                 ) : link.hash ? (
                   <Link 
                     to={link.to} 
                     onClick={(e) => handleNavClick(e, link.hash!)}
                     className="flex hover:text-gray-900 dark:hover:text-zinc-300 text-gray-500 dark:text-zinc-500 font-medium transition-colors"
                   >
                     {link.label}
                   </Link>
                 ) : (
                   <Link to={link.to} className="flex hover:text-gray-900 dark:hover:text-zinc-300 text-gray-500 dark:text-zinc-500 font-medium transition-colors">
                     {link.label}
                   </Link>
                 )}
               </li>
            ))}
          </ul>

          <div className="flex items-center gap-4 text-gray-400 dark:text-zinc-500">
            <a href="https://www.instagram.com/visteon" target="_blank" rel="noopener noreferrer" title="Instagram" className="hover:text-blue-600 dark:hover:text-blue-500 hover:scale-110 transition-all"><Instagram className="w-5 h-5" /></a>
            <a href="https://www.facebook.com/VisteonCorporation" target="_blank" rel="noopener noreferrer" title="Facebook" className="hover:text-blue-600 dark:hover:text-blue-500 hover:scale-110 transition-all"><Facebook className="w-5 h-5" /></a>
            <a href="https://twitter.com/Visteon" target="_blank" rel="noopener noreferrer" title="Twitter" className="hover:text-blue-600 dark:hover:text-blue-500 hover:scale-110 transition-all"><Twitter className="w-5 h-5" /></a>
            <a href="https://www.linkedin.com/company/visteon" target="_blank" rel="noopener noreferrer" title="LinkedIn" className="hover:text-blue-600 dark:hover:text-blue-500 hover:scale-110 transition-all"><Linkedin className="w-5 h-5" /></a>
            <a href="https://www.youtube.com/user/Visteon" target="_blank" rel="noopener noreferrer" title="YouTube" className="hover:text-blue-600 dark:hover:text-blue-500 hover:scale-110 transition-all"><Youtube className="w-5 h-5" /></a>
          </div>
        </div>

        <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-gray-500 dark:text-zinc-600 pt-8 border-t border-gray-100 dark:border-zinc-800">
          <p>© {currentYear} OneStopPortal. All rights reserved.</p>
          <div className="flex flex-wrap items-center gap-6 mt-4 md:mt-0">
            <Link to="/terms" className="hover:text-gray-900 dark:hover:text-zinc-400 transition-colors underline underline-offset-4 decoration-gray-300 dark:decoration-zinc-800">Terms and Conditions</Link>
            <Link to="/privacy" className="hover:text-gray-900 dark:hover:text-zinc-400 transition-colors underline underline-offset-4 decoration-gray-300 dark:decoration-zinc-800">Privacy Policy</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
