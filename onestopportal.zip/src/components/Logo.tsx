import { ReactNode } from "react";

export function Logo({ className = "" }: { className?: string }) {
  return (
    <div className={`flex items-center text-gray-900 dark:text-white ${className}`}>
      <svg viewBox="0 0 100 100" className="h-[1.4em] w-auto overflow-visible -mt-[0.05em] mr-[0.03em] -rotate-90">
        <circle cx="50" cy="50" r="32" fill="none" stroke="currentColor" className="text-blue-500" strokeWidth="26" pathLength="100" strokeDasharray="20 100" strokeDashoffset="0" />
        <circle cx="50" cy="50" r="32" fill="none" stroke="currentColor" className="text-blue-300" strokeWidth="26" pathLength="100" strokeDasharray="20 100" strokeDashoffset="-20" />
        <circle cx="50" cy="50" r="32" fill="none" stroke="currentColor" className="text-blue-700" strokeWidth="26" pathLength="100" strokeDasharray="20 100" strokeDashoffset="-40" />
        <circle cx="50" cy="50" r="32" fill="none" stroke="currentColor" className="text-blue-800" strokeWidth="26" pathLength="100" strokeDasharray="20 100" strokeDashoffset="-60" />
        <circle cx="50" cy="50" r="32" fill="none" stroke="currentColor" className="text-blue-600" strokeWidth="26" pathLength="100" strokeDasharray="20 100" strokeDashoffset="-80" />
      </svg>
      <span className="font-bold text-lg leading-none tracking-tight">neStopPortal</span>
    </div>
  );
}
