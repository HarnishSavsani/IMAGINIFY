import { MessageCircle, Mail, ChevronDown, Loader2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { ApiClient } from "../lib/api";

export default function FaqContact() {
  const faqs = [
    { q: "Do I need to log in to the portal?", a: "No. OneStopPortal is open to anyone on the Visteon network or VPN — no account needed." },
    { q: "How often does data refresh?", a: "Live data refreshes every 60 seconds from Graylog. A countdown timer is always visible." },
    { q: "Which license managers are supported?", a: "FlexLM, RLM, Tasking, Greenhills and DSLS. More can be added by License Ops via the Admin panel." },
    { q: "How do I add a new server or license?", a: "Submit your request in contact form." },
    { q: "What Timezone dashboard show us?", a: "It shows UTC+00:00 (GMT) Greenwich Mean Time." }
  ];

  const [openIndex, setOpenIndex] = useState<number | null>(0);
  const [cdsid, setCdsid] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!cdsid.trim() || !email.trim() || !message.trim()) {
      toast.error("Please fill in all required fields.");
      return;
    }

    if (!email.trim().toLowerCase().endsWith("@visteon.com")) {
      toast.error("Only @visteon.com email addresses are allowed to send messages.");
      return;
    }


    try {
      setIsSubmitting(true);
      await ApiClient.sendContactMessage({
        cdsid: cdsid.trim(),
        email: email.trim(),
        message: message.trim(),
      });
      toast.success("Message sent successfully!");
      setCdsid("");
      setEmail("");
      setMessage("");
    } catch (err: any) {
      toast.error(err.message || "Failed to send message.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="faq-contact" className="py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto border-t border-gray-100 dark:border-zinc-800">
      <div className="text-center mb-16">
        <h2 className="text-4xl font-bold text-gray-900 dark:text-zinc-50 mb-4 tracking-tight">How can we help?</h2>
        <p className="text-gray-500 dark:text-zinc-400 text-lg">Check our FAQ for quick answers or send us a message.</p>
      </div>

      <div className="grid md:grid-cols-2 gap-16 lg:gap-24">
        <div>
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 bg-blue-50 dark:bg-blue-900/20 rounded-full flex items-center justify-center text-blue-600">
              <MessageCircle className="w-5 h-5" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 dark:text-zinc-50">Frequently Asked Questions</h3>
          </div>

          <div className="space-y-4">
            {faqs.map((faq, i) => (
              <div key={i} className="border-b border-gray-100 dark:border-zinc-800 pb-4">
                <button
                  onClick={() => setOpenIndex(openIndex === i ? null : i)}
                  className="w-full flex items-center justify-between text-left py-3 group"
                >
                  <span className={`font-medium transition-colors ${openIndex === i ? 'text-blue-600' : 'text-gray-900 dark:text-zinc-300 group-hover:text-blue-600 dark:group-hover:text-blue-400'}`}>{faq.q}</span>
                  <ChevronDown className={`w-5 h-5 text-gray-400 dark:text-zinc-500 transition-transform duration-300 ${openIndex === i ? "rotate-180 text-blue-600" : ""}`} />
                </button>
                <div className={`overflow-hidden transition-all duration-300 ${openIndex === i ? "max-h-40 opacity-100" : "max-h-0 opacity-0"}`}>
                  <div className="pt-2 pb-4 text-gray-500 dark:text-zinc-400 text-sm leading-relaxed">
                    {faq.a}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div>
           <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 bg-blue-50 dark:bg-blue-900/20 rounded-full flex items-center justify-center text-blue-600">
              <Mail className="w-5 h-5" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 dark:text-zinc-50">Still have questions?</h3>
          </div>

          <div className="bg-white dark:bg-[#111] p-8 lg:p-10 rounded-3xl border border-gray-100 dark:border-zinc-800 shadow-xl shadow-gray-100/50 dark:shadow-none">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-900 dark:text-zinc-300 mb-2">
                  CDSID <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={cdsid}
                  onChange={(e) => setCdsid(e.target.value)}
                  placeholder="cdsid"
                  className="w-full px-5 py-3 bg-gray-50 dark:bg-zinc-800/50 border border-gray-200 dark:border-zinc-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all font-medium text-gray-900 dark:text-zinc-100 placeholder:text-gray-400 dark:placeholder:text-zinc-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-900 dark:text-zinc-300 mb-2">
                  Email <span className="text-red-500">*</span>
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="cdsid@visteon.com"
                  className="w-full px-5 py-3 bg-gray-50 dark:bg-zinc-800/50 border border-gray-200 dark:border-zinc-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all font-medium text-gray-900 dark:text-zinc-100 placeholder:text-gray-400 dark:placeholder:text-zinc-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-900 dark:text-zinc-300 mb-2">
                  Message <span className="text-red-500">*</span>
                </label>
                <textarea
                  required
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="How can we help?"
                  rows={4}
                  className="w-full px-5 py-3 bg-gray-50 dark:bg-zinc-800/50 border border-gray-200 dark:border-zinc-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all resize-none font-medium text-gray-900 dark:text-zinc-100 placeholder:text-gray-400 dark:placeholder:text-zinc-500"
                ></textarea>
              </div>
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-blue-600 text-white font-semibold py-3.5 rounded-xl hover:bg-blue-700 transition-all shadow-md shadow-blue-600/20 hover:shadow-lg hover:shadow-blue-600/30 flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Sending...
                  </>
                ) : (
                  "Send Message"
                )}
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
