import { useState } from "react";
import { ChevronDown, Cloud, Shield, Key, Database, Moon, Sun, Menu, X, Activity } from "lucide-react";
import { useTheme } from "./ThemeProvider";
import { Link } from "react-router-dom";

import { Logo } from "./Logo";

export default function Navbar() {
  const { theme, toggleTheme } = useTheme();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleLogoClick = (e: import("react").MouseEvent<HTMLAnchorElement>) => {
    if (window.location.pathname === "/") {
      e.preventDefault();
      window.scrollTo({ top: 0, behavior: "smooth" });
      setIsMobileMenuOpen(false);
    }
  };

  const handleNavClick = (e: import("react").MouseEvent<HTMLAnchorElement>, hash: string) => {
    if (window.location.pathname === "/") {
      const element = document.getElementById(hash.replace("#", ""));
      if (element) {
        e.preventDefault();
        element.scrollIntoView({ behavior: "smooth" });
        setIsMobileMenuOpen(false);
        window.history.pushState(null, "", hash);
      }
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/80 dark:bg-[#0a0a0a]/80 backdrop-blur-md border-b border-gray-100 dark:border-zinc-800 transition-colors duration-300">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <Link to="/" onClick={handleLogoClick} className="flex items-center gap-2">
          <Logo className="text-2xl" />
        </Link>


        <ul className="hidden lg:flex items-center gap-1 text-sm font-medium text-gray-700 dark:text-zinc-300">
          <li className="relative group p-2">
            <button className="flex items-center gap-1 hover:text-gray-900 dark:hover:text-white transition-colors py-2 px-3 rounded-md hover:bg-gray-50 dark:hover:bg-zinc-900/50">
              Services <ChevronDown className="h-4 w-4 text-gray-400 group-hover:rotate-180 transition-transform" />
            </button>
            <div className="absolute top-full left-1/2 -translate-x-1/2 mt-0 w-[600px] opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all bg-white dark:bg-[#111] border border-gray-100 dark:border-zinc-800 rounded-xl shadow-xl dark:shadow-none overflow-hidden p-4 grid grid-cols-5 gap-6">
               <div className="col-span-2 bg-gray-50 dark:bg-zinc-900 rounded-lg p-6 flex flex-col justify-between">
                 <div className="flex items-center justify-center flex-1">
                   <Activity className="w-16 h-16 text-gray-900 dark:text-zinc-50" />
                 </div>
                 <div className="mt-4">
                   <h4 className="font-semibold text-gray-900 dark:text-zinc-50 text-base mb-1">Overview</h4>
                   <p className="text-sm text-gray-500 dark:text-zinc-400">Discover how OneStopPortal gives real-time license visibility.</p>
                 </div>
               </div>
               <div className="col-span-3 grid grid-cols-2 gap-x-4 gap-y-6">
                 <Link to="/licenses" className="block hover:bg-gray-50 dark:hover:bg-zinc-800/50 p-2 -m-2 rounded-lg transition-colors">
                   <Cloud className="w-5 h-5 mb-2 text-gray-600 dark:text-zinc-400" />
                   <h5 className="font-semibold text-sm text-gray-900 dark:text-zinc-50">License Explorer</h5>
                   <p className="text-xs text-gray-500 dark:text-zinc-400 mt-1 line-clamp-2">Filter and search all licenses across servers.</p>
                 </Link>
                 <Link to="/apps" className="block hover:bg-gray-50 dark:hover:bg-zinc-800/50 p-2 -m-2 rounded-lg transition-colors">
                   <Shield className="w-5 h-5 mb-2 text-gray-600 dark:text-zinc-400" />
                   <h5 className="font-semibold text-sm text-gray-900 dark:text-zinc-50">App Health</h5>
                   <p className="text-xs text-gray-500 dark:text-zinc-400 mt-1 line-clamp-2">Live status for all hosted applications.</p>
                 </Link>
                 <Link to="/login" className="block hover:bg-gray-50 dark:hover:bg-zinc-800/50 p-2 -m-2 rounded-lg transition-colors">
                   <Key className="w-5 h-5 mb-2 text-gray-600 dark:text-zinc-400" />
                   <h5 className="font-semibold text-sm text-gray-900 dark:text-zinc-50">Admin Panel</h5>
                   <p className="text-xs text-gray-500 dark:text-zinc-400 mt-1 line-clamp-2">Add servers and licenses without CLI commands.</p>
                 </Link>
                 <Link to="/graylog" className="block hover:bg-gray-50 dark:hover:bg-zinc-800/50 p-2 -m-2 rounded-lg transition-colors">
                   <Database className="w-5 h-5 mb-2 text-gray-600 dark:text-zinc-400" />
                   <h5 className="font-semibold text-sm text-gray-900 dark:text-zinc-50">Graylog Integration</h5>
                   <p className="text-xs text-gray-500 dark:text-zinc-400 mt-1 line-clamp-2">Deep-dive analytics and alerts via Graylog.</p>
                 </Link>
               </div>
            </div>
          </li>
          <li className="relative group p-2">
             <Link to="/licenses" className="flex items-center gap-1 hover:text-gray-900 dark:hover:text-white transition-colors py-2 px-3 rounded-md hover:bg-gray-50 dark:hover:bg-zinc-900/50">
               Licenses
             </Link>
          </li>
          <li className="relative group p-2">
             <Link to="/apps" className="flex items-center gap-1 hover:text-gray-900 dark:hover:text-white transition-colors py-2 px-3 rounded-md hover:bg-gray-50 dark:hover:bg-zinc-900/50">
               Apps
             </Link>
          </li>
          <li className="relative group p-2">
             <Link to="/#faq-contact" onClick={(e) => handleNavClick(e, "#faq-contact")} className="flex items-center gap-1 hover:text-gray-900 dark:hover:text-white transition-colors py-2 px-3 rounded-md hover:bg-gray-50 dark:hover:bg-zinc-900/50">
               Contact
             </Link>
          </li>
        </ul>

        <div className="flex items-center gap-4 text-sm font-medium">
          <button onClick={toggleTheme} className="p-2.5 text-gray-500 dark:text-zinc-400 bg-gray-50 dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 hover:text-gray-900 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-zinc-800 rounded-full transition-colors">
            {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
          
          <button 
            className="lg:hidden p-2.5 text-gray-500 dark:text-zinc-400 bg-gray-50 dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 hover:text-gray-900 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-zinc-800 rounded-lg transition-colors"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </nav>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="lg:hidden bg-white dark:bg-[#0a0a0a] border-b border-gray-100 dark:border-zinc-800">
          <ul className="px-4 pt-2 pb-4 space-y-1">
            <li>
              <Link to="/licenses" onClick={() => setIsMobileMenuOpen(false)} className="w-full flex items-center justify-between text-left px-3 py-3 font-medium text-gray-900 dark:text-zinc-100 rounded-lg hover:bg-gray-50 dark:hover:bg-zinc-900/50 transition-colors">
                Licenses
              </Link>
            </li>
            <li>
              <Link to="/apps" onClick={() => setIsMobileMenuOpen(false)} className="w-full flex items-center justify-between text-left px-3 py-3 font-medium text-gray-900 dark:text-zinc-100 rounded-lg hover:bg-gray-50 dark:hover:bg-zinc-900/50 transition-colors">
                Apps
              </Link>
            </li>
            <li>
              <Link to="/#faq-contact" onClick={(e) => handleNavClick(e, "#faq-contact")} className="w-full flex items-center justify-between text-left px-3 py-3 font-medium text-gray-900 dark:text-zinc-100 rounded-lg hover:bg-gray-50 dark:hover:bg-zinc-900/50 transition-colors">
                Contact
              </Link>
            </li>
          </ul>
        </div>
      )}
    </header>
  );
}
