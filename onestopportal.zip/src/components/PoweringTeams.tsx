import { ArrowRight } from "lucide-react";
import React, { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { useTheme } from "./ThemeProvider";

const licenseNames = [
  "FlexLM",
  "RLM",
  "Graylog",
  "MATLAB",
  "QNX",
  "CST",
  "ARM",
  "Kanzi",
  "GreenHills"
];

const AnimatedText: React.FC<{ text: string }> = ({ text }) => {
  const ref = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState(1);

  useEffect(() => {
    let frame: number;
    const update = () => {
      if (ref.current) {
        const rect = ref.current.getBoundingClientRect();
        const center = window.innerWidth / 2;
        const itemCenter = rect.left + rect.width / 2;
        const dist = Math.abs(center - itemCenter);
        const maxDist = 400; // slightly wider max dist for smooth scaling
        
        // Scale up towards the center (1.75 max scale)
        const newScale = 1 + (0.75 * Math.max(0, 1 - dist / maxDist));
        setScale(newScale);
      }
      frame = requestAnimationFrame(update);
    };
    update();
    return () => cancelAnimationFrame(frame);
  }, []);

  return (
    <div className="flex-shrink-0 mx-8 md:mx-14 flex items-center justify-center h-20">
       <div
         ref={ref}
         className="font-black text-xl md:text-2xl text-muted-foreground/40 hover:text-blue-600 dark:hover:text-blue-500 transition-colors duration-300 cursor-default"
         style={{ transform: `scale(${scale})` }}
       >
         {text}
       </div>
    </div>
  );
}

export default function PoweringTeams() {
  const { theme } = useTheme();

  return (
    <section id="servers" className="py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto text-center border-t border-gray-100 dark:border-zinc-800 overflow-hidden">
      <h2 className="text-3xl font-bold text-gray-900 dark:text-zinc-50 mb-2">Monitoring licenses across Visteon engineering</h2>
      <p className="text-gray-500 dark:text-zinc-400 mb-16">Covering FlexLM, RLM, Tasking, and DSLS platforms</p>
      
      <div className="relative w-full overflow-hidden mb-16 before:absolute before:left-0 before:w-16 md:before:w-48 before:h-full before:bg-gradient-to-r before:from-background before:to-transparent before:z-10 after:absolute after:right-0 after:w-16 md:after:w-48 after:h-full after:bg-gradient-to-l after:from-background after:to-transparent after:z-10 py-8">
        <div className="flex w-fit animate-marquee">
          <div className="flex items-center">
              {licenseNames.map((name, idx) => <AnimatedText key={idx} text={name} />)}
          </div>
          <div className="flex items-center">
              {licenseNames.map((name, idx) => <AnimatedText key={`dup-${idx}`} text={name} />)}
          </div>
        </div>
      </div>

      <Link 
        to="/licenses" 
        className="bg-blue-600 text-white px-8 py-3 rounded-full font-medium hover:bg-blue-700 transition-colors inline-flex items-center gap-2 text-sm shadow-sm hover:shadow-blue-600/20 group"
      >
        Discover <ArrowRight className="w-4 h-4 ml-1 transition-transform group-hover:translate-x-1" />
      </Link>
    </section>
  );
}
