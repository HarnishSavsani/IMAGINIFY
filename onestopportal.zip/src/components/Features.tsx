import { RefreshCcw, Search, Server, Activity, Settings, Download } from "lucide-react";
import { Link } from "react-router-dom";

export default function Features() {
  const features = [
    { 
      name: "Continuous Monitoring", 
      icon: <RefreshCcw className="w-8 h-8 text-blue-600" />,
      desc: "License data and status refreshed automatically to ensure you always have the latest insights."
    },
    { 
      name: "License Explorer", 
      icon: <Search className="w-8 h-8 text-blue-600" />,
      desc: "Filter, sort, and export all licenses across every server in seconds.",
      link: "/licenses"
    },
    { 
      name: "App Health", 
      icon: <Server className="w-8 h-8 text-blue-600" />,
      desc: "Live status for all hosted applications with color-coded utilization.",
      link: "/apps"
    },
    { 
      name: "Graylog Integration", 
      icon: <Activity className="w-8 h-8 text-blue-600" />,
      desc: "Complete pipeline from raw server logs to actionable dashboard analytics."
    },
    { 
      name: "Admin Panel", 
      icon: <Settings className="w-8 h-8 text-blue-600" />,
      desc: "Manage licenses, onboard applications, and configure admin access — no CLI required."
    },
    { 
      name: "Export & Reports", 
      icon: <Download className="w-8 h-8 text-blue-600" />,
      desc: "One-click export to Excel or CSV for audits and cost reviews."
    },
  ];

  return (
    <section id="features" className="py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto border-t border-gray-100 dark:border-zinc-800">
      <div className="max-w-2xl mx-auto text-center mb-12">
        <h2 className="text-3xl font-bold text-gray-900 dark:text-zinc-50 mb-4">What You Get</h2>
        <p className="text-gray-500 dark:text-zinc-400">
          Everything your team needs to monitor and manage licenses and applications.
        </p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {features.map((feature, i) => {
          const CardContent = (
            <div className="border border-gray-100 dark:border-zinc-800 rounded-2xl p-8 hover:shadow-lg dark:hover:shadow-[0_0_20px_rgba(30,58,138,0.1)] transition-all hover:border-blue-100 dark:hover:border-zinc-700 bg-white dark:bg-[#111] group cursor-pointer h-full">
              <div className="mb-6 transform transition-transform duration-300 group-hover:scale-110 group-hover:-translate-y-1 inline-block">
                {feature.icon}
              </div>
              <h3 className="font-semibold text-lg text-gray-900 dark:text-zinc-100 mb-3 group-hover:text-blue-600 transition-colors">{feature.name}</h3>
              <p className="text-gray-500 dark:text-zinc-400 text-sm leading-relaxed">
                {feature.desc}
              </p>
            </div>
          );

          return feature.link ? (
            <Link to={feature.link} key={i} className="block w-full h-full">
              {CardContent}
            </Link>
          ) : (
            <div key={i}>
              {CardContent}
            </div>
          );
        })}
      </div>
    </section>
  );
}
