import { useState } from "react";

export default function Journey() {
  const [activeStep, setActiveStep] = useState(1);

  return (
    <section className="py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto border-t border-gray-100 dark:border-zinc-800">
      <div className="mb-16 text-center">
        <h2 className="text-4xl font-bold text-gray-900 dark:text-zinc-50 mb-4 tracking-tight">How It Works</h2>
        <p className="text-lg text-gray-500 dark:text-zinc-400 max-w-2xl mx-auto leading-relaxed">
          From raw license logs to a live, queryable dashboard — in three simple steps.
        </p>
      </div>

      <div className="bg-white dark:bg-[#111] border text-left border-gray-100 dark:border-zinc-800 rounded-3xl p-8 lg:p-14 shadow-sm relative overflow-hidden">
        {/* Subtle decorative background piece */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-blue-50/50 dark:bg-blue-900/10 rounded-full blur-3xl -z-10"></div>
        
        <div className="mb-16 relative z-10">
           <h3 className="text-2xl font-bold text-gray-900 dark:text-zinc-50">Up and running in 60 seconds</h3>
        </div>

        <div className="grid md:grid-cols-3 gap-10 md:gap-8 relative z-10" onMouseLeave={() => setActiveStep(1)}>
           {/* Connecting Line with Flowing Blue Progress */}
           <div className="hidden md:block absolute top-[11px] left-2 right-2 h-0.5 bg-gray-100 dark:bg-zinc-800 z-0 overflow-hidden">
             <div 
               className="absolute top-0 left-0 h-full bg-blue-600 transition-all duration-500 ease-out" 
               style={{ width: activeStep === 1 ? '33.33%' : activeStep === 2 ? '66.66%' : '100%' }}
             ></div>
           </div>

           <div className="group cursor-pointer" onMouseEnter={() => setActiveStep(1)}>
              <div className={`relative z-10 w-3 h-3 outline outline-4 outline-white dark:outline-[#111] rounded-full mb-8 mt-1.5 ml-2 transition-all duration-300 group-hover:scale-150 ${activeStep >= 1 ? 'bg-blue-600' : 'bg-gray-300 dark:bg-zinc-700'}`}></div>
              <div className="border border-gray-200 dark:border-zinc-800 rounded-md px-4 py-1.5 text-sm font-semibold inline-block mb-5 transition-colors duration-300 group-hover:border-blue-200 dark:group-hover:border-blue-900/50 group-hover:text-blue-600 dark:group-hover:text-blue-400 group-hover:bg-blue-50 dark:group-hover:bg-blue-500/10 text-gray-900 dark:text-zinc-50">
                 <span className="text-gray-400 dark:text-zinc-500 mr-2 group-hover:text-blue-500 transition-colors">01</span>Poll
              </div>
              <h4 className="font-bold text-lg text-gray-900 dark:text-zinc-100 mb-3 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors duration-300">License servers are queried</h4>
              <p className="text-gray-500 dark:text-zinc-400 text-sm pb-2 leading-relaxed h-20">
                Graylog polls all servers every 60 seconds using lmstat ,rlmstat and DSstats - capturing concurrent usage in real time.
              </p>
           </div>

           <div className="group cursor-pointer" onMouseEnter={() => setActiveStep(2)}>
              <div className={`relative z-10 w-3 h-3 outline outline-4 outline-white dark:outline-[#111] rounded-full mb-8 mt-1.5 ml-2 transition-all duration-300 group-hover:scale-150 ${activeStep >= 2 ? 'bg-blue-600' : 'bg-gray-300 dark:bg-zinc-700'}`}></div>
              <div className="border border-gray-200 dark:border-zinc-800 rounded-md px-4 py-1.5 text-sm font-semibold inline-block mb-5 transition-colors duration-300 group-hover:border-blue-200 dark:group-hover:border-blue-900/50 group-hover:text-blue-600 dark:group-hover:text-blue-400 group-hover:bg-blue-50 dark:group-hover:bg-blue-500/10 text-gray-900 dark:text-zinc-50">
                 <span className="text-gray-400 dark:text-zinc-500 mr-2 group-hover:text-blue-500 transition-colors">02</span>Stream
              </div>
              <h4 className="font-bold text-lg text-gray-900 dark:text-zinc-100 mb-3 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors duration-300">Logs are parsed and indexed</h4>
              <p className="text-gray-500 dark:text-zinc-400 text-sm pb-2 leading-relaxed h-20">
                Raw license log streams flow into Graylog's pipeline. Feature names, user IDs, pool counts, and timestamps are extracted and aggregated.
              </p>
           </div>

           <div className="group cursor-pointer" onMouseEnter={() => setActiveStep(3)}>
              <div className={`relative z-10 w-3 h-3 outline outline-4 outline-white dark:outline-[#111] rounded-full mb-8 mt-1.5 ml-2 transition-all duration-300 group-hover:scale-150 ${activeStep >= 3 ? 'bg-blue-600' : 'bg-gray-300 dark:bg-zinc-700'}`}></div>
              <div className="border border-gray-200 dark:border-zinc-800 rounded-md px-4 py-1.5 text-sm font-semibold inline-block mb-5 transition-colors duration-300 group-hover:border-blue-200 dark:group-hover:border-blue-900/50 group-hover:text-blue-600 dark:group-hover:text-blue-400 group-hover:bg-blue-50 dark:group-hover:bg-blue-500/10 text-gray-900 dark:text-zinc-50">
                 <span className="text-gray-400 dark:text-zinc-500 mr-2 group-hover:text-blue-500 transition-colors">03</span>Monitor
              </div>
              <h4 className="font-bold text-lg text-gray-900 dark:text-zinc-100 mb-3 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors duration-300">Stats appear in your dashboard</h4>
              <p className="text-gray-500 dark:text-zinc-400 text-sm pb-2 leading-relaxed h-20">
                Renders Unique Denials, Concurrent Peak Usage, Feature usage and many other stats that helps take business decisions.
              </p>
           </div>

        </div>
      </div>
    </section>
  );
}
