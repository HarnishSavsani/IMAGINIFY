import { Server, BarChart3, Activity } from "lucide-react";

export default function Connecting() {
  const leftNodes = [
    { top: "10%", y: 60 },
    { top: "26%", y: 156 },
    { top: "42%", y: 252 },
    { top: "58%", y: 348 },
    { top: "74%", y: 444 },
    { top: "90%", y: 540 }
  ];
  const rightNodes = [
    { top: "50%", y: 300, icon: BarChart3 }
  ];

  return (
    <section className="py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto text-center border-t border-gray-100 dark:border-zinc-800 overflow-hidden">
      <p className="text-gray-500 dark:text-zinc-400 mb-4 font-medium tracking-wide">All Servers. One View.</p>
      <h2 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-zinc-50 mb-10 tracking-tight">License Servers, Unified</h2>

      {/* Desktop Layout (Horizontal) */}
      <div className="hidden md:flex relative w-full max-w-5xl mx-auto h-[600px] xl:h-[700px] items-center justify-center">
         
        {/* Center Log Processor */}
        <div className="absolute z-20 w-36 h-36 bg-white dark:bg-[#111] rounded-[2rem] border border-gray-200 dark:border-zinc-800 shadow-2xl dark:shadow-blue-900/10 flex flex-col items-center justify-center transform transition-all hover:scale-110 hover:border-blue-400">
          <div className="w-16 h-16 bg-blue-50 dark:bg-blue-900/20 rounded-2xl flex items-center justify-center mb-2 animate-pulse">
            <Activity className="w-8 h-8 text-blue-600 dark:text-blue-400" />
          </div>
          <span className="text-xs font-bold text-gray-600 dark:text-zinc-400 tracking-wider">GRAYLOG</span>
        </div>

        {/* Left Servers */}
        {leftNodes.map((node, i) => (
          <div key={i} className="absolute z-20 left-[2%] md:left-[5%] bg-white dark:bg-[#111] w-14 h-14 rounded-2xl border border-gray-200 dark:border-zinc-800 shadow-sm flex items-center justify-center transition-all hover:border-blue-500 dark:hover:border-blue-500 hover:shadow-lg hover:shadow-blue-500/20" style={{ top: node.top, transform: 'translateY(-50%)' }}>
            <Server className="w-6 h-6 text-gray-600 dark:text-zinc-400" />
          </div>
        ))}

        {/* Right Charts */}
        {rightNodes.map((node, i) => {
          const Icon = node.icon;
          return (
             <div key={i} className="absolute z-20 right-[2%] md:right-[5%] bg-white dark:bg-[#111] w-16 h-16 rounded-2xl border border-gray-200 dark:border-zinc-800 shadow-md flex items-center justify-center transition-all hover:border-blue-500 dark:hover:border-blue-500 hover:shadow-lg hover:shadow-blue-500/20 hover:-translate-y-1" style={{ top: node.top, transform: 'translateY(-50%)' }}>
              <Icon className="w-7 h-7 text-gray-800 dark:text-zinc-200" />
             </div>
          );
        })}

        {/* Connecting Paths */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 1000 600" preserveAspectRatio="none">
           <defs>
             <linearGradient id="magic-grad" x1="0%" y1="0%" x2="100%" y2="0%">
               <stop offset="0%" stopColor="#3b82f6" stopOpacity="0" />
               <stop offset="50%" stopColor="#3b82f6" stopOpacity="1" />
               <stop offset="100%" stopColor="#3b82f6" stopOpacity="1" /> {/* Fixed right opacity to 1 so line reaches chart */}
             </linearGradient>
           </defs>
           
           {/* Left to Center Lines */}
           {leftNodes.map((node, i) => (
             <g key={`lines-${i}`}>
               <path d={`M 50 ${node.y} C 250 ${node.y}, 350 300, 500 300`} fill="none" stroke="currentColor" className="text-gray-100 dark:text-zinc-800" strokeWidth="2.5" />
               <path
                 d={`M 50 ${node.y} C 250 ${node.y}, 350 300, 500 300`}
                 fill="none"
                 stroke="#3b82f6"
                 strokeWidth="4"
                 pathLength="100"
                 strokeDasharray="20 100"
                 className="animate-pulse-path"
                 style={{ animationDelay: `${i * 0.4}s`, opacity: 0.8 }}
               />
             </g>
           ))}

           {/* Center to Right Lines */}
           {rightNodes.map((node, i) => (
             <g key={`right-${i}`}>
               <path d={`M 500 300 C 650 300, 750 ${node.y}, 950 ${node.y}`} fill="none" stroke="currentColor" className="text-gray-100 dark:text-zinc-800" strokeWidth="2.5" />
               <path
                 d={`M 500 300 C 650 300, 750 ${node.y}, 950 ${node.y}`}
                 fill="none"
                 stroke="#3b82f6" /* Direct blue color so it's clearly travelling to the right */
                 strokeWidth="4"
                 pathLength="100"
                 strokeDasharray="20 100"
                 className="animate-pulse-path"
                 style={{ animationDelay: `${i * 0.5 + 1.2}s`, opacity: 0.8 }}
               />
             </g>
           ))}
        </svg>
      </div>

      {/* Mobile Layout (Vertical) */}
      <div className="flex md:hidden flex-col items-center justify-center gap-12 relative w-full py-10 mt-10">
        {/* Servers Row */}
        <div className="flex flex-wrap justify-center gap-4 z-20">
          {[1,2,3].map((_, i) => (
            <div key={i} className="bg-white dark:bg-[#111] w-14 h-14 rounded-2xl border border-gray-200 dark:border-zinc-800 shadow-sm flex items-center justify-center">
              <Server className="w-6 h-6 text-gray-600 dark:text-zinc-400" />
            </div>
          ))}
        </div>

        {/* Center Log Processor */}
        <div className="z-20 w-32 h-32 bg-white dark:bg-[#111] rounded-[1.5rem] border border-gray-200 dark:border-zinc-800 shadow-xl flex flex-col items-center justify-center">
          <div className="w-14 h-14 bg-blue-50 dark:bg-blue-900/20 rounded-2xl flex items-center justify-center mb-2 animate-pulse">
            <Activity className="w-7 h-7 text-blue-600 dark:text-blue-400" />
          </div>
          <span className="text-[10px] font-bold text-gray-600 dark:text-zinc-400 tracking-wider">GRAYLOG</span>
        </div>

        {/* Bottom Chart */}
        <div className="z-20 bg-white dark:bg-[#111] w-14 h-14 rounded-2xl border border-gray-200 dark:border-zinc-800 shadow-sm flex items-center justify-center">
          <BarChart3 className="w-6 h-6 text-gray-800 dark:text-zinc-200" />
        </div>

        {/* Background SVG for Vertical Lines */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 300 400" preserveAspectRatio="none">
          {/* Server to Graylog lines */}
          <path d="M 90 70 C 90 120, 150 120, 150 160" fill="none" stroke="currentColor" className="text-gray-100 dark:text-zinc-800" strokeWidth="2" />
          <path d="M 150 70 C 150 120, 150 120, 150 160" fill="none" stroke="currentColor" className="text-gray-100 dark:text-zinc-800" strokeWidth="2" />
          <path d="M 210 70 C 210 120, 150 120, 150 160" fill="none" stroke="currentColor" className="text-gray-100 dark:text-zinc-800" strokeWidth="2" />

          {/* Animated Server to Graylog lines */}
          <path d="M 90 70 C 90 120, 150 120, 150 160" fill="none" stroke="#3b82f6" strokeWidth="3" pathLength="100" strokeDasharray="20 100" className="animate-pulse-path" style={{ opacity: 0.8 }} />
          <path d="M 150 70 C 150 120, 150 120, 150 160" fill="none" stroke="#3b82f6" strokeWidth="3" pathLength="100" strokeDasharray="20 100" className="animate-pulse-path" style={{ animationDelay: '0.4s', opacity: 0.8 }} />
          <path d="M 210 70 C 210 120, 150 120, 150 160" fill="none" stroke="#3b82f6" strokeWidth="3" pathLength="100" strokeDasharray="20 100" className="animate-pulse-path" style={{ animationDelay: '0.8s', opacity: 0.8 }} />

          {/* Graylog to Chart line */}
          <path d="M 150 280 L 150 330" fill="none" stroke="currentColor" className="text-gray-100 dark:text-zinc-800" strokeWidth="2" />
          <path d="M 150 280 L 150 330" fill="none" stroke="#3b82f6" strokeWidth="3" pathLength="100" strokeDasharray="20 100" className="animate-pulse-path" style={{ animationDelay: '1.2s', opacity: 0.8 }} />
        </svg>
      </div>

    </section>
  );
}
