export interface NavItem {
  title: string;
  href: string;
}

export interface RedisUser {
  Username: string;
  Hostname: string;
  Timestamp: string;
  [key: string]: any;
}

export interface RedisLicenseFeature {
  Name: string;
  Region: string;
  Feature: string;
  "Total Issued": number;
  "In Use": number;
  "Last Updated": string;
  users: RedisUser[];
}

export interface License {
  id: string;
  name: string;
  ab: string;
  type: string;
  port: number;
  sv: number;
  reg: string[];
  col: string;
  desc: string;
  expiry: string;
  status: 'Active' | 'Inactive';
  osType?: string;
  lingerTime?: string;
  dashboardUrl?: string;
}

export interface Application {
  id: number;
  name: string;
  status: 'Active' | 'Slow' | 'Not Active' | 'Auth Issue';
  latency: number | null;
  url: string;
  category: string;
  auth_type?: string;
  auth_token?: string;
  last_checked?: string;
}
