/**
 * Storage Service
 * Enterprise-grade abstraction for data persistence.
 * Currently uses localStorage but designed to be easily swapped out 
 * with a remote database interface (like Firebase, Cloud SQL, or REST APIs).
 */
import { logger } from './logger';

export class StorageService {
  /**
   * Retrieves an item from storage
   * @param key The storage key
   * @param fallback Default value if the key doesn't exist
   */
  static getItem<T>(key: string, fallback: T): T {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : fallback;
    } catch (err) {
      logger.error(`Failed to parse item from storage: ${key}`, err);
      return fallback;
    }
  }

  /**
   * Saves an item to storage
   * @param key The storage key
   * @param value The value to store
   */
  static setItem<T>(key: string, value: T): void {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      logger.debug(`Saved item to storage: ${key}`);
    } catch (err) {
      logger.error(`Failed to save item to storage: ${key}`, err);
    }
  }

  /**
   * Removes an item from storage
   * @param key The storage key
   */
  static removeItem(key: string): void {
    localStorage.removeItem(key);
    logger.debug(`Removed item from storage: ${key}`);
  }
}
