import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";

export default function Privacy() {
  return (
    <div className="min-h-screen bg-white dark:bg-[#0a0a0a] pt-24 pb-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <Link to="/" className="inline-flex items-center gap-2 text-sm font-medium text-gray-500 hover:text-gray-900 dark:text-zinc-400 dark:hover:text-zinc-100 transition-colors mb-8">
          <ArrowLeft className="w-4 h-4" />
          Back to Home
        </Link>
        
        <h1 className="text-4xl font-bold text-gray-900 dark:text-zinc-50 mb-8">Privacy Policy</h1>
        
        <div className="prose prose-blue dark:prose-invert max-w-none space-y-6 text-gray-600 dark:text-zinc-300">
          <p className="text-sm text-gray-500 dark:text-zinc-400">Last Updated: June 2026</p>
          
          <section className="space-y-4">
            <h2 className="text-2xl font-semibold text-gray-900 dark:text-zinc-100 mt-8">Data Collection Scope</h2>
            <p>
              As an internal Visteon application, OneStopPortal operates with a fundamentally restrictive data acquisition model. We do not track, profile, or sell user behavior matrices, nor does any of the data flow out of Visteon’s strictly controlled internal boundaries.
            </p>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-semibold text-gray-900 dark:text-zinc-100 mt-8">Information We Log</h2>
            <p>
              The minimal footprints retained by the system focus exclusively on access and operational continuity:
            </p>
            <ul className="list-disc pl-5 space-y-2">
              <li><strong>Authentication Logs:</strong> When triggering notifications, we verify your CDSID. This verification enforces an anti-spam limitation, but we do not store plaintext passwords.</li>
              <li><strong>License Utilization Streams:</strong> Extracted directly from backend Graylog queries. The hostnames, usernames, and check-out times exposed strictly represent shared corporate assets (licenses).</li>
            </ul>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-semibold text-gray-900 dark:text-zinc-100 mt-8">Notification Security & Anti-Spam</h2>
            <p>
               In an effort to prevent "Notification Spamming" over the Visteon network, certain workflows enforce credential confirmations via LDAP. We temporarily capture authentication queries strictly to route "Release License" reminder tokens logically. This procedure confirms authorization, records the issuance volume for internal audit logs, and safeguards against automated payload abuse.
            </p>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-semibold text-gray-900 dark:text-zinc-100 mt-8">External Disclosures</h2>
            <p>
              Under no circumstances is aggregated log data, employee identifiers (CDSID), or server cluster configurations shared with entities lacking secure VPN access to Visteon's inner architecture.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}
