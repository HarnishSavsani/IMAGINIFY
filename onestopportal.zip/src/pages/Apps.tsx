import { useState, useEffect, useRef, useMemo } from "react";
import {
  CheckCircle2,
  Snail,
  ShieldAlert,
  XCircle,
  AlertCircle,
  Tv,
  Search,
  Activity,
  PowerOff,
  Filter,
  Check,
  ChevronDown,
} from "lucide-react";
import { ApiClient } from "../lib/api";
import { useWebSocket } from "../hooks/useWebSocket";
import { useLocation, useNavigate } from "react-router-dom";
import { Application } from "../types";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";

const CustomTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white dark:bg-zinc-800 p-2 border border-gray-200 dark:border-zinc-700 rounded-lg shadow-sm text-sm">
        <p className="font-medium text-gray-900 dark:text-zinc-100">{payload[0].payload.name}</p>
        <p className="text-gray-500 dark:text-zinc-400">value : {payload[0].value}</p>
      </div>
    );
  }
  return null;
};

export default function Apps() {
  const [apps, setAppsData] = useState<Application[]>([]);


  const { lastMessage } = useWebSocket('apps');
  const location = useLocation();
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");
  const isScreenModeParam =
    new URLSearchParams(location.search).get("mode") === "screen";
  const [tvMode, setTvMode] = useState(isScreenModeParam);
  const containerRef = useRef<HTMLDivElement>(null);

  const [selectedIssues, setSelectedIssues] = useState<Set<string>>(new Set());
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const filterRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    ApiClient.getApps()
      .then((data) => {
        if (Array.isArray(data) && data.length > 0) {
          setAppsData(data);
        }
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    if (lastMessage && lastMessage.type === 'apps_status_update' && Array.isArray(lastMessage.apps)) {
      setAppsData((prevApps) => {
        const updatedMap = new Map(lastMessage.apps.map((a: any) => [a.id, a]));
        return prevApps.map((app) => {
          const fresh: any = updatedMap.get(app.id);
          if (fresh) {
            return { ...app, health_status: fresh.health_status || fresh.status, latency: fresh.latency };
          }
          return app;
        });
      });
    }
  }, [lastMessage]);






  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (
        filterRef.current &&
        !filterRef.current.contains(event.target as Node)
      ) {
        setIsFilterOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleTvModeToggle = () => {
    const newTvMode = !tvMode;
    setTvMode(newTvMode);
    if (newTvMode) {
      navigate("/apps?mode=screen");
    } else {
      navigate("/apps");
    }
  };

  useEffect(() => {
    setTvMode(isScreenModeParam);
  }, [isScreenModeParam]);

  // Status mapping
  const getStatusConfig = (statusStr: string, appItem?: any) => {
    const activeStatus = appItem?.health_status || statusStr;
    switch (activeStatus) {
      case "Active":
        return {
          icon: CheckCircle2,
          bg: "bg-emerald-100 dark:bg-emerald-900/30",
          text: "text-emerald-700 dark:text-emerald-400",
          border: "border-emerald-200 dark:border-emerald-800",
          label: "Active",
          chartColor: "#10b981",
        };
      case "Slow":
        return {
          icon: Snail,
          bg: "bg-amber-100 dark:bg-amber-900/30",
          text: "text-amber-700 dark:text-amber-400",
          border: "border-amber-200 dark:border-amber-800",
          label: "Slowness",
          chartColor: "#f59e0b",
        };
      case "Auth Issue":
        return {
          icon: ShieldAlert,
          bg: "bg-purple-100 dark:bg-purple-900/30",
          text: "text-purple-700 dark:text-purple-400",
          border: "border-purple-200 dark:border-purple-800",
          label: "Auth Issue",
          chartColor: "#8b5cf6",
        };
      case "Not Active":
      default:
        return {
          icon: PowerOff,
          bg: "bg-gray-100 dark:bg-zinc-800",
          text: "text-gray-700 dark:text-zinc-400",
          border: "border-gray-200 dark:border-zinc-700",
          label: "Not Active",
          chartColor: "#6b7280",
        };
    }
  };

  const ISSUE_TYPES = [
    "Active",
    "Slow",
    "Auth Issue",
    "Not Active",
  ];

  // Filter & Sort
  const filteredApps = useMemo(() => {
    return apps.filter((app) => {
      if (app.status && app.status === 'Inactive') return false;
      const matchSearch =
        app.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (app.category &&
          app.category.toLowerCase().includes(searchTerm.toLowerCase()));

      const liveHealth = app.health_status || app.status;
      const matchIssue =
        selectedIssues.size === 0 || selectedIssues.has(liveHealth);
      return matchSearch && matchIssue;
    }).sort((a, b) => a.name.localeCompare(b.name));
  }, [searchTerm, selectedIssues, apps]);

  const appsWithIssues = filteredApps.filter((a) => (a.health_status || a.status) !== "Active");
  const activeAppList = filteredApps.filter((a) => (a.health_status || a.status) === "Active");

  // Stats
  const activeAppsOnly = apps.filter(a => a.status !== 'Inactive');
  const totalApps = activeAppsOnly.length;
  const activeAppCount = activeAppsOnly.filter((a) => (a.health_status || a.status) === "Active").length;
  const issueAppCount = totalApps - activeAppCount;

  const chartData = useMemo(() => {
    const counts: Record<string, number> = {
      Active: 0,
      Slow: 0,
      "Auth Issue": 0,
      "Not Active": 0,
    };
    apps.forEach((app) => {
      if (app.status !== 'Inactive') {
        const hs = app.health_status || app.status;
        counts[hs] = (counts[hs] || 0) + 1;
      }
    });
    return Object.entries(counts).map(([name, value]) => ({
      name,
      value,
      color: getStatusConfig(name).chartColor,
    }));
  }, [apps]);


  const toggleIssueFilter = (issue: string) => {
    const next = new Set(selectedIssues);
    if (next.has(issue)) next.delete(issue);
    else next.add(issue);
    setSelectedIssues(next);
  };

  // Keyboard shortcut for Esc
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape" && tvMode) {
        setTvMode(false);
        navigate("/apps");
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [tvMode, navigate]);

  // Auto-scroll logic for TV mode
  useEffect(() => {
    if (!tvMode || !containerRef.current) return;

    const scroller = containerRef.current;
    let scrollPos = 0;

    const interval = setInterval(() => {
      if (scroller) {
        scrollPos += 1.25;
        if (scrollPos >= scroller.scrollHeight - scroller.clientHeight) {
          scrollPos = 0;
          scroller.scrollTo({ top: 0, behavior: "smooth" });
          return;
        }
        scroller.scrollTo({ top: scrollPos });
      }
    }, 40);

    return () => clearInterval(interval);
  }, [tvMode]);

  const tvModeClasses = tvMode
    ? "fixed inset-0 z-[100] bg-[#f8fafc] dark:bg-[#0a0a0a] overflow-y-auto px-8 py-8"
    : "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pt-24";

  return (
    <div className={tvModeClasses} ref={containerRef}>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-zinc-100 flex items-center gap-2 tracking-tight">
            <Activity className="w-8 h-8 text-blue-600" /> Application Health
          </h1>
          <p className="text-gray-500 dark:text-zinc-400 mt-1">
            Real-time status monitoring for all connected applications
          </p>
        </div>
        <div className="flex items-center gap-3 w-full md:w-auto">
          {!tvMode && (
            <div className="relative flex-1 md:w-64 border border-gray-200 dark:border-zinc-800 rounded-lg bg-white dark:bg-zinc-900">
              <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-4 py-2 bg-transparent text-sm focus:outline-none text-gray-900 dark:text-zinc-100"
              />
            </div>
          )}
          {!tvMode && (
            <div className="relative" ref={filterRef}>
              <button
                onClick={() => setIsFilterOpen(!isFilterOpen)}
                className="flex items-center justify-center gap-2 px-3 py-2 bg-white dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 text-gray-700 dark:text-zinc-300 rounded-lg text-sm font-medium transition-colors hover:bg-gray-50 dark:hover:bg-zinc-800"
              >
                <Filter className="w-4 h-4" /> Issue Type
                {selectedIssues.size > 0 && (
                  <span className="ml-1 bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-400 px-1.5 py-0.5 rounded text-xs">
                    {selectedIssues.size}
                  </span>
                )}
                <ChevronDown className="w-4 h-4 opacity-70" />
              </button>

              {isFilterOpen && (
                <div className="absolute right-0 top-full mt-1 w-56 z-50 bg-white dark:bg-[#111] border border-gray-200 dark:border-zinc-800 rounded-lg shadow-lg overflow-hidden">
                  <div className="p-1">
                    {ISSUE_TYPES.map((opt) => {
                      const isSelected = selectedIssues.has(opt);
                      const conf = getStatusConfig(opt);
                      const Icon = conf.icon;
                      return (
                        <button
                          key={opt}
                          onClick={() => toggleIssueFilter(opt)}
                          className="w-full flex items-center justify-between px-2 py-1.5 text-sm rounded-md hover:bg-gray-100 dark:hover:bg-zinc-800 text-gray-700 dark:text-zinc-300 transition-colors"
                        >
                          <div className="flex items-center gap-2">
                            <div
                              className={`w-4 h-4 border rounded flex items-center justify-center transition-colors ${isSelected ? "bg-blue-600 border-blue-600" : "border-gray-300 dark:border-zinc-600 bg-white dark:bg-zinc-900"}`}
                            >
                              {isSelected && (
                                <Check className="w-3 h-3 text-white" />
                              )}
                            </div>
                            <span className="flex items-center gap-1.5 font-normal">
                              <Icon className="w-3 h-3" />
                              {conf.label}
                            </span>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                  {selectedIssues.size > 0 && (
                    <div className="p-2 border-t border-gray-100 dark:border-zinc-800 text-center">
                      <button
                        onClick={() => setSelectedIssues(new Set())}
                        className="text-xs text-blue-600 font-medium"
                      >
                        Clear filters
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
          <button
            title={tvMode ? "Exit Screen Mode" : "Enter Screen Mode"}
            onClick={handleTvModeToggle}
            className={`group relative flex items-center justify-center p-2 rounded-lg transition-colors ${tvMode ? "bg-red-600 hover:bg-red-700 text-white" : "bg-white dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 text-gray-700 dark:text-zinc-300 hover:bg-gray-50 dark:hover:bg-zinc-800"}`}
          >
            <Tv className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* KPIs & Chart */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
        <div className="bg-white dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 rounded-xl p-5 shadow-sm flex flex-col justify-between">
          <p className="text-sm font-medium text-gray-500 dark:text-zinc-400 uppercase tracking-wider mb-2">
            Monitored Apps
          </p>
          <div className="text-4xl font-bold text-gray-900 dark:text-zinc-100">
            {totalApps}
          </div>
        </div>
        <div className="bg-emerald-50 dark:bg-emerald-900/10 border border-emerald-100 dark:border-emerald-900/30 rounded-xl p-5 shadow-sm flex flex-col justify-between">
          <p className="text-sm font-medium text-emerald-700 dark:text-emerald-400 uppercase tracking-wider mb-2 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4" /> Healthy
          </p>
          <div className="flex items-baseline gap-2">
            <span className="text-4xl font-bold text-emerald-700 dark:text-emerald-400">
              {activeAppCount}
            </span>
            <span className="text-sm text-emerald-600 dark:text-emerald-500 font-medium">
              ({Math.round((activeAppCount / totalApps) * 100)}%)
            </span>
          </div>
        </div>
        <div className="bg-red-50 dark:bg-red-900/10 border border-red-100 dark:border-red-900/30 rounded-xl p-5 shadow-sm flex flex-col justify-between">
          <p className="text-sm font-medium text-red-700 dark:text-red-400 uppercase tracking-wider mb-2 flex items-center gap-2">
            <AlertCircle className="w-4 h-4" /> Attention Required
          </p>
          <div className="flex items-baseline gap-2">
            <span className="text-4xl font-bold text-red-700 dark:text-red-400">
              {issueAppCount}
            </span>
          </div>
        </div>
        <div className="bg-white dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 rounded-xl p-4 shadow-sm h-[120px] flex flex-col justify-center">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={chartData}
              margin={{ top: 0, right: 0, left: 0, bottom: 0 }}
            >
              <Tooltip
                cursor={{ fill: "transparent" }}
                content={<CustomTooltip />}
              />
              <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Problematic Apps */}
      {appsWithIssues.length > 0 && (
        <div className="mb-12">
          <h2 className="text-xl font-bold text-gray-900 dark:text-zinc-100 mb-4 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
            Attention Required
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {appsWithIssues.map((app) => {
              const conf = getStatusConfig(app.status, app);

              const Icon = conf.icon;
              return (
                <a
                  href={app.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  key={app.id}
                  className={`flex flex-col bg-white dark:bg-zinc-900 border rounded-xl overflow-hidden shadow-sm transition-all hover:shadow-md ${conf.border}`}
                >
                  <div
                    className={`p-4 border-b ${conf.border} flex justify-between items-start gap-3 bg-gradient-to-b from-${conf.bg.split(" ")[0]} to-transparent`}
                  >
                    <div className="font-semibold text-gray-900 dark:text-zinc-100 truncate">
                      {app.name}
                    </div>
                    <div
                      className={`p-2 rounded-lg ${conf.bg} ${conf.text} shrink-0`}
                    >
                      <Icon className="w-4 h-4" />
                    </div>
                  </div>
                  <div className="p-4 flex-1 flex flex-col justify-between">
                    <div className="flex items-center gap-2 flex-wrap mb-3">
                      <span
                        className={`px-2.5 py-1 rounded-md text-xs font-semibold uppercase tracking-wide border ${conf.bg} ${conf.text} border-transparent`}
                      >
                        {conf.label}
                      </span>
                      {app.category && (
                        <span className="px-2 py-0.5 rounded text-[10px] font-medium bg-gray-100 text-gray-600 dark:bg-zinc-800 dark:text-zinc-400 border border-gray-200 dark:border-zinc-700">
                          {app.category}
                        </span>
                      )}
                    </div>
                    {app.latency !== null && (
                      <div className="text-xs text-gray-500 dark:text-zinc-400 flex items-center gap-1.5 mt-auto">
                        <Activity className="w-3 h-3" /> Latency:{" "}
                        <span className="font-mono text-gray-900 dark:text-zinc-300">
                          {app.latency}ms
                        </span>
                      </div>
                    )}
                  </div>
                </a>
              );
            })}
          </div>
        </div>
      )}

      {/* Active Apps */}
      {activeAppList.length > 0 && (
        <div>
          <h2 className="text-xl font-bold text-gray-900 dark:text-zinc-100 mb-4 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 pt-1"></span>
            Healthy Services
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {activeAppList.map((app) => {
              const conf = getStatusConfig(app.status, app);
              const Icon = conf.icon;

              return (
                <a
                  href={app.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  key={app.id}
                  className="flex border border-gray-200 dark:border-zinc-800 rounded-xl bg-white dark:bg-zinc-900 p-4 items-center gap-4 shadow-sm hover:shadow-md transition-shadow cursor-pointer"
                >
                  <div
                    className={`p-2.5 rounded-full ${conf.bg} ${conf.text} shrink-0`}
                  >
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold text-sm text-gray-900 dark:text-zinc-100 truncate flex items-center gap-2">
                      {app.name}
                      {app.category && (
                        <span className="px-1.5 py-0.5 rounded text-[10px] font-medium bg-gray-100 text-gray-500 dark:bg-zinc-800 dark:text-zinc-400 border border-transparent">
                          {app.category}
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-gray-500 dark:text-zinc-400 flex items-center gap-1.5 mt-1">
                      <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></span>{" "}
                      Active
                      {app.latency !== null && (
                        <span className="text-gray-400 dark:text-zinc-500 font-mono ml-2">
                          {app.latency}ms
                        </span>
                      )}
                    </div>
                  </div>
                </a>
              );
            })}
          </div>
        </div>
      )}

      {filteredApps.length === 0 && (
        <div className="text-center py-20 text-gray-500 dark:text-zinc-400">
          No applications match your search.
        </div>
      )}
    </div>
  );
}
