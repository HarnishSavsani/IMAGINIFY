import { useState, FormEvent } from "react";
import { Search, Plus, Trash2, X, AlertCircle } from "lucide-react";
import { toast } from "sonner";

interface AdminUser {
  id: number;
  cdsid: string;
  addedAt: string;
}

const INITIAL_ADMINS: AdminUser[] = [
  { id: 1, cdsid: "hatul", addedAt: "2026-01-10T10:00:00Z" },
  { id: 2, cdsid: "jdoe", addedAt: "2026-03-05T14:30:00Z" },
  { id: 3, cdsid: "asmith", addedAt: "2026-05-20T09:15:00Z" },
];

export default function Admins() {
  const [admins, setAdmins] = useState<AdminUser[]>(INITIAL_ADMINS);
  const [searchTerm, setSearchTerm] = useState("");
  
  // Modal state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [selectedAdmin, setSelectedAdmin] = useState<AdminUser | null>(null);
  const [newCdsid, setNewCdsid] = useState("");

  const filteredAdmins = admins.filter(a => a.cdsid.toLowerCase().includes(searchTerm.toLowerCase()));

  const openAddModal = () => {
    setNewCdsid("");
    setIsAddModalOpen(true);
  };

  const handleAdd = (e: FormEvent) => {
    e.preventDefault();
    if (!newCdsid.trim()) return;

    if (admins.some(a => a.cdsid.toLowerCase() === newCdsid.toLowerCase())) {
      toast.error(`User ${newCdsid} is already an admin.`);
      return;
    }

    const newAdmin: AdminUser = {
      id: Date.now(),
      cdsid: newCdsid.toLowerCase(),
      addedAt: new Date().toISOString()
    };
    
    setAdmins([...admins, newAdmin]);
    toast.success(`User ${newAdmin.cdsid} added as admin successfully.`);
    setIsAddModalOpen(false);
  };

  const openDeleteModal = (admin: AdminUser) => {
    setSelectedAdmin(admin);
    setIsDeleteModalOpen(true);
  };

  const handleDelete = () => {
    if (selectedAdmin) {
      setAdmins(admins.filter(a => a.id !== selectedAdmin.id));
      toast.success(`Admin ${selectedAdmin.cdsid} removed successfully.`);
      setIsDeleteModalOpen(false);
    }
  };

  return (
    <div className="max-w-[1000px] mx-auto flex flex-col h-full space-y-4">
      <div className="flex justify-between items-center">
         <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-zinc-100">Administrators</h1>
          <p className="text-sm text-gray-500 dark:text-zinc-400 mt-1">Manage portal administrators</p>
         </div>
      </div>

      <div className="bg-white dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 rounded-xl shadow-sm flex flex-col">
        <div className="p-4 border-b border-gray-200 dark:border-zinc-800 flex flex-col sm:flex-row items-center font-sans justify-between">
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input 
              type="text" 
              placeholder="Search by CDSID..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 border border-gray-200 dark:border-zinc-700 bg-white dark:bg-zinc-900 rounded-lg text-sm focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none text-gray-900 dark:text-zinc-100 transition-all shadow-sm"
            />
          </div>
          
          <div className="flex items-center gap-3 w-full sm:w-auto mt-4 sm:mt-0">
            <button onClick={openAddModal} className="flex items-center justify-center h-9 gap-1.5 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-medium transition-colors shadow-sm">
              <Plus className="w-4 h-4" /> Add Admin
            </button>
          </div>
        </div>

        <div className="overflow-x-auto min-h-[300px]">
          <table className="w-full text-left text-sm text-gray-700 dark:text-zinc-300 whitespace-nowrap font-sans">
            <thead className="bg-[#f9fafb] dark:bg-zinc-900/50">
              <tr className="border-b border-gray-200 dark:border-zinc-800 transition-colors">
                <th className="px-4 py-3 text-gray-900 dark:text-zinc-100 font-medium w-1/2">CDSID</th>
                <th className="px-4 py-3 text-gray-900 dark:text-zinc-100 font-medium">Added On</th>
                <th className="px-4 py-3 font-medium text-right text-gray-900 dark:text-zinc-100">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-zinc-800/80">
              {filteredAdmins.map((admin) => (
                  <tr key={admin.id} className="transition-colors hover:bg-gray-50/50 dark:hover:bg-zinc-800/30 group">
                    <td className="px-4 py-3 align-middle font-medium text-gray-900 dark:text-zinc-100">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900/30 text-blue-600 flex items-center justify-center font-bold text-sm uppercase">
                            {admin.cdsid.substring(0, 2)}
                        </div>
                        {admin.cdsid}
                      </div>
                    </td>
                    <td className="px-4 py-3 align-middle text-sm text-gray-600 dark:text-zinc-400">
                      {new Date(admin.addedAt).toLocaleDateString()}
                    </td>
                    <td className="px-4 py-3 align-middle text-right">
                      <div className="flex justify-end gap-1 opacity-100 transition-opacity">
                        <button onClick={() => openDeleteModal(admin)} className="p-1.5 text-gray-400 hover:text-red-600 rounded transition-colors" title="Delete">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
              ))}
              {filteredAdmins.length === 0 && (
                <tr>
                  <td colSpan={3} className="px-4 py-12 text-center text-gray-500 dark:text-zinc-400">
                    No administrators found matching your search.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {isAddModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="bg-white dark:bg-zinc-900 rounded-xl shadow-xl w-full max-w-sm border border-gray-100 dark:border-zinc-800 overflow-hidden font-sans">
            <div className="flex justify-between items-center p-4 border-b border-gray-100 dark:border-zinc-800">
              <h3 className="font-semibold text-lg text-gray-900 dark:text-zinc-100">
                Add Administrator
              </h3>
              <button type="button" onClick={() => setIsAddModalOpen(false)} className="text-gray-400 hover:text-gray-600 dark:hover:text-zinc-300">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleAdd} className="p-4 space-y-4">
              <div>
                <label className="block text-xs font-medium text-gray-700 dark:text-zinc-300 mb-1">CDSID *</label>
                <input required autoFocus value={newCdsid} onChange={e => setNewCdsid(e.target.value)} className="w-full px-3 py-2 text-sm border border-gray-300 dark:border-zinc-700 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none bg-transparent dark:text-zinc-100" placeholder="e.g. jdoe2" />
              </div>

              <div className="pt-4 flex justify-end gap-3 border-t border-gray-100 dark:border-zinc-800">
                <button type="button" onClick={() => setIsAddModalOpen(false)} className="px-4 py-2 border border-gray-300 dark:border-zinc-700 text-gray-700 dark:text-zinc-300 rounded-lg text-sm font-medium hover:bg-gray-50 dark:hover:bg-zinc-800 transition-colors">
                  Cancel
                </button>
                <button type="submit" disabled={!newCdsid.trim()} className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-sm">
                  Add Admin
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {isDeleteModalOpen && selectedAdmin && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="bg-white dark:bg-zinc-900 rounded-xl shadow-xl w-full max-w-sm border border-gray-100 dark:border-zinc-800 overflow-hidden font-sans">
             <div className="p-6 text-center">
               <div className="w-12 h-12 rounded-full bg-red-100 dark:bg-red-900/30 text-red-600 flex items-center justify-center mx-auto mb-4">
                 <AlertCircle className="w-6 h-6" />
               </div>
               <h3 className="text-lg font-semibold text-gray-900 dark:text-zinc-100 mb-2">Remove Admin?</h3>
               <p className="text-sm text-gray-500 dark:text-zinc-400">
                 Are you sure you want to remove <span className="font-semibold text-gray-900 dark:text-zinc-300">{selectedAdmin.cdsid}</span>'s admin privileges?
               </p>
             </div>
             <div className="bg-gray-50 dark:bg-zinc-800/50 p-4 flex justify-end gap-3 rounded-b-xl border-t border-gray-100 dark:border-zinc-800">
                <button onClick={() => setIsDeleteModalOpen(false)} className="px-4 py-2 bg-white dark:bg-zinc-800 border border-gray-300 dark:border-zinc-700 text-gray-700 dark:text-zinc-300 rounded-lg text-sm font-medium hover:bg-gray-50 dark:hover:bg-zinc-700 transition-colors shadow-sm">
                  Cancel
                </button>
                <button onClick={handleDelete} className="px-4 py-2 bg-red-600 text-white rounded-lg text-sm font-medium hover:bg-red-700 transition-colors shadow-sm">
                  Remove
                </button>
             </div>
          </div>
        </div>
      )}
    </div>
  );
}
