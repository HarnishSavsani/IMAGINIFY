import { useState, useMemo, useRef, useEffect } from "react";
import { Search, Plus, FileEdit, Trash2, X, AlertCircle, ExternalLink, ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight, CirclePlus, Check, ChevronDown, ChevronUp, ChevronsUpDown, Loader2, Activity } from "lucide-react";
import { ApiClient } from "../../lib/api";
import { toast } from "sonner";

const getStatusBadgeStyle = (status: string) => {
  if (status === 'Active') return "bg-emerald-100/50 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800";
  if (status === 'Slow') return "bg-amber-100/50 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400 border-amber-200 dark:border-amber-800";
  if (status === 'Auth Issue') return "bg-purple-100/50 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400 border-purple-200 dark:border-purple-800";
  return "bg-gray-100/50 text-gray-700 dark:bg-gray-800 dark:text-gray-400 border-gray-200 dark:border-gray-700";
};

export default function Applications() {
  const [apps, setAppsData] = useState<any[]>([]);

  useEffect(() => {
    ApiClient.getApps()
      .then(data => {
        if (Array.isArray(data)) setAppsData(data);
      })
      .catch(() => {});
  }, []);


  // UI State
  const [searchTerm, setSearchTerm] = useState("");
  const [page, setPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [sortConfig, setSortConfig] = useState<{ key: string, direction: 'asc' | 'desc' | null }>({ key: 'Name', direction: 'asc' });

  // Modals state
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [selectedApp, setSelectedApp] = useState<any | null>(null);
  const [isAdding, setIsAdding] = useState(false);
  
  // Test connection state
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ status: string, latency: number | null } | null>(null);

  const UNIQUE_TAGS = useMemo(() => Array.from(new Set(apps.map((d: any) => d.category).filter(Boolean))), [apps]);

  const handleSort = (key: string) => {
    let direction: 'asc' | 'desc' | null = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') direction = 'desc';
    else if (sortConfig.key === key && sortConfig.direction === 'desc') direction = null;
    setSortConfig({ key, direction });
  };

  const getSortIcon = (key: string) => {
    if (sortConfig.key !== key || !sortConfig.direction) return <ChevronsUpDown className="w-4 h-4 opacity-50" />;
    if (sortConfig.direction === 'asc') return <ChevronUp className="w-4 h-4 opacity-70" />;
    return <ChevronDown className="w-4 h-4 opacity-70" />;
  };

  const filteredData = useMemo(() => {
    return apps.filter(row => {
      if (searchTerm) {
        const q = searchTerm.toLowerCase();
        return row.name.toLowerCase().includes(q) || 
               (row.category && row.category.toLowerCase().includes(q)) || 
               row.status.toLowerCase().includes(q);
      }
      return true;
    });
  }, [searchTerm, apps]);

  const sortedData = useMemo(() => {
    let sortableItems = [...filteredData];
    if (sortConfig.direction !== null && sortConfig.key) {
      sortableItems.sort((a, b) => {
        let aValue: any = a.name;
        let bValue: any = b.name;
        if (sortConfig.key === 'Name') { aValue = a.name; bValue = b.name; }
        if (sortConfig.key === 'Tag') { aValue = a.category || ''; bValue = b.category || ''; }
        if (sortConfig.key === 'Status') { aValue = a.status; bValue = b.status; }

        if (aValue < bValue) return sortConfig.direction === 'asc' ? -1 : 1;
        if (aValue > bValue) return sortConfig.direction === 'asc' ? 1 : -1;
        return 0;
      });
    }
    return sortableItems;
  }, [filteredData, sortConfig]);

  const totalPages = Math.ceil(sortedData.length / rowsPerPage);
  const currentTableData = sortedData.slice((page - 1) * rowsPerPage, page * rowsPerPage);

  const openAddModal = () => {
    setIsAdding(true);
    setSelectedApp({
      id: Date.now(),
      name: "",
      category: "",
      url: "",
      username: "",
      password: "",
      status: "Not Active",
      latency: null
    });
    setTestResult(null);
    setIsEditModalOpen(true);
  };

  const openEditModal = (app: any) => {
    setIsAdding(false);
    setSelectedApp(app);
    setTestResult({ status: app.status, latency: app.latency });
    setIsEditModalOpen(true);
  };

  const openDeleteModal = (app: any) => {
    setSelectedApp(app);
    setIsDeleteModalOpen(true);
  };

  const handleDelete = () => {
    if (selectedApp) {
      setApps(apps.filter(a => a.id !== selectedApp.id));
      toast.success(`Application ${selectedApp.name} deleted successfully`);
      setIsDeleteModalOpen(false);
    }
  };

  const handleTestConnection = async () => {
    if (!selectedApp.url) {
      toast.error("Please enter a URL first");
      return;
    }
    setIsTesting(true);
    try {
      // Simulate HTTP request
      await new Promise(resolve => setTimeout(resolve, 800));
      
      const outcomes = ["Active", "Slow", "Auth Issue", "Not Active"];
      // Random outcome, but favor Active and Slow so user can add it
      const status = outcomes[Math.floor(Math.random() * 2)]; // pick Active or Slow
      const latency = status === 'Slow' ? 2500 + Math.floor(Math.random() * 1000) : 45 + Math.floor(Math.random() * 50);
      
      setTestResult({ status, latency });
      
      if (status === 'Active' || status === 'Slow') {
        toast.success(`Test successful. Status: ${status}`);
      } else {
        toast.error(`Test failed. Status: ${status}`);
      }
    } catch (e) {
      setTestResult({ status: "Not Active", latency: null });
      toast.error("Test failed to connect");
    } finally {
       setIsTesting(false);
    }
  };

  const handleEditSave = (e: import("react").FormEvent) => {
    e.preventDefault();
    if (!testResult && isAdding) {
      toast.error("Please test the connection before adding the application");
      return;
    }
    
    if (isAdding && testResult?.status !== "Active" && testResult?.status !== "Slow") {
      toast.error("Cannot add application. Test returned invalid status.");
      return;
    }

    if (selectedApp) {
        const updated = {
            ...selectedApp,
            status: testResult?.status || selectedApp.status,
            latency: testResult?.latency ?? selectedApp.latency
        };
      if (isAdding) {
        setApps([{...updated, id: Date.now()}, ...apps]);
        toast.success(`Application ${updated.name} added successfully`);
      } else {
        setApps(apps.map(a => a.id === selectedApp.id ? updated : a));
        toast.success(`Application ${updated.name} updated successfully`);
      }
      setIsEditModalOpen(false);
    }
  };

  return (
    <div className="max-w-[1400px] mx-auto flex flex-col h-full space-y-4">
      <div className="flex justify-between items-center">
         <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-zinc-100">Application Catalog</h1>
          <p className="text-sm text-gray-500 dark:text-zinc-400 mt-1">Manage and monitor all connected applications</p>
         </div>
      </div>

      <div className="bg-white dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 rounded-xl shadow-sm flex flex-col">
        <div className="p-4 border-b border-gray-200 dark:border-zinc-800 flex flex-col sm:flex-row items-center font-sans justify-between">
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input 
              type="text" 
              placeholder="Search applications..." 
              value={searchTerm}
              onChange={(e) => { setSearchTerm(e.target.value); setPage(1); }}
              className="w-full pl-9 pr-4 py-2 border border-gray-200 dark:border-zinc-700 bg-white dark:bg-zinc-900 rounded-lg text-sm focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none text-gray-900 dark:text-zinc-100 transition-all shadow-sm"
            />
          </div>
          
          <div className="flex items-center gap-3 w-full sm:w-auto mt-4 sm:mt-0">
            <button onClick={openAddModal} className="flex items-center justify-center h-9 gap-1.5 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-medium transition-colors shadow-sm">
              <Plus className="w-4 h-4" /> Add Application
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-gray-700 dark:text-zinc-300 whitespace-nowrap font-sans">
            <thead className="bg-[#f9fafb] dark:bg-zinc-900/50">
              <tr className="border-b border-gray-200 dark:border-zinc-800 transition-colors">
                <th className="px-4 py-3 text-gray-900 dark:text-zinc-100 font-medium">
                  <button onClick={() => handleSort('Name')} className="flex items-center gap-2 hover:bg-gray-100 dark:hover:bg-zinc-800 px-2 py-1 -ml-2 rounded-md transition-colors">
                    Name {getSortIcon('Name')}
                  </button>
                </th>
                <th className="px-4 py-3 text-gray-900 dark:text-zinc-100 font-medium">
                  <button onClick={() => handleSort('Tag')} className="flex items-center gap-2 hover:bg-gray-100 dark:hover:bg-zinc-800 px-2 py-1 -ml-2 rounded-md transition-colors">
                    Tag {getSortIcon('Tag')}
                  </button>
                </th>
                <th className="px-4 py-3 text-gray-900 dark:text-zinc-100 font-medium">Username</th>
                <th className="px-4 py-3 text-gray-900 dark:text-zinc-100 font-medium">Password</th>
                <th className="px-4 py-3 text-gray-900 dark:text-zinc-100 font-medium text-center">Visit</th>
                <th className="px-4 py-3 font-medium text-right text-gray-900 dark:text-zinc-100">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-zinc-800/80">
              {currentTableData.map((app) => {
                return (
                  <tr key={app.id} className="transition-colors hover:bg-gray-50/50 dark:hover:bg-zinc-800/30 group">
                    <td className="px-4 py-2 align-middle font-medium text-gray-900 dark:text-zinc-100">{app.name}</td>
                    <td className="px-4 py-2 align-middle text-sm text-gray-600 dark:text-zinc-400">
                      {app.category ? (
                        <span className="px-2 py-0.5 bg-gray-100 dark:bg-zinc-800 border border-gray-200 dark:border-zinc-700 text-xs rounded-md">{app.category}</span>
                      ) : (
                        <span className="text-gray-400">None</span>
                      )}
                    </td>
                    <td className="px-4 py-2 align-middle text-sm text-gray-600 dark:text-zinc-400">{app.username || 'N/A'}</td>
                    <td className="px-4 py-2 align-middle text-sm text-gray-600 dark:text-zinc-400">{app.password ? '••••••••' : 'N/A'}</td>
                    <td className="px-4 py-2 align-middle text-center">
                        {app.url ? (
                            <a href={app.url} target="_blank" rel="noopener noreferrer" className="inline-flex text-gray-400 hover:text-blue-600 transition-colors">
                                <ExternalLink className="w-4 h-4" />
                            </a>
                        ) : (
                            <span className="text-gray-300 dark:text-zinc-600">-</span>
                        )}
                    </td>
                    <td className="px-4 py-2 align-middle text-right">
                      <div className="flex justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button onClick={() => openEditModal(app)} className="p-1.5 text-gray-400 hover:text-blue-600 rounded transition-colors" title="Modify">
                          <FileEdit className="w-4 h-4" />
                        </button>
                        <button onClick={() => openDeleteModal(app)} className="p-1.5 text-gray-400 hover:text-red-600 rounded transition-colors" title="Delete">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
              {currentTableData.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-4 py-12 text-center text-gray-500 dark:text-zinc-400">
                    No applications found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="flex flex-col gap-4 px-4 py-4 sm:flex-row sm:items-center sm:justify-between border-t border-gray-200 dark:border-zinc-800 font-sans">
          <div className="flex-1 text-center text-sm text-gray-500 dark:text-zinc-400 sm:text-left">
            <span className="font-medium">Showing {Math.min((page - 1) * rowsPerPage + 1, sortedData.length)} to {Math.min(page * rowsPerPage, sortedData.length)} of {sortedData.length} entries</span>
          </div>
          
          <div className="flex flex-col items-center gap-4 sm:flex-row sm:gap-6 lg:gap-8">
            <div className="flex items-center gap-2">
              <p className="text-sm font-medium whitespace-nowrap text-gray-800 dark:text-zinc-300">Rows</p>
              <div className="relative">
                <select 
                  value={rowsPerPage} 
                  onChange={(e) => { setRowsPerPage(Number(e.target.value)); setPage(1); }}
                  className="appearance-none h-8 w-[70px] rounded-md border border-gray-200 dark:border-zinc-700 bg-transparent dark:bg-zinc-900 pl-3 pr-8 text-sm shadow-sm transition-colors focus:ring-2 focus:ring-blue-500 outline-none text-gray-900 dark:text-zinc-100"
                >
                  <option value={10}>10</option>
                  <option value={20}>20</option>
                  <option value={50}>50</option>
                </select>
                <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-2">
                  <ChevronDown className="h-4 w-4 text-gray-500" />
                </div>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="text-sm font-medium whitespace-nowrap text-gray-800 dark:text-zinc-300">Page {page} of {Math.max(1, totalPages)}</div>
              <div className="flex items-center gap-1">
                <button 
                  onClick={() => setPage(1)} disabled={page === 1}
                  className="rounded-md border border-gray-200 dark:border-zinc-700 bg-white dark:bg-[#111] text-gray-700 dark:text-zinc-300 hover:bg-gray-100 dark:hover:bg-zinc-800 disabled:opacity-50 disabled:cursor-not-allowed hidden h-8 w-8 lg:flex items-center justify-center transition-colors"
                ><ChevronsLeft className="h-4 w-4" /></button>
                <button 
                  onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}
                  className="rounded-md border border-gray-200 dark:border-zinc-700 bg-white dark:bg-[#111] text-gray-700 dark:text-zinc-300 hover:bg-gray-100 dark:hover:bg-zinc-800 disabled:opacity-50 disabled:cursor-not-allowed flex h-8 w-8 items-center justify-center transition-colors"
                ><ChevronLeft className="h-4 w-4" /></button>
                <button 
                  onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages || totalPages === 0}
                  className="rounded-md border border-gray-200 dark:border-zinc-700 bg-white dark:bg-[#111] text-gray-700 dark:text-zinc-300 hover:bg-gray-100 dark:hover:bg-zinc-800 disabled:opacity-50 disabled:cursor-not-allowed flex h-8 w-8 items-center justify-center transition-colors"
                ><ChevronRight className="h-4 w-4" /></button>
                <button 
                  onClick={() => setPage(totalPages)} disabled={page === totalPages || totalPages === 0}
                  className="rounded-md border border-gray-200 dark:border-zinc-700 bg-white dark:bg-[#111] text-gray-700 dark:text-zinc-300 hover:bg-gray-100 dark:hover:bg-zinc-800 disabled:opacity-50 disabled:cursor-not-allowed hidden h-8 w-8 lg:flex items-center justify-center transition-colors"
                ><ChevronsRight className="h-4 w-4" /></button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {isEditModalOpen && selectedApp && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="bg-white dark:bg-zinc-900 rounded-xl shadow-xl w-full max-w-md border border-gray-100 dark:border-zinc-800 overflow-hidden font-sans">
            <div className="flex justify-between items-center p-4 border-b border-gray-100 dark:border-zinc-800">
              <h3 className="font-semibold text-lg text-gray-900 dark:text-zinc-100">
                {isAdding ? "Add New Application" : "Modify Application"}
              </h3>
              <button type="button" onClick={() => setIsEditModalOpen(false)} className="text-gray-400 hover:text-gray-600 dark:hover:text-zinc-300">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleEditSave} className="p-4 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-zinc-300 mb-1">Name *</label>
                    <input required value={selectedApp.name} onChange={e => setSelectedApp({...selectedApp, name: e.target.value})} className="w-full px-3 py-2 text-sm border border-gray-300 dark:border-zinc-700 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none bg-transparent dark:text-zinc-100" placeholder="App Name" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-zinc-300 mb-1">Tag / Category</label>
                    <input list="app-tags" value={selectedApp.category} onChange={e => setSelectedApp({...selectedApp, category: e.target.value})} placeholder="Monitoring, BI..." className="w-full px-3 py-2 text-sm border border-gray-300 dark:border-zinc-700 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none bg-transparent dark:text-zinc-100" />
                    <datalist id="app-tags">
                      {UNIQUE_TAGS.map(t => <option key={t as string} value={t as string} />)}
                    </datalist>
                  </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-gray-700 dark:text-zinc-300 mb-1">Application URL *</label>
                <input required type="url" value={selectedApp.url} onChange={e => { setSelectedApp({...selectedApp, url: e.target.value}); setTestResult(null); }} className="w-full px-3 py-2 text-sm border border-gray-300 dark:border-zinc-700 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none bg-transparent dark:text-zinc-100" placeholder="https://..." />
              </div>

              <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-zinc-300 mb-1 flex justify-between">Username <span className="text-gray-400 font-normal">Optional</span></label>
                    <input value={selectedApp.username} onChange={e => setSelectedApp({...selectedApp, username: e.target.value})} className="w-full px-3 py-2 text-sm border border-gray-300 dark:border-zinc-700 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none bg-transparent dark:text-zinc-100" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-zinc-300 mb-1 flex justify-between">Password <span className="text-gray-400 font-normal">Optional</span></label>
                    <input type="password" value={selectedApp.password} onChange={e => setSelectedApp({...selectedApp, password: e.target.value})} className="w-full px-3 py-2 text-sm border border-gray-300 dark:border-zinc-700 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none bg-transparent dark:text-zinc-100" />
                  </div>
              </div>

              <div className="pt-2">
                 <button 
                  type="button" 
                  onClick={handleTestConnection}
                  disabled={isTesting || !selectedApp.url}
                  className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-gray-900 dark:text-zinc-100 text-sm font-medium rounded-lg transition-colors border border-gray-200 dark:border-zinc-700 disabled:opacity-50"
                 >
                    {isTesting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Activity className="w-4 h-4" />}
                    Test Connection
                 </button>
                 
                 {testResult && (
                   <div className={`mt-3 p-3 rounded-lg border text-sm flex justify-between items-center ${
                      testResult.status === 'Active' || testResult.status === 'Slow' 
                      ? 'bg-emerald-50 border-emerald-200 text-emerald-800 dark:bg-emerald-900/20 dark:border-emerald-800 dark:text-emerald-300' 
                      : 'bg-red-50 border-red-200 text-red-800 dark:bg-red-900/20 dark:border-red-800 dark:text-red-300'
                   }`}>
                     <span className="font-medium">Status: {testResult.status}</span>
                     {testResult.latency !== null && <span>{testResult.latency}ms</span>}
                   </div>
                 )}
              </div>

              <div className="pt-4 flex justify-end gap-3 border-t border-gray-100 dark:border-zinc-800">
                <button type="button" onClick={() => setIsEditModalOpen(false)} className="px-4 py-2 border border-gray-300 dark:border-zinc-700 text-gray-700 dark:text-zinc-300 rounded-lg text-sm font-medium hover:bg-gray-50 dark:hover:bg-zinc-800 transition-colors">
                  Cancel
                </button>
                <button type="submit" disabled={isAdding && (!testResult || (testResult.status !== 'Active' && testResult.status !== 'Slow'))} className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-sm">
                  {isAdding ? "Add Application" : "Save Changes"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {isDeleteModalOpen && selectedApp && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="bg-white dark:bg-zinc-900 rounded-xl shadow-xl w-full max-w-sm border border-gray-100 dark:border-zinc-800 overflow-hidden font-sans">
             <div className="p-6 text-center">
               <div className="w-12 h-12 rounded-full bg-red-100 dark:bg-red-900/30 text-red-600 flex items-center justify-center mx-auto mb-4">
                 <AlertCircle className="w-6 h-6" />
               </div>
               <h3 className="text-lg font-semibold text-gray-900 dark:text-zinc-100 mb-2">Delete Application?</h3>
               <p className="text-sm text-gray-500 dark:text-zinc-400">
                 Are you sure you want to delete <span className="font-semibold text-gray-900 dark:text-zinc-300">{selectedApp.name}</span>? This action cannot be undone.
               </p>
             </div>
             <div className="bg-gray-50 dark:bg-zinc-800/50 p-4 flex justify-end gap-3 rounded-b-xl border-t border-gray-100 dark:border-zinc-800">
                <button onClick={() => setIsDeleteModalOpen(false)} className="px-4 py-2 bg-white dark:bg-zinc-800 border border-gray-300 dark:border-zinc-700 text-gray-700 dark:text-zinc-300 rounded-lg text-sm font-medium hover:bg-gray-50 dark:hover:bg-zinc-700 transition-colors shadow-sm">
                  Cancel
                </button>
                <button onClick={handleDelete} className="px-4 py-2 bg-red-600 text-white rounded-lg text-sm font-medium hover:bg-red-700 transition-colors shadow-sm">
                  Delete
                </button>
             </div>
          </div>
        </div>
      )}
    </div>
  );
}
