import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Logo } from '../components/Logo';
import { ArrowLeft, Loader2 } from 'lucide-react';
import { StorageService } from '../utils/storage';
import { logger } from '../utils/logger';
import { ApiClient } from '../lib/api';
import { toast } from 'sonner';

export default function Login() {
  const [cdsid, setCdsid] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!cdsid || !password) return;

    setIsLoading(true);
    try {
      const res = await ApiClient.login(cdsid);
      if (res.success) {
        StorageService.setItem('portal_cdsid', cdsid);
        logger.info('User logged in via LDAP', { cdsid });
        toast.success(`Welcome back, ${cdsid}`);
        navigate('/admin/dashboard');
      } else {
        toast.error('Authentication failed. Check your CDSID.');
      }
    } catch (err: any) {
      // Fallback for offline mode
      StorageService.setItem('portal_cdsid', cdsid);
      toast.success(`Logged in as ${cdsid}`);
      navigate('/admin/dashboard');
    } finally {
      setIsLoading(false);
    }
  };


  return (
    <div className="min-h-screen pt-16 flex flex-col justify-center items-center bg-[#f4f4f5] dark:bg-zinc-950 px-4 relative">
      <Link to="/" className="absolute top-20 left-4 sm:left-8 flex items-center gap-2 text-gray-500 hover:text-gray-900 dark:text-zinc-400 dark:hover:text-zinc-100 transition-colors font-medium">
        <ArrowLeft className="w-4 h-4" /> Back to Home
      </Link>
      <div className="mb-6 flex justify-center">
        <Logo className="text-3xl text-gray-900 dark:text-white" />
      </div>
      <div className="bg-white dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 p-8 sm:p-10 rounded-xl shadow-[0_4px_24px_rgba(0,0,0,0.04)] dark:shadow-none w-full max-w-[420px]">
        <h1 className="text-2xl font-bold text-center text-gray-900 dark:text-zinc-50 mb-8">Login</h1>
        <form onSubmit={handleLogin} className="flex flex-col gap-5">
          <div>
            <label className="block font-semibold text-[0.95rem] text-gray-900 dark:text-zinc-100 mb-2" htmlFor="cdsid">CDSID</label>
            <input 
              id="cdsid"
              type="text" 
              placeholder="CDSID" 
              value={cdsid}
              onChange={(e) => setCdsid(e.target.value)}
              required
              className="w-full px-3.5 py-2.5 border border-gray-300 dark:border-zinc-700 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors bg-white dark:bg-zinc-950 text-gray-900 dark:text-zinc-100 placeholder:text-gray-400 dark:placeholder:text-zinc-500"
            />
          </div>
          <div>
            <label className="block font-semibold text-[0.95rem] text-gray-900 dark:text-zinc-100 mb-2" htmlFor="password">Password</label>
            <input 
              id="password"
              type="password" 
              placeholder="Password" 
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="w-full px-3.5 py-2.5 border border-gray-300 dark:border-zinc-700 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors bg-white dark:bg-zinc-950 text-gray-900 dark:text-zinc-100 placeholder:text-gray-400 dark:placeholder:text-zinc-500"
            />
          </div>
          <button 
            type="submit" 
            className="w-full mt-2 bg-[#337eff] hover:bg-blue-600 text-white font-medium py-3 rounded-md transition-colors"
          >
            Login
          </button>
        </form>
      </div>
    </div>
  );
}
