import { Link } from 'react-router-dom';
import { Home, ZapOff } from 'lucide-react';

export default function NotFound() {
  return (
    <div className="min-h-[80vh] flex flex-col items-center justify-center p-4 overflow-hidden">
      <div className="w-full max-w-4xl text-center p-8">
        
        {/* Abstract Illustration Container */}
        <div className="relative w-full max-w-2xl mx-auto mb-8 flex items-center justify-center">
          <img src="/404.svg" alt="404 Not Found" className="w-full max-w-md mx-auto" />
        </div>

        <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-zinc-50 mb-4 tracking-tight uppercase">
          Sorry! Page Not Found
        </h2>
        <p className="text-gray-500 dark:text-zinc-400 mb-10 max-w-lg mx-auto text-lg leading-relaxed">
          Looks like the connection is broken. The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.
        </p>
        <Link 
          to="/" 
          className="inline-flex items-center justify-center gap-2 h-14 px-8 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-lg font-semibold transition-all shadow-md hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0 active:shadow-sm"
        >
          <Home className="w-5 h-5" />
          Reconnect to Dashboard
        </Link>
      </div>
    </div>
  );
}
