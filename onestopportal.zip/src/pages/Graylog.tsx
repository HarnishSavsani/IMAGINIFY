import { Server, Activity, Filter, Database, LayoutDashboard } from "lucide-react";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

export default function Graylog() {
  const steps = [
    {
      title: "Data Retrieval",
      description: "Extract data directly from your servers utilizing lightweight Graylog sidecars and Beats agents for efficient log shipping.",
      icon: Server,
    },
    {
      title: "Dedicated Streams",
      description: "Route incoming log messages into dedicated streams to categorize and manage data flows efficiently from the get-go.",
      icon: Activity,
    },
    {
      title: "Data Transformation",
      description: "Process each stream through custom pipelines, extracting, parsing, and transforming raw logs into structured, actionable data.",
      icon: Filter,
    },
    {
      title: "OpenSearch Storage",
      description: "Store the filtered, extracted data reliably in OpenSearch, enabling lightning-fast indexing and querying.",
      icon: Database,
    },
    {
      title: "Dashboards & Analytics",
      description: "Aggregate and organize this OpenSearch extract to build comprehensive dashboards and alerts for deep actionable insights.",
      icon: LayoutDashboard,
    },
  ];

  return (
    <div className="bg-white dark:bg-[#0a0a0a] min-h-screen font-sans selection:bg-blue-100 dark:selection:bg-blue-900/40 flex flex-col">
      <Navbar />

      <main className="flex-grow pt-32 pb-24">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-12 gap-12 lg:gap-24">
            
            {/* Left Column - Sticky Header */}
            <div className="lg:col-span-5 lg:sticky lg:top-32 self-start">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
                <span className="text-blue-600 dark:text-blue-500 block mb-2">Complete Data</span>
                <span className="text-blue-600 dark:text-blue-500 block mb-2">Extraction</span>
                <span className="text-gray-500 dark:text-zinc-400 block">Process</span>
              </h1>
              <p className="text-lg text-gray-600 dark:text-zinc-400 max-w-md">
                Understanding the pipeline from raw server logs to actionable dashboard analytics using Graylog and OpenSearch.
              </p>
            </div>

            {/* Right Column - Steps */}
            <div className="lg:col-span-7 flex flex-col pt-8 lg:pt-0">
              {steps.map((step, index) => {
                const Icon = step.icon;
                return (
                  <div 
                    key={index} 
                    className={`flex items-start gap-8 py-10 ${
                      index !== steps.length - 1 ? 'border-b border-gray-100 dark:border-zinc-800' : ''
                    }`}
                  >
                    <div className="flex-shrink-0 mt-1">
                      <Icon className="w-8 h-8 text-gray-900 dark:text-white" strokeWidth={1.5} />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-blue-600 dark:text-blue-500 mb-3">
                        {step.title}
                      </h3>
                      <p className="text-base text-gray-600 dark:text-zinc-400 leading-relaxed max-w-lg">
                        {step.description}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>

          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
