import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";

export default function Terms() {
  return (
    <div className="min-h-screen bg-white dark:bg-[#0a0a0a] pt-24 pb-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <Link to="/" className="inline-flex items-center gap-2 text-sm font-medium text-gray-500 hover:text-gray-900 dark:text-zinc-400 dark:hover:text-zinc-100 transition-colors mb-8">
          <ArrowLeft className="w-4 h-4" />
          Back to Home
        </Link>
        
        <h1 className="text-4xl font-bold text-gray-900 dark:text-zinc-50 mb-8">Terms and Conditions</h1>
        
        <div className="prose prose-blue dark:prose-invert max-w-none space-y-6 text-gray-600 dark:text-zinc-300">
          <p className="text-sm text-gray-500 dark:text-zinc-400">Last Updated: June 2026</p>
          
          <section className="space-y-4">
            <h2 className="text-2xl font-semibold text-gray-900 dark:text-zinc-100 mt-8">1. Internal Use Only</h2>
            <p>
              OneStopPortal is an internal tool developed strictly for Visteon employees and authorized contractors. The application, inclusive of all its features, dashboard data, and analytical capabilities, must not be shared, demonstrated, or otherwise distributed to individuals external to the Visteon corporate network.
            </p>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-semibold text-gray-900 dark:text-zinc-100 mt-8">2. Proper Use of Telemetry Data</h2>
            <p>
              The license utilization data, server health metrics, and Graylog analytics accessible via this portal represent confidential operational data. You agree to use this information solely for the purposes of capacity planning, license optimization, and internal IT administration. Attempting to misuse or misrepresent the metrics provided could lead to disciplinary actions as per Visteon's standard IT security policies.
            </p>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-semibold text-gray-900 dark:text-zinc-100 mt-8">3. Communication and Notification Spam</h2>
            <p>
              The platform features the ability to dispatch automated release notifications to users currently occupying specific licenses (e.g., users occupying CST, CAD, or compiler seats). To mitigate spam and prevent unauthorized broadcasts, authentication (via your Visteon CDSID and network credentials) is required before notifications are queued. 
            </p>
            <p>
              By using this functionality, you agree not to repeatedly harass peers or dispatch notifications without valid operational necessity. We monitor notification volumes to identify and address abuse continuously.
            </p>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-semibold text-gray-900 dark:text-zinc-100 mt-8">4. Service Availability</h2>
            <p>
              While OneStopPortal is designed with high availability in mind, pulling real-time metrics strictly every 60 seconds, downtime may occasionally occur due to underlying Graylog maintenance or network segment interruptions. Service availability is provided on a "best-effort" internal service level agreement (SLA).
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}
