import express from 'express';
import http from 'http';
import cors from 'cors';
import { config } from './config/index.js';
import { initDatabase } from './database/connection.js';
import { RedisService } from './services/redis.service.js';
import { WebSocketHandler } from './websocket/handler.js';
import { RedisPoller } from './workers/redisPoller.js';
import { AppMonitorWorker } from './workers/appMonitor.js';
import routes from './routes/index.js';


const app = express();

// Middleware
app.use(cors({ origin: config.CORS_ORIGIN }));
app.use(express.json());

// Healthcheck endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// API Routes
app.use('/api', routes);

import path from 'path';
// Serve static client assets in production
if (config.NODE_ENV === 'production') {
  const distPath = path.resolve(process.cwd(), 'dist');
  app.use(express.static(distPath));
  app.get('*', (req, res, next) => {
    if (req.path.startsWith('/api') || req.path.startsWith('/ws')) {
      return next();
    }
    res.sendFile(path.join(distPath, 'index.html'));
  });
}


// Create HTTP server
const server = http.createServer(app);

// Initialize Infrastructure
async function bootstrap() {
  console.log('🚀 Starting OneStopPortal Enterprise Server...');

  // 1. Initialize SQLite
  initDatabase();


  // 2. Initialize Redis Connection
  RedisService.init();

  // 3. Initialize WebSocket Server
  WebSocketHandler.init(server);

  // 4. Start Background Workers
  RedisPoller.start();
  AppMonitorWorker.start();

  // 5. Listen
  server.listen(config.PORT, () => {
    console.log(`================================═════════════════════`);
    console.log(`🟢 OneStopPortal API Server running on port ${config.PORT}`);
    console.log(`⚡ WebSocket endpoint available at ws://localhost:${config.PORT}/ws`);
    console.log(`================================═════════════════════`);
  });
}

bootstrap().catch((err) => {
  console.error('❌ Server startup error:', err);
});
