import { RedisService } from '../services/redis.service';
import { WebSocketHandler } from '../websocket/handler';
import { config } from '../config';

export class RedisPoller {
  private static lastState: Record<string, string> = {};
  private static isPolling = false;
  private static timer: NodeJS.Timeout | null = null;

  static start() {
    console.log(`⏱️ Starting 1-second Redis Poller Worker (Interval: ${config.REDIS_POLL_INTERVAL_MS}ms)`);
    
    this.timer = setInterval(async () => {
      if (this.isPolling) return; // Prevent overlapping runs
      this.isPolling = true;

      try {
        const rawStrings = await RedisService.getLiveLicenseRawStrings();
        const currentData: Record<string, any> = {};
        const diffs: Record<string, any> = {};
        let changeCount = 0;

        // Group changes by license group
        const groupDiffs: Record<string, any[]> = {};

        Object.entries(rawStrings).forEach(([key, strVal]) => {
          try {
            const val = JSON.parse(strVal);
            currentData[key] = val;

            if (this.lastState[key] !== strVal) {
              this.lastState[key] = strVal;
              diffs[key] = val;
              changeCount++;

              const groupName = val.Name ? val.Name.toLowerCase() : 'unknown';
              if (!groupDiffs[groupName]) {
                groupDiffs[groupName] = [];
              }
              groupDiffs[groupName].push(val);
            }
          } catch {}
        });

        if (changeCount > 0) {
          // Broadcast full diff to 'all' subscribers
          WebSocketHandler.broadcast({
            type: 'redis_update',
            timestamp: new Date().toISOString(),
            changedCount: changeCount,
            data: currentData,
          }, 'all');

          // Broadcast group-specific diffs to room subscribers
          Object.entries(groupDiffs).forEach(([group, items]) => {
            WebSocketHandler.broadcast({
              type: 'license_group_update',
              group: group,
              timestamp: new Date().toISOString(),
              items: items,
              fullGroupData: Object.values(currentData).filter(
                (item: any) => item && item.Name && item.Name.toLowerCase() === group
              ),
            }, group);
          });
        }
      } catch (err) {
        console.error('Error in RedisPoller execution:', err);
      } finally {
        this.isPolling = false;
      }
    }, config.REDIS_POLL_INTERVAL_MS);
  }

  static stop() {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }
}
