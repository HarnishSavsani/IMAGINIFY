import { Request, Response } from 'express';
import { DbService } from '../services/db.service';

export class AdminController {
  static getAdmins(req: Request, res: Response) {
    try {
      const admins = DbService.getAllAdmins();
      res.json(admins);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  }

  static createAdmin(req: Request, res: Response) {
    try {
      const { cdsid, email, role } = req.body;
      if (!cdsid || !email) {
        return res.status(400).json({ error: 'CDSID and email are required' });
      }
      const admin = DbService.createAdmin(cdsid, email, role || 'admin');
      res.status(201).json(admin);
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  }

  static deleteAdmin(req: Request, res: Response) {
    try {
      const success = DbService.deleteAdmin(Number(req.params.id));
      if (!success) {
        return res.status(404).json({ error: 'Admin not found' });
      }
      res.json({ message: 'Admin removed successfully' });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  }
}
