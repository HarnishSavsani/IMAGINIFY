import { Request, Response } from 'express';
import { LdapService } from '../services/ldap.service';
import { MailService } from '../services/mail.service';
import { DbService } from '../services/db.service';

export class NotifyController {
  static async sendReleaseRequest(req: Request, res: Response) {
    try {
      const {
        senderCdsid,
        senderEmail,
        targetUsername,
        targetEmail,
        licenseName,
        feature,
        hostname,
        checkoutTimestamp,
      } = req.body;

      if (!senderCdsid || !targetUsername || !licenseName || !feature) {
        return res.status(400).json({ error: 'Missing required parameters (senderCdsid, targetUsername, licenseName, feature)' });
      }

      const verifiedSenderEmail = (senderEmail || `${senderCdsid}@visteon.com`).toLowerCase().trim();

      // Enforce @visteon.com domain restriction
      if (!verifiedSenderEmail.endsWith('@visteon.com')) {
        return res.status(400).json({ error: 'Unauthorized email domain: Only @visteon.com email addresses are permitted to send emails.' });
      }

      // 1. Anti-spam Rate Limiting Check (Max 1 email per target/feature per sender every 30 mins)
      const isSpam = DbService.isRecentNotificationSent(senderCdsid, targetUsername, feature, 30);
      if (isSpam) {
        return res.status(429).json({
          error: `Anti-Spam Protection: A release request was already sent to ${targetUsername} for ${feature} in the last 30 minutes. Please wait before requesting again.`,
        });
      }

      // 2. LDAP User Verification (Binds CDSID + Email to Visteon AD)
      const ldapRes = await LdapService.verifyUser(senderCdsid, verifiedSenderEmail);
      if (!ldapRes.success) {
        return res.status(403).json({ error: `LDAP Verification Failed: ${ldapRes.message}` });
      }

      // 3. Dispatch SMTP HTML Mail
      const mailRes = await MailService.sendReleaseRequest({
        senderCdsid,
        senderEmail: verifiedSenderEmail,
        targetUsername,
        targetEmail: targetEmail || `${targetUsername}@visteon.com`,
        licenseName,
        feature,
        hostname: hostname || 'Unknown Host',
        checkoutTimestamp: checkoutTimestamp || new Date().toLocaleString(),
      });

      if (!mailRes.success) {
        DbService.logNotification(senderCdsid, targetUsername, licenseName, feature, 'FAILED');
        return res.status(500).json({ error: mailRes.message });
      }

      // 4. Log successful audit record
      DbService.logNotification(senderCdsid, targetUsername, licenseName, feature, 'SUCCESS');

      res.json({
        success: true,
        message: `Notification email successfully sent to ${targetUsername}`,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  }

  static async sendContactForm(req: Request, res: Response) {
    try {
      const { cdsid, email, message } = req.body;
      if (!cdsid || !email || !message) {
        return res.status(400).json({ error: 'Please provide CDSID, email, and message.' });
      }

      const formattedEmail = email.toLowerCase().trim();

      // Enforce @visteon.com domain restriction
      if (!formattedEmail.endsWith('@visteon.com')) {
        return res.status(400).json({ error: 'Unauthorized email domain: Only @visteon.com email addresses are permitted to submit messages.' });
      }

      const mailRes = await MailService.sendContactFormMessage({ cdsid, email: formattedEmail, message });
      res.json({ success: true, message: mailRes.message || 'Message sent successfully' });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  }
}
