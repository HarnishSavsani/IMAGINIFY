import { Request, Response } from 'express';
import { LdapService } from '../services/ldap.service';

export class AuthController {
  static async login(req: Request, res: Response) {
    try {
      const { cdsid, email, password } = req.body;

      if (!cdsid) {
        return res.status(400).json({ error: 'CDSID is required' });
      }

      const targetEmail = email || `${cdsid}@visteon.com`;

      // Perform LDAP Directory verification
      const ldapResult = await LdapService.verifyUser(cdsid, targetEmail);
      if (!ldapResult.success) {
        return res.status(401).json({ error: ldapResult.message });
      }

      res.json({
        success: true,
        message: 'Login successful',
        user: {
          cdsid,
          email: targetEmail,
        },
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  }
}
