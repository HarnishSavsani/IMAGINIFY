import { Request, Response } from 'express';
import { DbService } from '../services/db.service';
import { RedisService } from '../services/redis.service';

export class LicenseController {
  static getAllLicenses(req: Request, res: Response) {
    try {
      const licenses = DbService.getAllLicenses();
      res.json(licenses);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  }

  static getLicenseById(req: Request, res: Response) {
    try {
      const license = DbService.getLicenseById(req.params.id);
      if (!license) {
        return res.status(404).json({ error: 'License not found' });
      }
      res.json(license);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  }

  static async getLiveUsage(req: Request, res: Response) {
    try {
      const { name } = req.params;
      const usage = await RedisService.getLicenseUsage(name);
      res.json(usage);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  }

  static createLicense(req: Request, res: Response) {
    try {
      const created = DbService.createLicense(req.body);
      res.status(201).json(created);
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  }

  static updateLicense(req: Request, res: Response) {
    try {
      const updated = DbService.updateLicense(req.params.id, req.body);
      if (!updated) {
        return res.status(404).json({ error: 'License not found' });
      }
      res.json(updated);
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  }

  static deleteLicense(req: Request, res: Response) {
    try {
      const success = DbService.deleteLicense(req.params.id);
      if (!success) {
        return res.status(404).json({ error: 'License not found' });
      }
      res.json({ message: 'License deleted successfully' });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  }
}
