import { WebSocketServer, WebSocket } from 'ws';
import { Server } from 'http';
import { config } from '../config';

interface ClientSocket extends WebSocket {
  isAlive?: boolean;
  subscriptions?: Set<string>;
}

export class WebSocketHandler {
  private static wss: WebSocketServer | null = null;
  private static clients: Set<ClientSocket> = new Set();

  static init(server: Server) {
    this.wss = new WebSocketServer({ server, path: '/ws' });

    this.wss.on('connection', (ws: ClientSocket) => {
      ws.isAlive = true;
      ws.subscriptions = new Set();
      this.clients.add(ws);

      console.log(`🔌 Client connected to WebSocket. Total clients: ${this.clients.size}`);

      ws.on('pong', () => {
        ws.isAlive = true;
      });

      ws.on('message', (message: string) => {
        try {
          const data = JSON.parse(message.toString());
          if (data.type === 'subscribe' && data.room) {
            ws.subscriptions?.add(data.room.toLowerCase());
            console.log(`📡 Client subscribed to room: ${data.room}`);
            ws.send(JSON.stringify({ type: 'subscribed', room: data.room }));
          } else if (data.type === 'unsubscribe' && data.room) {
            ws.subscriptions?.delete(data.room.toLowerCase());
            ws.send(JSON.stringify({ type: 'unsubscribed', room: data.room }));
          }
        } catch (e) {
          console.error('Invalid WebSocket message received:', message);
        }
      });

      ws.on('close', () => {
        this.clients.delete(ws);
        console.log(`🔌 Client disconnected. Total clients: ${this.clients.size}`);
      });
    });

    // Heartbeat ping/pong interval
    setInterval(() => {
      this.clients.forEach((ws) => {
        if (ws.isAlive === false) {
          this.clients.delete(ws);
          return ws.terminate();
        }
        ws.isAlive = false;
        ws.ping();
      });
    }, config.WS_HEARTBEAT_INTERVAL_MS);

    console.log('✅ WebSocket server handler attached to HTTP server at /ws');
  }

  /**
   * Broadcasts message payload to all connected clients or specific room
   */
  static broadcast(payload: any, room?: string) {
    if (!this.wss) return;

    const message = JSON.stringify(payload);
    const targetRoom = room?.toLowerCase();

    this.clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        if (!targetRoom || client.subscriptions?.has(targetRoom) || client.subscriptions?.has('all')) {
          client.send(message);
        }
      }
    });
  }
}
