import { WebSocketServer, WebSocket } from 'ws';
import { Server } from 'http';
import { config } from '../config';

interface ClientSocket extends WebSocket {
  isAlive?: boolean;
  subscriptions?: Set<string>;
}

export class WebSocketHandler {
  private static wss: WebSocketServer | null = null;
  private static clients: Set<ClientSocket> = new Set();
  private static roomSubscriptions: Map<string, Set<ClientSocket>> = new Map();

  static init(server: Server) {
    this.wss = new WebSocketServer({ server, path: '/ws' });

    this.wss.on('connection', (ws: ClientSocket) => {
      ws.isAlive = true;
      ws.subscriptions = new Set();
      this.clients.add(ws);

      console.log(`🔌 Client connected to WebSocket. Total clients: ${this.clients.size}`);

      ws.on('pong', () => {
        ws.isAlive = true;
      });

      ws.on('message', (message: string) => {
        try {
          const data = JSON.parse(message.toString());
          if (data.type === 'subscribe' && data.room) {
            const roomLower = data.room.toLowerCase();
            ws.subscriptions?.add(roomLower);
            
            if (!this.roomSubscriptions.has(roomLower)) {
              this.roomSubscriptions.set(roomLower, new Set());
            }
            this.roomSubscriptions.get(roomLower)!.add(ws);
            
            console.log(`📡 Client subscribed to room: ${data.room}`);
            ws.send(JSON.stringify({ type: 'subscribed', room: data.room }));
          } else if (data.type === 'unsubscribe' && data.room) {
            const roomLower = data.room.toLowerCase();
            ws.subscriptions?.delete(roomLower);
            this.roomSubscriptions.get(roomLower)?.delete(ws);
            
            ws.send(JSON.stringify({ type: 'unsubscribed', room: data.room }));
          }
        } catch (e) {
          console.error('Invalid WebSocket message received:', message);
        }
      });

      ws.on('close', () => {
        this.removeClient(ws);
        console.log(`🔌 Client disconnected. Total clients: ${this.clients.size}`);
      });
    });

    // Heartbeat ping/pong interval
    setInterval(() => {
      this.clients.forEach((ws) => {
        if (ws.isAlive === false) {
          this.removeClient(ws);
          return ws.terminate();
        }
        ws.isAlive = false;
        ws.ping();
      });
    }, config.WS_HEARTBEAT_INTERVAL_MS);

    console.log('✅ WebSocket server handler attached to HTTP server at /ws');
  }

  private static removeClient(ws: ClientSocket) {
    this.clients.delete(ws);
    ws.subscriptions?.forEach((room) => {
      this.roomSubscriptions.get(room)?.delete(ws);
    });
  }

  /**
   * Broadcasts message payload to all connected clients or specific room
   */
  static broadcast(payload: any, room?: string) {
    if (!this.wss) return;

    const message = JSON.stringify(payload);
    const targetRoom = room?.toLowerCase();

    if (targetRoom) {
      const sent = new Set<ClientSocket>();

      // Send to users subscribed directly to the room
      const subscribers = this.roomSubscriptions.get(targetRoom);
      subscribers?.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(message);
          sent.add(client);
        }
      });

      // Send to users subscribed to 'all' (if not already sent)
      const allSubscribers = this.roomSubscriptions.get('all');
      allSubscribers?.forEach((client) => {
        if (client.readyState === WebSocket.OPEN && !sent.has(client)) {
          client.send(message);
          sent.add(client);
        }
      });
    } else {
      // General broadcast to everyone
      this.clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(message);
        }
      });
    }
  }
}
