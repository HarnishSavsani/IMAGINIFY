import { Request, Response, NextFunction } from 'express';

interface RateLimitRecord {
  count: number;
  resetTime: number;
}

const ipRequestMap = new Map<string, RateLimitRecord>();

/**
 * Lightweight, zero-dependency, in-memory IP rate limiter middleware.
 * Fits perfectly for single-container architectures.
 * 
 * @param maxRequests Maximum requests allowed within the window
 * @param windowMs Time window in milliseconds
 */
export const rateLimiter = (maxRequests: number, windowMs: number) => {
  return (req: Request, res: Response, next: NextFunction) => {
    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const now = Date.now();

    let record = ipRequestMap.get(ip);

    if (!record || now > record.resetTime) {
      record = {
        count: 1,
        resetTime: now + windowMs,
      };
      ipRequestMap.set(ip, record);
      return next();
    }

    record.count++;

    if (record.count > maxRequests) {
      console.warn(`[Rate Limiter Blocked] IP: ${ip} exceeded limit of ${maxRequests} requests per ${windowMs}ms.`);
      return res.status(429).json({
        error: 'Too many requests. Please wait a moment and try again.',
      });
    }

    next();
  };
};
