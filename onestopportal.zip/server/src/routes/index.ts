import { Router } from 'express';
import licenseRoutes from './license.routes';
import appRoutes from './app.routes';
import authRoutes from './auth.routes';
import notifyRoutes from './notify.routes';
import adminRoutes from './admin.routes';

const router = Router();

router.use('/licenses', licenseRoutes);
router.use('/apps', appRoutes);
router.use('/auth', authRoutes);
router.use('/notify', notifyRoutes);
router.use('/admin', adminRoutes);

export default router;
