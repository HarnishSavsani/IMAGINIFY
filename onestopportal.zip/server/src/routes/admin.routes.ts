import { Router } from 'express';
import { AdminController } from '../controllers/admin.controller';

const router = Router();

router.get('/', AdminController.getAdmins);
router.post('/', AdminController.createAdmin);
router.delete('/:id', AdminController.deleteAdmin);

export default router;
