import { Router } from 'express';
import { NotifyController } from '../controllers/notify.controller';
import { rateLimiter } from '../middleware/rateLimiter';

const router = Router();

// Limit release requests to 3 per 10 minutes per IP
router.post('/release-request', rateLimiter(3, 10 * 60 * 1000), NotifyController.sendReleaseRequest);

// Limit contact forms to 5 per 10 minutes per IP
router.post('/contact', rateLimiter(5, 10 * 60 * 1000), NotifyController.sendContactForm);

export default router;
