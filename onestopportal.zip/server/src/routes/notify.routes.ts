import { Router } from 'express';
import { NotifyController } from '../controllers/notify.controller';

const router = Router();

router.post('/release-request', NotifyController.sendReleaseRequest);
router.post('/contact', NotifyController.sendContactForm);

export default router;
