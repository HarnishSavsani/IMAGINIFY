import { Router } from 'express';
import { AppController } from '../controllers/app.controller';

const router = Router();

router.get('/', AppController.getAllApps);
router.post('/', AppController.createApp);
router.delete('/:id', AppController.deleteApp);
router.post('/check', AppController.triggerHealthCheck);

export default router;
