import { Router } from 'express';
import { LicenseController } from '../controllers/license.controller';

const router = Router();

router.get('/', LicenseController.getAllLicenses);
router.get('/:id', LicenseController.getLicenseById);
router.get('/usage/:name', LicenseController.getLiveUsage);
router.post('/', LicenseController.createLicense);
router.put('/:id', LicenseController.updateLicense);
router.delete('/:id', LicenseController.deleteLicense);

export default router;
