import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';
import { config } from '../config';

const dbPath = path.resolve(process.cwd(), config.SQLITE_DB_PATH);
const dirPath = path.dirname(dbPath);

if (!fs.existsSync(dirPath)) {
  fs.mkdirSync(dirPath, { recursive: true });
}

export const db = new Database(dbPath);

// Enable WAL mode for high performance concurrency
db.pragma('journal_mode = WAL');

// Checkpoint WAL to flush all data into main portal.sqlite file
export function checkpointDatabase() {
  try {
    db.pragma('wal_checkpoint(TRUNCATE)');
  } catch (e) {}
}

export function initDatabase() {
  // Create tables if they do not exist
  db.exec(`
    CREATE TABLE IF NOT EXISTS licenses (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      ab TEXT NOT NULL,
      type TEXT NOT NULL,
      port INTEGER NOT NULL,
      sv INTEGER NOT NULL,
      reg TEXT NOT NULL,
      col TEXT NOT NULL,
      desc TEXT NOT NULL,
      expiry TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Active',
      osType TEXT,
      lingerTime TEXT,
      dashboardUrl TEXT
    );

    CREATE TABLE IF NOT EXISTS applications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Active',
      health_status TEXT DEFAULT 'Active',
      latency INTEGER,
      url TEXT NOT NULL,
      category TEXT NOT NULL,
      auth_type TEXT DEFAULT 'none',
      auth_token TEXT,
      last_checked TEXT
    );

    CREATE TABLE IF NOT EXISTS admins (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      cdsid TEXT NOT NULL UNIQUE,
      email TEXT NOT NULL,
      role TEXT DEFAULT 'admin',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS notification_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sender_cdsid TEXT NOT NULL,
      target_username TEXT NOT NULL,
      license_name TEXT NOT NULL,
      feature TEXT NOT NULL,
      sent_at TEXT NOT NULL,
      status TEXT NOT NULL
    );
  `);

  // Migration for health_status column if missing in older schema
  try {
    db.exec(`ALTER TABLE applications ADD COLUMN health_status TEXT DEFAULT 'Active'`);
  } catch (e) {}

  // Ensure default superadmin exists
  try {
    const adminCount = (db.prepare('SELECT COUNT(*) as count FROM admins').get() as any).count;
    if (adminCount === 0) {
      db.prepare(`
        INSERT INTO admins (cdsid, email, role, created_at)
        VALUES ('admin', 'admin@visteon.com', 'superadmin', datetime('now'))
      `).run();
      console.log('🌱 Seeded default superadmin account.');
    }
  } catch (e) {}

  checkpointDatabase();
  console.log('✅ SQLite Database initialized at:', dbPath);
}

// Flush WAL on exit so portal.sqlite is always 100% self-contained
process.on('exit', () => checkpointDatabase());
process.on('SIGINT', () => { checkpointDatabase(); process.exit(0); });
process.on('SIGTERM', () => { checkpointDatabase(); process.exit(0); });
