import { Redis } from 'ioredis';
import fs from 'fs';
import path from 'path';
import { config } from '../config';


export class RedisService {
  private static client: Redis | null = null;
  private static isConnected = false;
  private static mockSnapshots: any[] = [];
  private static mockSnapshotIndex = 0;

  static init() {
    try {
      this.client = new Redis({
        host: config.REDIS_HOST,
        port: config.REDIS_PORT,
        password: config.REDIS_PASSWORD || undefined,
        retryStrategy: (times) => {
          if (times > 3) {
            console.warn('⚠️ Redis connection retries exceeded. Falling back to local snapshot simulation.');
            return null; // Stop retrying
          }
          return Math.min(times * 500, 2000);
        },
        maxRetriesPerRequest: 1,
        lazyConnect: true,
      });

      this.client.connect().then(() => {
        this.isConnected = true;
        console.log(`✅ Connected to Redis at ${config.REDIS_HOST}:${config.REDIS_PORT}`);
      }).catch((err) => {
        console.warn('⚠️ Redis not available on port ' + config.REDIS_PORT + '. Using fallback snapshot engine.');
        this.initMockEngine();
      });

      this.client.on('error', (err) => {
        if (this.isConnected) {
          console.error('Redis Client Error:', err.message);
          this.isConnected = false;
        }
      });
    } catch (e) {
      this.initMockEngine();
    }
  }

  private static initMockEngine() {
    const snapshotDir = path.resolve(process.cwd(), 'redis test/real_data_snapshots');
    if (fs.existsSync(snapshotDir)) {
      const files = fs.readdirSync(snapshotDir).filter(f => f.endsWith('.json')).sort();
      this.mockSnapshots = files.map(file => {
        try {
          return JSON.parse(fs.readFileSync(path.join(snapshotDir, file), 'utf-8'));
        } catch {
          return null;
        }
      }).filter(Boolean);
      console.log(`ℹ️ Loaded ${this.mockSnapshots.length} real-data Redis snapshots for fallback simulation.`);
    }
  }

  /**
   * Fetches all raw live license strings from Redis (for event-loop optimized polling)
   */
  static async getLiveLicenseRawStrings(): Promise<Record<string, string>> {
    if (this.isConnected && this.client) {
      try {
        const dataMap: Record<string, string> = {};
        let cursor = '0';
        const pattern = `${config.REDIS_KEY_PREFIX}*`;

        do {
          const [newCursor, keys] = await this.client.scan(cursor, 'MATCH', pattern, 'COUNT', 100);
          cursor = newCursor;

          if (keys.length > 0) {
            const pipeline = this.client.pipeline();
            keys.forEach(k => pipeline.get(k));
            const results = await pipeline.exec();

            if (results) {
              results.forEach(([err, val], idx) => {
                if (!err && val) {
                  dataMap[keys[idx]] = val as string;
                }
              });
            }
          }
        } while (cursor !== '0');

        return dataMap;
      } catch (err) {
        console.warn('Failed to scan Redis live strings:', err);
      }
    }

    // Fallback: cycle through snapshots
    if (this.mockSnapshots.length > 0) {
      const data = this.mockSnapshots[this.mockSnapshotIndex];
      this.mockSnapshotIndex = (this.mockSnapshotIndex + 1) % this.mockSnapshots.length;
      
      const rawMap: Record<string, string> = {};
      Object.entries(data).forEach(([k, v]) => {
        rawMap[k] = JSON.stringify(v);
      });
      return rawMap;
    }

    return {};
  }

  /**
   * Fetches all live license data keys from Redis (or snapshot fallback)
   */
  static async getAllLiveLicenseData(): Promise<Record<string, any>> {
    if (this.isConnected && this.client) {
      const rawStrings = await this.getLiveLicenseRawStrings();
      const dataMap: Record<string, any> = {};
      Object.entries(rawStrings).forEach(([k, v]) => {
        try {
          dataMap[k] = JSON.parse(v);
        } catch {}
      });
      return dataMap;
    }

    // Fallback: cycle through snapshots
    if (this.mockSnapshots.length > 0) {
      const data = this.mockSnapshots[this.mockSnapshotIndex];
      this.mockSnapshotIndex = (this.mockSnapshotIndex + 1) % this.mockSnapshots.length;
      return data;
    }

    return {};
  }

  /**
   * Gets features for a specific license name (e.g. Catia, MATLAB)
   */
  static async getLicenseUsage(licenseName: string): Promise<any[]> {
    const allData = await this.getAllLiveLicenseData();
    const result: any[] = [];

    const normTarget = licenseName.toLowerCase().replace(/[^a-z0-9]/g, '');

    Object.values(allData).forEach(item => {
      if (!item || !item.Name) return;
      const normItem = item.Name.toLowerCase().replace(/[^a-z0-9]/g, '');
      if (normItem.includes(normTarget) || normTarget.includes(normItem)) {
        result.push(item);
      }
    });

    return result;
  }
}
