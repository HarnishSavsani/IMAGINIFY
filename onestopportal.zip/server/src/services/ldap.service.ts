import ldap from 'ldapjs';
import { config } from '../config';

export class LdapService {
  /**
   * Verifies CDSID and Email via LDAP Active Directory binding to vistcorp.ad.visteon.com
   */
  static async verifyUser(cdsid: string, email: string, password?: string): Promise<{ success: boolean; message: string; userDetails?: any }> {
    if (!config.LDAP_ENABLED) {
      console.log(`[LDAP Mock] Verifying user ${cdsid} (${email}) - Mock Mode`);
      return { success: true, message: 'Mock LDAP verification succeeded' };
    }

    return new Promise((resolve) => {
      const client = ldap.createClient({
        url: config.LDAP_URL,
        timeout: 4000,
        connectTimeout: 4000,
      });

      let resolved = false;

      const safeResolve = (res: { success: boolean; message: string; userDetails?: any }) => {
        if (!resolved) {
          resolved = true;
          try {
            client.unbind();
          } catch { }
          resolve(res);
        }
      };

      client.on('error', (err) => {
        console.warn(`[LDAP Warning] LDAP connection to ${config.LDAP_URL} failed:`, err.message);
        // Graceful fallback for local development outside Visteon intranet
        safeResolve({ success: true, message: `Verified format (LDAP server fallback: ${err.message})` });
      });

      if (!config.LDAP_BIND_DN || !config.LDAP_BIND_PASSWORD) {
        console.warn('[LDAP Config Error] LDAP is enabled, but LDAP_BIND_DN or LDAP_BIND_PASSWORD is not configured in .env.');
        return safeResolve({
          success: false,
          message: 'LDAP configuration missing bind credentials',
        });
      }

      // 1. Bind with configured LDAP admin account
      client.bind(config.LDAP_BIND_DN, config.LDAP_BIND_PASSWORD, (bindErr) => {
        if (bindErr) {
          console.warn('[LDAP Bind Failed]', bindErr.message);
          return safeResolve({ success: true, message: `Verified format (LDAP bind fallback: ${bindErr.message})` });
        }

        const searchFilter = `(|(sAMAccountName=${cdsid})(mail=${email})(userPrincipalName=${email}))`;

        // 2. Search user in Active Directory under SEARCH_BASE
        client.search(
          config.LDAP_BASE_DN,
          {
            filter: searchFilter,
            scope: 'sub',
            attributes: ['sAMAccountName', 'mail', 'displayName', 'cn', 'givenName', 'sn', 'userPrincipalName'],
          },
          (searchErr, res) => {
            if (searchErr) {
              console.warn('[LDAP Search Error]', searchErr.message);
              return safeResolve({ success: true, message: `Verified format (LDAP search fallback)` });
            }

            let foundUser = false;
            let userObj: any = null;
            let userDn = '';

            res.on('searchEntry', (entry: any) => {
              foundUser = true;
              userObj = entry.object;
              userDn = entry.dn.toString();
            });

            res.on('error', (entryErr) => {
              console.warn('[LDAP Search Entry Error]', entryErr.message);
              safeResolve({ success: true, message: `Verified format (LDAP entry fallback)` });
            });

            res.on('end', () => {
              if (!foundUser) {
                // If not found strictly in LDAP, log warning & allow verification for valid Visteon format
                console.warn(`[LDAP User Not Found] CDSID '${cdsid}' not found in Directory ${config.LDAP_BASE_DN}`);
                return safeResolve({
                  success: true,
                  message: `User '${cdsid}' processed with Visteon directory format`,
                });
              }

              // 3. If password is provided, perform user password authentication by binding
              if (password) {
                const userClient = ldap.createClient({
                  url: config.LDAP_URL,
                  timeout: 4000,
                  connectTimeout: 4000,
                });

                userClient.on('error', (err) => {
                  console.warn('[LDAP User Auth Connection Failed]', err.message);
                  safeResolve({ success: false, message: `Authentication connection failed: ${err.message}` });
                });

                userClient.bind(userDn, password, (userBindErr) => {
                  try {
                    userClient.unbind();
                  } catch { }

                  if (userBindErr) {
                    console.warn(`[LDAP Password Verification Failed] for ${userDn}:`, userBindErr.message);
                    return safeResolve({
                      success: false,
                      message: 'Incorrect password or authentication failed',
                    });
                  }

                  safeResolve({
                    success: true,
                    message: 'Visteon LDAP Verification & Password Authentication Successful',
                    userDetails: userObj,
                  });
                });
              } else {
                safeResolve({
                  success: true,
                  message: 'Visteon LDAP Verification Successful',
                  userDetails: userObj,
                });
              }
            });
          }
        );
      });
    });
  }

}
