import { DbService } from './db.service';
import { config } from '../config';

export class HealthService {
  /**
   * Pings an application endpoint via HTTP and updates status in SQLite
   */
  static async checkApplicationHealth(app: any): Promise<{ id: number; name: string; status: string; health_status: string; latency: number | null }> {
    const startTime = Date.now();
    let status = 'Active';
    let latency: number | null = null;

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), config.APP_MONITOR_TIMEOUT_MS);

      const headers: Record<string, string> = {
        'User-Agent': 'OneStopPortal-HealthCheck/1.0',
      };

      if (app.auth_type === 'bearer' && app.auth_token) {
        headers['Authorization'] = `Bearer ${app.auth_token}`;
      } else if (app.auth_type === 'basic' && app.auth_token) {
        headers['Authorization'] = `Basic ${app.auth_token}`;
      }

      const response = await fetch(app.url, {
        method: 'HEAD',
        signal: controller.signal,
        headers,
      }).catch(async () => {
        // Fallback to GET if HEAD fails
        return await fetch(app.url, {
          method: 'GET',
          signal: controller.signal,
          headers,
        });
      });

      clearTimeout(timeoutId);
      latency = Date.now() - startTime;

      if (response.status === 401 || response.status === 403) {
        status = 'Auth Issue';
        latency = null;
      } else if (!response.ok && response.status >= 500) {
        status = 'Not Active';
        latency = null;
      } else if (latency > config.APP_SLOW_THRESHOLD_MS) {
        status = 'Slow';
      } else {
        status = 'Active';
      }
    } catch (err: any) {
      if (err.name === 'AbortError') {
        status = 'Slow';
        latency = config.APP_MONITOR_TIMEOUT_MS;
      } else {
        status = 'Not Active';
        latency = null;
      }
    }

    DbService.updateApplicationStatus(app.id, status, latency);
    return { id: app.id, name: app.name, status: app.status || 'Active', health_status: status, latency };
  }


  /**
   * Runs health checks for all applications in database
   */
  static async checkAllApplications(): Promise<any[]> {
    const apps = DbService.getAllApplications();
    const results = await Promise.allSettled(
      apps.map(app => this.checkApplicationHealth(app))
    );

    return results.map(r => r.status === 'fulfilled' ? r.value : null).filter(Boolean);
  }
}
