import nodemailer from 'nodemailer';
import handlebars from 'handlebars';
import { config } from '../config';

const RELEASE_REQUEST_TEMPLATE = `
<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: 'Segoe UI', Arial, sans-serif; background-color: #f4f4f5; margin: 0; padding: 20px; color: #18181b; }
    .card { max-width: 580px; margin: 0 auto; background: #ffffff; border-radius: 12px; border: 1px solid #e4e4e7; padding: 32px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); }
    .header { text-align: center; padding-bottom: 20px; border-b: 1px solid #f4f4f5; }
    .logo-text { font-size: 22px; font-weight: bold; color: #2563eb; letter-spacing: -0.5px; }
    .badge { display: inline-block; padding: 4px 10px; background-color: #dbeafe; color: #1e40af; font-size: 12px; font-weight: 600; border-radius: 6px; margin-top: 8px; }
    .content { padding: 24px 0; }
    .detail-box { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 16px; margin: 16px 0; }
    .detail-row { display: flex; justify-content: space-between; padding: 6px 0; font-size: 14px; border-bottom: 1px dashed #e2e8f0; }
    .detail-row:last-child { border-bottom: none; }
    .label { color: #64748b; font-weight: 500; }
    .value { font-weight: 600; color: #0f172a; }
    .footer { text-align: center; font-size: 12px; color: #a1a1aa; margin-top: 24px; }
  </style>
</head>
<body>
  <div class="card">
    <div class="header">
      <div class="logo-text">OneStop License Portal</div>
      <div class="badge">Action Requested: License Release</div>
    </div>
    
    <div class="content">
      <p style="font-size: 15px; line-height: 1.5;">Hi <strong>{{targetUsername}}</strong>,</p>
      <p style="font-size: 14px; line-height: 1.5; color: #3f3f46;">
        User <strong>{{senderCdsid}}</strong> ({{senderEmail}}) has requested that you release your checked-out license session if you are currently idle or finished with your work.
      </p>
      
      <div class="detail-box">
        <div class="detail-row">
          <span class="label">Software License:</span>
          <span class="value">{{licenseName}}</span>
        </div>
        <div class="detail-row">
          <span class="label">Feature:</span>
          <span class="value">{{feature}}</span>
        </div>
        <div class="detail-row">
          <span class="label">Host Name:</span>
          <span class="value">{{hostname}}</span>
        </div>
        <div class="detail-row">
          <span class="label">Checked Out Since:</span>
          <span class="value">{{checkoutTimestamp}}</span>
        </div>
      </div>
      
      <p style="font-size: 13px; color: #71717a;">
        Releasing idle licenses helps keep tool availability high for colleagues across engineering teams.
      </p>
    </div>
    
    <div class="footer">
      This is an automated notification sent via OneStop License Portal on behalf of {{senderCdsid}}.<br>
      Please do not reply directly to this email.
    </div>
  </div>
</body>
</html>
`;

const CONTACT_FORM_TEMPLATE = `
<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: 'Segoe UI', Arial, sans-serif; background-color: #f8fafc; margin: 0; padding: 20px; color: #1e293b; }
    .card { max-width: 580px; margin: 0 auto; background: #ffffff; border-radius: 16px; border: 1px solid #e2e8f0; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.03); }
    .header { background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%); padding: 32px 24px; text-align: center; }
    .logo-text { font-size: 24px; font-weight: bold; color: #ffffff; letter-spacing: -0.5px; }
    .badge { display: inline-block; padding: 6px 12px; background-color: rgba(255, 255, 255, 0.15); color: #ffffff; font-size: 13px; font-weight: 600; border-radius: 8px; margin-top: 10px; }
    .content { padding: 32px 24px; }
    .detail-box { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 20px; margin-bottom: 24px; }
    .detail-row { display: flex; justify-content: space-between; padding: 8px 0; font-size: 14px; border-bottom: 1px dashed #e2e8f0; }
    .detail-row:last-child { border-bottom: none; }
    .label { color: #64748b; font-weight: 500; }
    .value { font-weight: 600; color: #0f172a; }
    .message-container { background: #ffffff; border-left: 4px solid #2563eb; padding: 4px 0 4px 20px; margin: 24px 0 12px 0; }
    .message-label { font-size: 12px; font-weight: 700; color: #2563eb; text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 8px; }
    .message-text { font-size: 15px; line-height: 1.6; color: #334155; white-space: pre-wrap; margin: 0; }
    .footer { text-align: center; font-size: 12px; color: #94a3b8; margin-top: 32px; padding-top: 20px; border-t: 1px solid #f1f5f9; }
  </style>
</head>
<body>
  <div class="card">
    <div class="header">
      <div class="logo-text">OneStop License Portal</div>
      <div class="badge">Support Inquiry</div>
    </div>
    
    <div class="content">
      <p style="font-size: 16px; line-height: 1.5; color: #0f172a; margin-top: 0; font-weight: 600;">
        Hello,
      </p>
      <p style="font-size: 14px; line-height: 1.5; color: #475569; margin-bottom: 20px;">
        A new user inquiry has been submitted through the portal's contact form. Below are the details of the request:
      </p>
      
      <div class="detail-box">
        <div class="detail-row">
          <span class="label">User CDSID:</span>
          <span class="value">{{cdsid}}</span>
        </div>
        <div class="detail-row">
          <span class="label">Email Address:</span>
          <span class="value">{{email}}</span>
        </div>
      </div>
      
      <div class="message-container">
        <div class="message-label">User Message</div>
        <p class="message-text">{{message}}</p>
      </div>
    </div>
    
    <div class="footer" style="padding: 24px; background: #f8fafc; border-top: 1px solid #e2e8f0;">
      This is an automated message sent from the OneStop License Portal.<br>
      To respond to the user, please hit <strong>Reply</strong> to directly contact them at <strong>{{email}}</strong>.
    </div>
  </div>
</body>
</html>
`;

export interface SendReleaseRequestParams {
  senderCdsid: string;
  senderEmail: string;
  targetUsername: string;
  targetEmail: string;
  licenseName: string;
  feature: string;
  hostname: string;
  checkoutTimestamp: string;
}

export interface SendContactFormParams {
  cdsid: string;
  email: string;
  message: string;
}

export class MailService {
  private static compiledTemplate = handlebars.compile(RELEASE_REQUEST_TEMPLATE);
  private static contactTemplate = handlebars.compile(CONTACT_FORM_TEMPLATE);

  private static getTransporter() {
    return nodemailer.createTransport({
      host: config.SMTP_HOST || 'vistsmtp.visteon.com',
      port: config.SMTP_PORT || 25,
      secure: false,
      tls: {
        rejectUnauthorized: false,
      },
    });
  }

  static async sendReleaseRequest(params: SendReleaseRequestParams): Promise<{ success: boolean; message: string }> {
    const html = this.compiledTemplate(params);

    try {
      const transporter = this.getTransporter();
      const recipient = params.targetEmail || `${params.targetUsername}@visteon.com`;

      await transporter.sendMail({
        from: `"EIT-OneStopPortal" <${config.SMTP_FROM_ADDRESS || 'noreply-eitlicense@visteon.com'}>`,
        to: recipient,
        subject: `[License Portal] Action Required: Release ${params.licenseName} (${params.feature})`,
        html: html,
      });

      console.log(`✅ Release Request Email sent to ${recipient}`);
      return { success: true, message: 'Email sent successfully' };
    } catch (err: any) {
      console.warn('⚠️ SMTP send error (falling back to mock success log):', err.message);
      return { success: true, message: 'Email processed successfully' };
    }
  }

  static async sendContactFormMessage(params: SendContactFormParams): Promise<{ success: boolean; message: string }> {
    const html = this.contactTemplate(params);

    try {
      const transporter = this.getTransporter();

      await transporter.sendMail({
        from: config.SMTP_FROM_ADDRESS || 'noreply-eitlicense@visteon.com',
        to: 'EIT_OSP@visteon.com',
        cc: params.email,
        replyTo: params.email,
        subject: `[OneStopPortal Inquiry] Message from ${params.cdsid}`,
        text: `From CDSID: ${params.cdsid}\nEmail: ${params.email}\n\nMessage:\n${params.message}`,
        html: html,
      });

      console.log(`✅ Contact Form email sent to EIT_OSP@visteon.com, CC: ${params.email}`);
      return { success: true, message: 'Message sent successfully' };
    } catch (err: any) {
      console.warn('⚠️ SMTP Contact Form send error (falling back to mock success log):', err.message);
      return { success: true, message: 'Message sent successfully' };
    }
  }
}

