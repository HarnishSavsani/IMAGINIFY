import dotenv from 'dotenv';
import path from 'path';
import { configSchema, Config } from './schema';

// Load environment variables from .env / .env.local
dotenv.config({ path: path.resolve(process.cwd(), '.env.local') });
dotenv.config({ path: path.resolve(process.cwd(), '.env') });

function loadConfig(): Config {
  const parsed = configSchema.safeParse(process.env);
  if (!parsed.success) {
    console.error('❌ Invalid environment configuration:', parsed.error.format());
    // Fall back to defaults for optional parameters
  }
  return parsed.data || configSchema.parse({});
}

export const config = loadConfig();
