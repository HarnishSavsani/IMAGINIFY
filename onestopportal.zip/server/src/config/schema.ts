import { z } from 'zod';

export const configSchema = z.object({
  // Server
  PORT: z.coerce.number().default(3001),
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  CORS_ORIGIN: z.string().default('*'),

  // Redis
  REDIS_HOST: z.string().default('localhost'),
  REDIS_PORT: z.coerce.number().default(6379),
  REDIS_PASSWORD: z.string().optional().default(''),
  REDIS_KEY_PREFIX: z.string().default('license:live:'),
  REDIS_POLL_INTERVAL_MS: z.coerce.number().default(1000),

  // SQLite
  SQLITE_DB_PATH: z.string().default('./server/data/portal.sqlite'),

  // LDAP Visteon Config
  LDAP_URL: z.string().default('ldap://vistcorp.ad.visteon.com:389'),
  LDAP_BASE_DN: z.string().default('cn=users,dc=vistcorp,dc=ad,dc=visteon,dc=com'),
  LDAP_SEARCH_FILTER: z.string().default('(&(objectClass=user)(|(sAMAccountName={{username}})(mail={{username}})))'),
  LDAP_BIND_DN: z.string().default(''),
  LDAP_BIND_PASSWORD: z.string().default(''),
  LDAP_ENABLED: z.coerce.boolean().default(true),

  // SMTP Visteon Config
  SMTP_HOST: z.string().default('vistsmtp.visteon.com'),
  SMTP_PORT: z.coerce.number().default(25),
  SMTP_SECURE: z.coerce.boolean().default(false),
  SMTP_FROM_ADDRESS: z.string().default('noreply-onestopportal@visteon.com'),
  SMTP_FROM_NAME: z.string().default('EIT-OneStopPortal'),
  SMTP_ENABLED: z.coerce.boolean().default(true),

  // App Monitoring
  APP_MONITOR_CRON: z.string().default('*/30 * * * *'),
  APP_MONITOR_TIMEOUT_MS: z.coerce.number().default(5000),
  APP_SLOW_THRESHOLD_MS: z.coerce.number().default(2000),

  // WebSocket
  WS_PORT: z.coerce.number().default(3002),
  WS_HEARTBEAT_INTERVAL_MS: z.coerce.number().default(30000),
});

export type Config = z.infer<typeof configSchema>;
