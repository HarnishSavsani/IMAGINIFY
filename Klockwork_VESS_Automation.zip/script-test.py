import requests
import datetime
from datetime import datetime
import oracledb
import os
import configparser
import json
import smtplib
import threading
import sys
import time
from email.message import EmailMessage

#============================================ Database Configs Starts ====================================================== 

scriptPath = os.path.dirname(os.path.abspath(__file__))

# To Read the data from Config file
ConfigFile = 'Klockwork_Automation_DEV.cfg'
ConfigFile = scriptPath+"\\"+ConfigFile
config = configparser.RawConfigParser()
config.read(ConfigFile)
Oracle_username = config.get('DBDetails', 'Oracle_username')
Oracle_pwd = config.get('DBDetails', 'Oracle_pwd')
dsn = config.get('DBDetails', 'dsn')
port = config.get('DBDetails', 'port')
encoding = config.get('DBDetails', 'encoding')

Oracle_Path = config.get('FileLocations', 'Oracle_Path')
OutPutFile = config.get('FileLocations', 'outputfile')
OutPutFile = scriptPath+"\\"+OutPutFile
ServerListFile = config.get('FileLocations', 'serverlistfile')
ServerListFile = scriptPath+"\\"+ServerListFile
mailFile = config.get('FileLocations', 'mailfile')
mailFile = scriptPath+"\\"+mailFile

ToList = config.get('SMTP', 'ToList')
From = config.get('SMTP', 'From')
Subject = config.get('SMTP', 'Subject')
SMTP_Server = config.get('SMTP', 'SMTP_Server')
SMTP_Port = config.get('SMTP', 'SMTP_Port')

#============================================ Database Configs Ends ====================================================== #============================================ Global Variables====================================================== 

#============================================ Global Variable Starts ====================================================== #============================================ Global Variables====================================================== 
# Reads server list and convert it to global variable with data struture dict with key as string and value as list
#where list[0] = url , list[1] = admin, list[2] = ltoken
def read_server_list(file_path):
    server_data = {}
    with open(file_path, 'r') as file:
        for line in file:
            if '.visteon.com' in line:
                # Split the line by '|'
                parts = line.split('|')
                if len(parts) == 4:
                    # Trim whitespace and remove extra spaces
                    key = parts[0].strip()
                    url = parts[1].strip()
                    user = parts[2].strip()
                    ltoken = parts[3].strip()
                    # Store the values in a dictionary
                    server_data[key] = [url, user, ltoken]
    return server_data

#created global variable 
KlockworkAuthObject = read_server_list(ServerListFile)

def check_server_availability(auth_object):
    unavailable_servers = []

    for server, details in auth_object.items():
        url = f'https://{details[0]}'
        
        try:
            if server == 'slhepv0127.ctsslou.visteon.com':
                response = requests.get(url, timeout=5, verify=False)
            else:
                response = requests.get(url, timeout=5)
            
            if response.status_code != 200:
                unavailable_servers.append(server)
        except requests.exceptions.RequestException:
            unavailable_servers.append(server)
    
    return unavailable_servers

unavailable_servers = check_server_availability(KlockworkAuthObject)
print(unavailable_servers)

#============================================ Global Variable Ends ====================================================== #============================================ Global Variables====================================================== 

#============================================ Method Defination Starts ====================================================== #============================================ Global Variables====================================================== 
    
def get_group_users(admin, url,  group_name, ltoken):
    data = {
        'action': 'groups',
        'user': admin,
        'search': group_name,
        'ltoken': ltoken,
        'list_users': 'true'
    }
    
    try:
        response = requests.post(url, data=data)
        response.raise_for_status()
        result = response.json()
        
        # Check if the 'users' key is in the result and return the list of users
        if 'users' in result:
            return result['users']
        else:
            return None

    except requests.exceptions.RequestException as e:
        print(f"An error occurred: {e}")
        return None
    
def give_user_access(admin, cdsid, group_name, ltoken, url, users,vessrequestid):
    data = {
        'action': 'update_group',
        'user': admin,
        'name' : group_name,
        'users': users,
        'ltoken': ltoken
    }
    try:
        response = requests.post(url, data=data)
        if response.status_code == 200:
            print(f"User '{cdsid}' has successfully recevied access to  group '{group_name}' ")
            createLog(f"{getTimeStamp()}  Info    VESS-Request-ID : {vessrequestid} CDS-ID : {cdsid} - User '{cdsid}' has successfully recevied access to  group '{group_name}'\n",OutPutFile)
            return True   
        else:
            print(f"Unable to give access to user '{cdsid}' to  group '{group_name}' ")
            createLog(f"{getTimeStamp()}  Info    VESS-Request-ID : {vessrequestid} CDS-ID : {cdsid} - Unable to give access to user '{cdsid}' to  group '{group_name}'\n",OutPutFile)
            return False
    except requests.exceptions.RequestException as e:
        print(f"Request Exception: {e}")
        createLog(f"{getTimeStamp()}  Error   VESS-Request-ID : {vessrequestid} CDS-ID : {cdsid} - Request Exception: {e}\n",OutPutFile)
        return False

# checks current user access
def check_current_user_access(admin, cdsid, group_name, ltoken, url,vessrequestid):
    data = {
        'action': 'users',
        'user': admin,
        'search': cdsid,
        'ltoken': ltoken
    }
    try:
        response = requests.post(url, data=data)
        if response.status_code == 200:
            json_response = response.json()
            # Check if 'groups' key exists in the JSON response
            if 'groups' in json_response:
                groups = json_response['groups']
                # Iterate through the groups to find a match for group_name
                for group in groups:
                    if group.get('name') == group_name:
                        createLog(f"{getTimeStamp()}  Info    VESS-Request-ID : {vessrequestid} CDS-ID : {cdsid} - {group_name} is present in the groups\n",OutPutFile)
                        return True
                createLog(f"{getTimeStamp()}  Info    VESS-Request-ID : {vessrequestid} CDS-ID : {cdsid} - {group_name} is not present in the groups\n",OutPutFile)
                return False
            else:
                print("Error: 'groups' key not found in response")
                createLog(f"{getTimeStamp()}  Error   VESS-Request-ID : {vessrequestid} CDS-ID : {cdsid} - 'groups' key not found in response\n",OutPutFile)
                return None       
        else:
            print(f"Error: {response.status_code} - {response.reason}")
            createLog(f"{getTimeStamp()}  Error   VESS-Request-ID : {vessrequestid} CDS-ID : {cdsid} - {response.status_code} - {response.reason}\n",OutPutFile)
            return None      
    except requests.exceptions.RequestException as e:
        print(f"Request Exception: {e}")
        createLog(f"{getTimeStamp()}  Error   VESS-Request-ID : {vessrequestid} CDS-ID : {cdsid} - Request Exception: {e}\n",OutPutFile)
        return None

def find_group_name(all_groups,oem, role):
    # Convert oem and role to lowercase for case-insensitive comparison
    oem_lower = oem.lower()
    role_lower = role.lower()
    # Search for oem and role in the list of all_groups
    for group_name in all_groups:
        # Convert group_name to lowercase for case-insensitive comparison
        group_name_lower = group_name.lower()
        # Check if both oem and role are present in the group_name
        if oem_lower in group_name_lower and role_lower in group_name_lower:
            return group_name
    # If no matching group_name is found, return None
    return None

def get_all_group_names(admin,ltoken, url):
    try:
        # Parameters for the API request
        data = {
            'action': 'groups',
            'user': admin,
            'search' : '*',
            'limit': '10000000',
            'ltoken': ltoken
        } 
        # Send the GET request to the API
        response = requests.post(url, data=data)
        if response.status_code == 200:
            # Split the response by lines and parse each line as JSON
            lines = response.text.splitlines()
            group_names = []
            
            for line in lines:
                try:
                    json_data = json.loads(line)
                    if 'name' in json_data:
                        group_names.append(json_data['name'])
                except json.JSONDecodeError as e:
                    print(f"Error decoding JSON: {e}. Line: {line}")
            
            return group_names
        else:
            print(f"Error: {response.status_code} - {response.reason}")
            createLog(f"{getTimeStamp()}  Error  - {response.status_code} - {response.reason}\n",OutPutFile)
            return None
            
    except requests.exceptions.RequestException as e:
        print(f"Request Exception: {e}")
        createLog(f"{getTimeStamp()}  Error  - Request Exception: {e}\n",OutPutFile)
        return None
    
def create_backup(group_name, user_list, cdsid):
    # Define the backup directory
    backup_dir = 'backup'
    # Create the backup directory if it doesn't exist
    if not os.path.exists(backup_dir):
        os.makedirs(backup_dir)
    # Define the file path
    file_path = os.path.join(backup_dir, f"{group_name}.txt")
    # Write the user list and CDSID to the file
    with open(file_path, 'w') as file:
        # Write the user list as a comma-separated string
        file.write(f"UserList: {','.join(user_list)}\n")
        # Write the CDSID
        file.write(f"NewUser: {cdsid}\n")

def clearMailContent(text,filename):
    file = open(filename,'w')
    file.write(text)
    file.close()

def SendEmail(msg_content, filename=None):
    # Create email message
    msg = EmailMessage()
    msg['To'] = ToList
    msg['From'] = From
    msg['Subject'] = Subject
    msg.set_content(msg_content,subtype='html')

    # Attach file if filename is provided
    if filename:
        with open(filename, "rb") as file:
            file_data = file.read()
        msg.add_attachment(file_data, maintype='application', subtype='octet-stream', filename=os.path.basename(filename))

    # Send the email
    with smtplib.SMTP(SMTP_Server, SMTP_Port) as server:
        server.starttls()
        server.send_message(msg)

def SendNotification(message_body,ToList,Subject):
        msg = EmailMessage()
        msg['To'] = ToList
        msg['From'] = From
        msg['Subject'] = Subject
        msg.set_content(message_body)
        server = smtplib.SMTP(SMTP_Server, SMTP_Port)
        server.starttls()
        server.send_message(msg)
        server.quit()

#============================================ Method Defination Ends ====================================================== 

#============================================ VESS RELATED FUNCTIONS Starts ====================================================== 

def getTimeStamp():
    now = datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    return(now)

def createLog(text,filename):
    file = open(filename, 'a')
    file.write(text)
    file.close()

def createMailContent(text,filename):
    file = open(filename, 'a')
    file.write(text)
    file.close()

def read_VESS_Table():
    print("Establishing Connection with VESS DB")
    oracledb.init_oracle_client(lib_dir=Oracle_Path)
    try:
        # Connect to the Oracle database
        conn = oracledb.connect(user=Oracle_username, password=Oracle_pwd, dsn=dsn)
        # Prepare a cursor object using cursor() method
        cursor = conn.cursor()
        # Execute the SQL query
        sql_query = """ SELECT *
                        FROM VESS.VESS72_KLOCWORK_RQST_DATA
                        WHERE VESS_REQUEST IN (
                            SELECT VESS_REQUEST
                            FROM VESS.VESS73_KLOCWORK_RQST_STATUS
                            WHERE REQUEST_STATUS = 'P'
                        )
                        AND ACTION_TYPE IN ('A')
                        ORDER BY KLOCWORK_SERVER, UPDATE_DATE"""
        cursor.execute(sql_query)
        # Fetch all rows and store them as a list of dictionaries
        rows = cursor.fetchall()
        result = []
        for row in rows:
            # Create a dictionary for each row
            row_dict = {}
            for i, column in enumerate(cursor.description):
                column_name = column[0]
                value = row[i]
                row_dict[column_name] = value
            result.append(row_dict)
        # Close the cursor and connection
        cursor.close()
        conn.close()
        return result
    except oracledb.DatabaseError as e:
        print("Database Error:", e)
        createLog(f"{getTimeStamp()}  Error  - Database Error while read_VESS_Table() : {e}\n",OutPutFile)
        return None
    

def update_VESS_Table(artifactoryResult):
    print("Establishing connection with VESS-DB to update request status")
    oracledb.init_oracle_client(lib_dir=Oracle_Path)
    try:
        now = datetime.now()
        datevar = now.strftime('%d-%b-%y')
        with oracledb.connect(Oracle_username, Oracle_pwd, dsn) as connection:
            # create a cursor
            with connection.cursor() as cursor:
                for result in artifactoryResult:
                    # execute the select statement
                    update_query = """update VESS.VESS73_KLOCWORK_RQST_STATUS set
                     REQUEST_STATUS = :status , UPDATE_DATE = :datevar 
                     where VESS_REQUEST = :VESS_Id """
                    cursor.execute(update_query, [result[1],datevar,result[0]])             
                connection.commit()
                cursor.close()
                connection.close()
                for error in cursor.getbatcherrors():
                    print(str(error))
                
                return True
    except oracledb.Error as error:
        print(error)
        return False

def mainFn():
    print("<<< Script Execution has successfully Started >>>")
    clearMailContent('',mailFile)
    createMailContent(f"=====================================================\n",mailFile)
    createMailContent(f"            KLOCKWORK ACCESS REQUEST REPORT\n",mailFile)
    createMailContent(f"=====================================================\n",mailFile)
    createMailContent(f"        Report Generated On:  {getTimeStamp()}\n",mailFile)
    createMailContent("-----------------------------------------------------\n\n",mailFile)

        
    createMailContent("=====================================================\n",mailFile)
    instance = 'slhepv0127.ctsslou.visteon.com'
    vessrequestid = '192000151'
    cdsid = 'pkumar50'
    OEM = 'FORD'
    role = 'lead'

    url, admin, ltoken =  KlockworkAuthObject[instance]
    
    url = f"https://{url}/review/api"
    
    createMailContent(f"REQUEST TYPE:          A\n",mailFile)
    createMailContent(f"VESS REQUEST ID:       {vessrequestid}\n",mailFile)
    createMailContent(f"CDS ID:                {cdsid}\n",mailFile)
    createMailContent(f"ROLE:                  {role}\n",mailFile)
    createMailContent(f"OEM:                   {OEM}\n",mailFile)
    createMailContent(f"INSTANCE:              {instance}\n",mailFile)

    total_requests = 1
    failed_requests = 0
    failed_request_ids = []
    total_pending_request = 0
    pending_request_ids = []
    non_reachable_instances = unavailable_servers
    
    if instance in unavailable_servers:
        total_pending_request +=1
        pending_request_ids.append(vessrequestid)
        createLog(f"{getTimeStamp()}  Error  VESS-Request-ID : {vessrequestid} CDS-ID : {cdsid} - Server '{instance}' is not Reachable\n", OutPutFile) 
        return

    # Convert role to lowercase for consistent comparison
    role_lower = role.lower()

    # Define group name based on specific conditions
    if OEM == 'MFA2/MRA2' and instance == 'kw.group2.visteon.com':
        if role_lower == 'developer':
            group_name = 'MFA_developers'
        elif role_lower == 'lead':
            group_name = 'MFA_leads'
    elif OEM == 'SVW' and instance == 'kw.group2.visteon.com':
        if role_lower == 'developer':
            group_name = 'SVW_developers'
        elif role_lower == 'lead':
            group_name = 'SVW_leads'
    elif OEM == 'VW' and instance == 'kw.group2.visteon.com':
        if role_lower == 'developer':
            group_name = 'VW_developers'
        elif role_lower == 'lead':
            group_name = 'VW_leads'
    else:
        # If none of the conditions match, use the existing logic to find the group name
        all_groups = get_all_group_names(admin, ltoken, url)
        group_name = find_group_name(all_groups, OEM, role)

    if group_name != None:
        result = check_current_user_access(admin, cdsid, group_name, ltoken, url,vessrequestid)
        if result == True:
            print("Approved")
            createLog(f"{getTimeStamp()}  Success  VESS-Request-ID : {vessrequestid} CDS-ID : {cdsid} - Approved\n", OutPutFile)      
            createMailContent(f"REQUEST STATUS:        Approved\n\n",mailFile)
        elif result == False:
            user_list = get_group_users(admin, url,  group_name, ltoken)
            create_backup(group_name, user_list, cdsid)
            if user_list == None or len(user_list) == 0:
                failed_requests += 1
                failed_request_ids.append(vessrequestid)
                print("Rejected")
                createLog(f"{getTimeStamp()}  Error   VESS-Request-ID : {vessrequestid} CDS-ID : {cdsid} - No users found in group '{group_name}' on {instance}\n", OutPutFile)      
                createLog(f"{getTimeStamp()}  Error   VESS-Request-ID : {vessrequestid} CDS-ID : {cdsid} - Manually needed to be completed [ Fetched empty user list for group '{group_name}' ]\n", OutPutFile)      
                createMailContent(f"REQUEST STATUS:        Manually needed to be completed [ Fetched empty user list for group '{group_name}' ]\n\n",mailFile)
            else:
                user_list.append(cdsid)
                user_string = ','.join(user_list)
                if give_user_access(admin, cdsid, group_name, ltoken, url,user_string,vessrequestid):
                    print("Approved")
                    createLog(f"{getTimeStamp()}  Success VESS-Request-ID : {vessrequestid} CDS-ID : {cdsid} - Approved\n", OutPutFile)      
                    createMailContent(f"REQUEST STATUS:        Approved\n\n",mailFile)
                else :
                    failed_requests += 1
                    failed_request_ids.append(vessrequestid)
                    print("Rejected")
                    createLog(f"{getTimeStamp()}  Error   VESS-Request-ID : {vessrequestid} CDS-ID : {cdsid} - Manually needed to be completed [API Failure to add user '{cdsid}' to group '{group_name}' ]\n", OutPutFile)      
                    createMailContent(f"REQUEST STATUS:        Manually needed to be completed [API Failure to add user '{cdsid}' to group '{group_name}' ]\n\n",mailFile)
        else:
            failed_requests += 1
            failed_request_ids.append(vessrequestid)
            print("Rejected")
            createLog(f"{getTimeStamp()}  Error   VESS-Request-ID : {vessrequestid} CDS-ID : {cdsid} - Manually needed to be completed [ Unable to check user '{cdsid}' current groups ]\n", OutPutFile)      
            createMailContent(f"REQUEST STATUS:        Manually needed to be completed [ Unable to check user '{cdsid}' current groups ]\n\n",mailFile)
    else:
        failed_requests += 1
        failed_request_ids.append(vessrequestid)
        print("Rejected")
        createLog(f"{getTimeStamp()}  Error   VESS-Request-ID : {vessrequestid} CDS-ID : {cdsid} - Manually needed to be completed [ Unable to get Group for OEM '{OEM} and Role '{role}' ]\n", OutPutFile)      
        createMailContent(f"REQUEST STATUS:        Manually needed to be completed [ Unable to get Group for OEM '{OEM}' and Role '{role}' ]\n\n",mailFile)



    print("Status update Successfully in the VESS-DB")
    createLog(f"{getTimeStamp()}  Success - Status update Successfully in the VESS-DB\n",OutPutFile)
    email_body = f"""
    <p>Dear Team,</p><br>

    <p>Please find below the summary of the user access requests processed on {getTimeStamp()}.</p><br>

    <table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse;">
        <tr>
            <th>Total Requests</th>
            <td>{total_requests}</td>
        </tr>
        <tr>
            <th>Total Successfull Requests</th>
            <td>{total_requests - (failed_requests + total_pending_request)}</td>
        </tr>
        <tr>
            <th>Total Failed Requests</th>
            <td>{failed_requests}</td>
        </tr>
        <tr>
            <th>Failed Requests IDs</th>
            <td>{'-' if not failed_request_ids else ','.join(f"'{item}'" for item in failed_request_ids)}</td>
        </tr>
        <tr>
            <th>Total Pending Requests</th>
            <td>{total_pending_request}</td>
        </tr>
        <tr>
            <th>Pending Requests IDs</th>
            <td>{'-' if not pending_request_ids else ','.join(f"'{item}'" for item in pending_request_ids)}</td>
        </tr>
        <tr>
            <th>Non-Reachable Instances</th>
            <td>{'-' if not non_reachable_instances else ','.join(f"'{item}'" for item in non_reachable_instances)}</td>
        </tr>
    </table><br>

    <p>Best Regards,<br>Your Automation System</p>
    """
    SendEmail(email_body,mailFile)

    
#============================================ VESS RELATED FUNCTIONS Ends ====================================================== 


#============================================ Script Execution Starts ====================================================== 

if __name__ == "__main__":
    mainFn()

#============================================ Script Execution Ends ====================================================== 
   

