import requests
import datetime
from datetime import datetime
import oracledb
import os
import configparser
import json
import smtplib
from email.message import EmailMessage
import urllib3

# IMPORTANT: Import loguru for advanced logging
from loguru import logger
import sys

# Suppress the InsecureRequestWarning for your specific internal server
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

#============================================ Database Configs Starts ====================================================== 

scriptPath = os.path.dirname(os.path.abspath(__file__))

# To Read the data from Config file
ConfigFile = 'Klockwork_Automation.cfg'
ConfigFile = os.path.join(scriptPath, ConfigFile)
config = configparser.RawConfigParser()
config.read(ConfigFile)

Oracle_username = config.get('DBDetails', 'Oracle_username')
Oracle_pwd = config.get('DBDetails', 'Oracle_pwd')
dsn = config.get('DBDetails', 'dsn')
port = config.get('DBDetails', 'port')
encoding = config.get('DBDetails', 'encoding')

Oracle_Path = config.get('FileLocations', 'Oracle_Path')
OutPutFile = os.path.join(scriptPath, config.get('FileLocations', 'outputfile'))
ServerListFile = os.path.join(scriptPath, config.get('FileLocations', 'serverlistfile'))
mailFile = os.path.join(scriptPath, config.get('FileLocations', 'mailfile'))

ToList = config.get('SMTP', 'ToList')
From = config.get('SMTP', 'From')
Subject = config.get('SMTP', 'Subject')
SMTP_Server = config.get('SMTP', 'SMTP_Server')
SMTP_Port = config.get('SMTP', 'SMTP_Port')

#============================================ Logging Configuration ====================================================== 
# Remove default loguru handler and set up custom formatting to include Line Numbers and Function Names
logger.remove()
log_format = "<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>"
file_log_format = "{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {function}:{line} - {message}"

# Console output
logger.add(sys.stdout, format=log_format, level="INFO")
# File output (with rotation to prevent massive log files)
logger.add(OutPutFile, format=file_log_format, level="INFO", rotation="10 MB")

#============================================ Global Variable Starts ====================================================== 

# Clean Refactoring of OEM Logic Mapping
# Format: {(instance, OEM, role_lower): 'Target_Group'}
OEM_GROUP_MAPPING = {
    ('kw.group2.visteon.com', 'MFA2/MRA2', 'developer'): 'MFA_developers',
    ('kw.group2.visteon.com', 'MFA2/MRA2', 'lead'): 'MFA_leads',
    ('kw.group2.visteon.com', 'SVW', 'developer'): 'SVW_developers',
    ('kw.group2.visteon.com', 'SVW', 'lead'): 'SVW_leads',
    ('kw.group2.visteon.com', 'VW', 'developer'): 'VW_developers',
    ('kw.group2.visteon.com', 'VW', 'lead'): 'VW_leads'
}

def read_server_list(file_path):
    server_data = {}
    with open(file_path, 'r') as file:
        for line in file:
            if '.visteon.com' in line:
                parts = line.split('|')
                if len(parts) == 4:
                    key = parts[0].strip()
                    url = parts[1].strip()
                    user = parts[2].strip()
                    ltoken = parts[3].strip()
                    server_data[key] = [url, user, ltoken]
    return server_data

KLOCKWORK_AUTH_OBJECT = read_server_list(ServerListFile)

def check_server_availability(auth_object):
    UNAVAILABLE_SERVERS = []
    for server, details in auth_object.items():
        url = f'https://{details[0]}'
        try:
            if server == 'slhepv0127.ctsslou.visteon.com':
                response = requests.get(url, timeout=5, verify=False)
            else:
                response = requests.get(url, timeout=5)
                
            if response.status_code != 200:
                UNAVAILABLE_SERVERS.append(server)
        except requests.exceptions.RequestException as e:
            logger.warning(f"Server {server} is unreachable. Error: {e}")
            UNAVAILABLE_SERVERS.append(server)
    return UNAVAILABLE_SERVERS

UNAVAILABLE_SERVERS = check_server_availability(KLOCKWORK_AUTH_OBJECT)

#============================================ Method Defination Starts ====================================================== 
    
def get_group_users(admin, url, group_name, ltoken):
    data = {
        'action': 'groups',
        'user': admin,
        'search': group_name,
        'ltoken': ltoken,
        'list_users': 'true'
    }
    try:
        response = requests.post(url, data=data)
        response.raise_for_status()
        result = response.json()
        
        if 'users' in result:
            return result['users']
        return None
    except requests.exceptions.RequestException as e:
        logger.error(f"Failed to get users for group {group_name}: {e}")
        return None
    
def give_user_access(admin, cdsid, group_name, ltoken, url, users, vessrequestid):
    data = {
        'action': 'update_group',
        'user': admin,
        'name' : group_name,
        'users': users,
        'ltoken': ltoken
    }
    try:
        response = requests.post(url, data=data)
        if response.status_code == 200:
            logger.info(f"VESS-Request-ID : {vessrequestid} CDS-ID : {cdsid} - User '{cdsid}' has successfully received access to group '{group_name}'")
            return True   
        else:
            logger.error(f"VESS-Request-ID : {vessrequestid} CDS-ID : {cdsid} - Unable to give access. API returned {response.status_code}")
            return False
    except requests.exceptions.RequestException as e:
        logger.error(f"VESS-Request-ID : {vessrequestid} CDS-ID : {cdsid} - Request Exception: {e}")
        return False

def check_current_user_access(admin, cdsid, group_name, ltoken, url, vessrequestid):
    data = {
        'action': 'users',
        'user': admin,
        'search': cdsid,
        'ltoken': ltoken
    }
    try:
        response = requests.post(url, data=data)
        if response.status_code == 200:
            json_response = response.json()
            if 'groups' in json_response:
                groups = json_response['groups']
                for group in groups:
                    if group.get('name') == group_name:
                        logger.info(f"VESS-Request-ID : {vessrequestid} CDS-ID : {cdsid} - '{group_name}' is present in user's groups")
                        return True
                logger.info(f"VESS-Request-ID : {vessrequestid} CDS-ID : {cdsid} - '{group_name}' is NOT present in user's groups")
                return False
            else:
                logger.error(f"VESS-Request-ID : {vessrequestid} CDS-ID : {cdsid} - 'groups' key not found in response")
                return None       
        else:
            logger.error(f"VESS-Request-ID : {vessrequestid} CDS-ID : {cdsid} - API Error {response.status_code} - {response.reason}")
            return None      
    except requests.exceptions.RequestException as e:
        logger.error(f"VESS-Request-ID : {vessrequestid} CDS-ID : {cdsid} - Request Exception: {e}")
        return None

def find_group_name(all_groups, oem, role):
    oem_lower = oem.lower()
    role_lower = role.lower()
    for group_name in all_groups:
        group_name_lower = group_name.lower()
        if oem_lower in group_name_lower and role_lower in group_name_lower:
            return group_name
    return None

def get_all_group_names(admin, ltoken, url):
    try:
        data = {
            'action': 'groups',
            'user': admin,
            'search' : '*',
            'limit': '10000000',
            'ltoken': ltoken
        } 
        response = requests.post(url, data=data)
        if response.status_code == 200:
            lines = response.text.splitlines()
            group_names = []
            for line in lines:
                try:
                    json_data = json.loads(line)
                    if 'name' in json_data:
                        group_names.append(json_data['name'])
                except json.JSONDecodeError as e:
                    logger.error(f"Error decoding JSON: {e}. Line: {line}")
            return group_names
        else:
            logger.error(f"API Error fetching all groups: {response.status_code} - {response.reason}")
            return None
    except requests.exceptions.RequestException as e:
        logger.error(f"Request Exception while fetching groups: {e}")
        return None
    
def create_backup(group_name, user_list, cdsid):
    backup_dir = 'backup'
    if not os.path.exists(backup_dir):
        os.makedirs(backup_dir)
    file_path = os.path.join(backup_dir, f"{group_name}.txt")
    with open(file_path, 'w') as file:
        file.write(f"UserList: {','.join(user_list)}\n")
        file.write(f"NewUser: {cdsid}\n")
    
def clearMailContent(text, filename):
    with open(filename, 'w') as file:
        file.write(text)

def createMailContent(text, filename):
    with open(filename, 'a') as file:
        file.write(text)

def SendEmail(msg_content, filename=None):
    msg = EmailMessage()
    msg['To'] = ToList
    msg['From'] = From
    msg['Subject'] = Subject
    msg.set_content(msg_content, subtype='html')

    if filename:
        with open(filename, "rb") as file:
            file_data = file.read()
        msg.add_attachment(file_data, maintype='application', subtype='octet-stream', filename=os.path.basename(filename))

    with smtplib.SMTP(SMTP_Server, SMTP_Port) as server:
        server.starttls()
        server.send_message(msg)

def SendNotification(message_body,ToList,Subject):
        msg = EmailMessage()
        msg['To'] = ToList
        msg['From'] = From
        msg['Subject'] = Subject
        msg.set_content(message_body)
        server = smtplib.SMTP(SMTP_Server, SMTP_Port)
        server.starttls()
        server.send_message(msg)
        server.quit()


#============================================ VESS RELATED FUNCTIONS Starts ====================================================== 

def read_VESS_Table():
    logger.info("Establishing Connection with VESS DB")
    try:
        conn = oracledb.connect(user=Oracle_username, password=Oracle_pwd, dsn=dsn)
        cursor = conn.cursor()
        sql_query = """ SELECT *
                        FROM VESS.VESS72_KLOCWORK_RQST_DATA
                        WHERE VESS_REQUEST IN (
                            SELECT VESS_REQUEST
                            FROM VESS.VESS73_KLOCWORK_RQST_STATUS
                            WHERE REQUEST_STATUS = 'P'
                        )
                        AND ACTION_TYPE IN ('A')
                        ORDER BY KLOCWORK_SERVER, UPDATE_DATE"""
        cursor.execute(sql_query)
        rows = cursor.fetchall()
        result = []
        for row in rows:
            row_dict = {}
            for i, column in enumerate(cursor.description):
                row_dict[column[0]] = row[i]
            result.append(row_dict)
        cursor.close()
        conn.close()
        return result
    except oracledb.DatabaseError as e:
        logger.error(f"Database Error while read_VESS_Table(): {e}")
        return None

def update_VESS_Table(artifactoryResult):
    logger.info("Establishing connection with VESS-DB to update request status")
    try:
        now = datetime.now()
        datevar = now.strftime('%d-%b-%y')
        with oracledb.connect(user=Oracle_username, password=Oracle_pwd, dsn=dsn) as connection:
            with connection.cursor() as cursor:
                for result in artifactoryResult:
                    update_query = """UPDATE VESS.VESS73_KLOCWORK_RQST_STATUS SET
                                      REQUEST_STATUS = :status, UPDATE_DATE = :datevar 
                                      WHERE VESS_REQUEST = :VESS_Id"""
                    cursor.execute(update_query, [result[1], datevar, result[0]])
                connection.commit()
                # FIX: Removed `cursor.getbatcherrors()` which caused the 'NoneType' crash.
                return True
    except oracledb.DatabaseError as error:
        logger.error(f"Database Error in update_VESS_Table: {error}")
        return False

def mainFn():
    logger.info("<<< Script Execution has successfully Started >>>")
    
    timestamp_str = datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    clearMailContent('', mailFile)
    createMailContent(f"=====================================================\n", mailFile)
    createMailContent(f"            KLOCKWORK ACCESS REQUEST REPORT\n", mailFile)
    createMailContent(f"=====================================================\n", mailFile)
    createMailContent(f"        Report Generated On:  {timestamp_str}\n", mailFile)
    createMailContent("-----------------------------------------------------\n\n", mailFile)

    try:
        requestList = read_VESS_Table()
    
        if requestList is None:
            logger.error("Error while connecting to database. Aborting execution.")
            error_message = f"<p>Dear Team,</p><br><p>An error occurred while attempting to connect to the database on {timestamp_str}.</p>"
            SendEmail(error_message)
            return
        elif len(requestList) <= 0:
            logger.success("No User request found")
            return
        else:
            total_requests = len(requestList)
            failed_requests = 0
            failed_request_ids = []
            total_pending_request = 0
            pending_request_ids = []
            non_reachable_instances = UNAVAILABLE_SERVERS
            KlockworkResult = []

            for request in requestList:
                createMailContent("=====================================================\n", mailFile)
                action_type = request.get("ACTION_TYPE") 
                
                if action_type == 'A':
                    instance = request.get("KLOCWORK_SERVER")
                    vessrequestid = request.get("VESS_REQUEST")
                    cdsid = request.get("CDSID")
                    role = request.get("ROLE")
                    OEM = request.get("OEM")

                    logger.info(f"Processing Request: ID={vessrequestid}, CDSID={cdsid}, Role={role}, OEM={OEM}")

                    if role.lower() == "lead - managers are to approve only for leads":
                        role = "Lead"

                    url, admin, ltoken = KLOCKWORK_AUTH_OBJECT[instance] 
                    url = f"https://{url}/review/api"
                    
                    createMailContent(f"REQUEST TYPE:          {action_type}\n", mailFile)
                    createMailContent(f"VESS REQUEST ID:       {vessrequestid}\n", mailFile)
                    createMailContent(f"CDS ID:                {cdsid}\n", mailFile)
                    createMailContent(f"ROLE:                  {role}\n", mailFile)
                    createMailContent(f"OEM:                   {OEM}\n", mailFile)
                    createMailContent(f"INSTANCE:              {instance}\n", mailFile)
                    
                    if instance in UNAVAILABLE_SERVERS:
                        total_pending_request += 1
                        pending_request_ids.append(vessrequestid)
                        logger.error(f"VESS-Request-ID: {vessrequestid} CDS-ID: {cdsid} - Server '{instance}' is not Reachable") 
                        continue

                    role_lower = role.lower()
                    lookup_key = (instance, OEM, role_lower)
                    
                    # Cleaned up OEM logic
                    if lookup_key in OEM_GROUP_MAPPING:
                        group_name = OEM_GROUP_MAPPING[lookup_key]
                    else:
                        all_groups = get_all_group_names(admin, ltoken, url)
                        # FIX: Added check to prevent 'NoneType' crash if API returns 500 error
                        if all_groups is None:
                            group_name = None
                        else:
                            group_name = find_group_name(all_groups, OEM, role)
                        
                    if group_name is not None:
                        result = check_current_user_access(admin, cdsid, group_name, ltoken, url, vessrequestid)
                        
                        if result is True:
                            logger.success(f"VESS-Request-ID: {vessrequestid} CDS-ID: {cdsid} - Approved (Already in group)")
                            KlockworkResult.append((vessrequestid, 'S'))
                            createMailContent("REQUEST STATUS:        Approved\n\n", mailFile)
                            
                        elif result is False:
                            user_list = get_group_users(admin, url, group_name, ltoken)
                            if user_list is None or len(user_list) == 0:
                                failed_requests += 1
                                failed_request_ids.append(vessrequestid)
                                logger.error(f"VESS-Request-ID: {vessrequestid} CDS-ID: {cdsid} - Rejected. No users found in group '{group_name}'")
                                KlockworkResult.append((vessrequestid, 'F'))
                                createMailContent(f"REQUEST STATUS:        Manually needed to be completed [ Fetched empty user list for group '{group_name}' ]\n\n", mailFile)
                            else:
                                create_backup(group_name, user_list, cdsid)
                                user_list.append(cdsid)
                                user_string = ','.join(user_list)

                                if give_user_access(admin, cdsid, group_name, ltoken, url, user_string, vessrequestid):
                                    logger.success(f"VESS-Request-ID: {vessrequestid} CDS-ID: {cdsid} - Approved (Added to group)")
                                    KlockworkResult.append((vessrequestid, 'S'))
                                    createMailContent("REQUEST STATUS:        Approved\n\n", mailFile)
                                else:
                                    failed_requests += 1
                                    failed_request_ids.append(vessrequestid)
                                    logger.error(f"VESS-Request-ID: {vessrequestid} CDS-ID: {cdsid} - Rejected. API Failure adding user.")
                                    KlockworkResult.append((vessrequestid, 'F'))
                                    createMailContent(f"REQUEST STATUS:        Manually needed to be completed [API Failure to add user '{cdsid}' to group '{group_name}' ]\n\n", mailFile)
                        else:
                            failed_requests += 1
                            failed_request_ids.append(vessrequestid)
                            logger.error(f"VESS-Request-ID: {vessrequestid} CDS-ID: {cdsid} - Rejected. Unable to check user current groups.")
                            KlockworkResult.append((vessrequestid, 'F'))
                            createMailContent(f"REQUEST STATUS:        Manually needed to be completed [ Unable to check user '{cdsid}' current groups ]\n\n", mailFile)
                    else:
                        failed_requests += 1
                        failed_request_ids.append(vessrequestid)
                        logger.error(f"VESS-Request-ID: {vessrequestid} CDS-ID: {cdsid} - Rejected. Unable to find Group for OEM '{OEM}' and Role '{role}'")
                        KlockworkResult.append((vessrequestid, 'F'))
                        createMailContent(f"REQUEST STATUS:        Manually needed to be completed [ Unable to get Group for OEM '{OEM}' and Role '{role}' ]\n\n", mailFile)
                

            if update_VESS_Table(KlockworkResult):
                logger.success("Status updated Successfully in the VESS-DB")
                email_body = f"""
                <p>Dear Team,</p><br>
                <p>Please find below the summary of the user access requests processed on {timestamp_str}.</p><br>
                <table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse;">
                    <tr><th>Total Requests</th><td>{total_requests}</td></tr>
                    <tr><th>Total Successfull Requests</th><td>{total_requests - (failed_requests + total_pending_request)}</td></tr>
                    <tr><th>Total Failed Requests</th><td>{failed_requests}</td></tr>
                    <tr><th>Failed Requests IDs</th><td>{'-' if not failed_request_ids else ','.join(f"'{item}'" for item in failed_request_ids)}</td></tr>
                    <tr><th>Total Pending Requests</th><td>{total_pending_request}</td></tr>
                    <tr><th>Pending Requests IDs</th><td>{'-' if not pending_request_ids else ','.join(f"'{item}'" for item in pending_request_ids)}</td></tr>
                    <tr><th>Non-Reachable Instances</th><td>{'-' if not non_reachable_instances else ','.join(f"'{item}'" for item in non_reachable_instances)}</td></tr>
                </table><br>
                <p>Best Regards,<br>Your Automation System</p>
                """
                SendEmail(email_body, mailFile)
            else:
                logger.error("Failed to update status in the VESS-DB")
                
    except Exception as error:
        # loguru allows you to log exceptions with full tracebacks easily
        logger.exception(f"Unhandled Exception occurred: {str(error)}")

if __name__ == "__main__":
    mainFn()