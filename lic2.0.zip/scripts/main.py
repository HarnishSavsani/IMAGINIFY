#!/usr/bin/env python3
import asyncio
import sys
from pathlib import Path
from loguru import logger

# Import our custom modules
from config_loader import load_config
from logger_setup import setup_logger
from license_parser import parse_lm_output, parse_ds_output
from executor import run_command_safe, save_log, run_ds_command_interactive, ds_session_manager
from http_scraper import process_http_server
from queue_logger import file_writer_worker, log_cleanup_worker


# Auto-detect root directory
SCRIPT_DIR = Path(__file__).resolve().parent
BASE_DIR = SCRIPT_DIR.parent

# Set to track running tasks and prevent overlaps (e.g., SALT taking 10 mins)
active_tasks = set()

async def process_ds_server(group, server, base_dir, timeout):
    server["port"] = group.get("port", 4084) 
    server_id = f"ds_{group['name']}_{server['hostname']}"
    if server_id in active_tasks: return
    active_tasks.add(server_id)
    
    try:
        # Auto-detect OS and pick the corresponding path from config
        is_windows = sys.platform == "win32"
        exe_path = group.get("exe_path_windows") if is_windows else group.get("exe_path_linux")
        
        # Fallback to the old key for backward compatibility
        if not exe_path:
            exe_path = group.get("exe_path")

        # ENTERPRISE FIX: Use Session Manager for Windows, One-Shot Interactive for Linux
        if is_windows:
            output, err = await ds_session_manager.fetch_usage(
                exe_path, server['hostname'], server['port'], group['password'], timeout
            )
        else:
            output, err = await run_ds_command_interactive(
                exe_path, server['hostname'], server['port'], group['password'], timeout
            )
        
        if err:
            await save_log(base_dir, "dslicsrv", group["name"], server, [], "error", err)
        elif not output or "Dassault Systemes" not in output:
            await save_log(base_dir, "dslicsrv", group["name"], server, [], "error", "Invalid or empty session output")
        else:
            features = parse_ds_output(output)
            await save_log(base_dir, "dslicsrv", group["name"], server, features, "ok")
    finally:
        active_tasks.remove(server_id)

async def process_server(group: dict, server: dict, base_dir: Path, timeout: int, sem: asyncio.Semaphore):
    """Runs the LM tool for a specific server, preventing overlap."""
    server["port"] = group.get("port", "—")

    server_id = f"{group['name']}_{server['hostname']}"

    if server_id in active_tasks:
        return False

    active_tasks.add(server_id)
    success = False
    
    try:
        tool = group["tool"]
        exe_ext = ".exe" if sys.platform == "win32" else ""
        exe_path = base_dir / f"{tool}{exe_ext}"
        
        if not exe_path.is_file():
            await save_log(base_dir, tool, group["name"], server, [], "error", f"Missing binary: {exe_path.name}")
            return False

        cmd_name = "lmstat" if tool != "rlmutil" else "rlmstat"
        cmd = [str(exe_path), cmd_name, "-c", f"{group['port']}@{server['hostname']}", "-a"]

        output, err = await run_command_safe(cmd, timeout, sem)

        if err:
            await save_log(base_dir, tool, group["name"], server, [], "error", err)
        else:
            # We now pass group["name"] to grab the correct Regex override
            features = parse_lm_output(output, tool, group["name"])
            
            if features:
                await save_log(base_dir, tool, group["name"], server, features, "ok")
                success = True
            else:
                await save_log(base_dir, tool, group["name"], server, [], "error", "No features parsed from output")
                
    finally:
        active_tasks.remove(server_id)
        
    return success

async def run_triad_group(group: dict, base_dir: Path, timeout: int, sem: asyncio.Semaphore):
    """Executes Triad failover. Stops querying once a server successfully responds."""
    group_id = f"triad_{group['name']}"
    if group_id in active_tasks: return
    active_tasks.add(group_id)
    
    try:
        servers = group.get("servers", [])
        for server in servers:
            success = await process_server(group, server, base_dir, timeout, sem)
            if success:
                # If triad succeeds, do not query the remaining redundant servers
                if len(servers) > 1:
                    logger.info(f"Triad SUCCESS for {group['name']} on {server['hostname']}. Skipping backups.")
                break 
        else:
            # The else block executes only if the loop finishes without hitting the 'break'
            logger.error(f"CRITICAL: License Down. All servers in group '{group['name']}' failed.")
    finally:
        active_tasks.remove(group_id)


async def run_http_with_lock(source: dict, base_dir: Path, timeout: int, source_id: str):
    """Wrapper to ensure HTTP tasks release their lock when finished."""
    try:
        await process_http_server(source, base_dir, timeout)
    finally:
        active_tasks.remove(source_id)


async def main_loop():
    """Main background scheduler loop."""
    setup_logger(BASE_DIR)
    logger.info(f"Project root detected: {BASE_DIR}")

    # --- START THE QUEUE WRITERS ---
    # These run infinitely in the background
    asyncio.create_task(file_writer_worker("lmutil", BASE_DIR))
    asyncio.create_task(file_writer_worker("rlmutil", BASE_DIR))
    asyncio.create_task(file_writer_worker("http", BASE_DIR))
    asyncio.create_task(file_writer_worker("catia", BASE_DIR))

    # Start the janitor (defaults to 30 days)
    asyncio.create_task(log_cleanup_worker(BASE_DIR, retention_days=30))
    # ------------------------------------
    
    config = load_config(BASE_DIR)
    lm_groups = config.get("lm_family", [])
    http_groups = config.get("http_sources", [])
    
    # Set timeouts and concurrency limits
    timeout = config.get("global", {}).get("command_timeout_seconds", 1000)
    http_timeout = 30  # Shorter timeout specifically for HTTP to prevent hanging on bad web servers
    max_parallel = config.get("global", {}).get("max_parallel_queries", 50)
    interval = config.get("collect", {}).get("interval_seconds", 60)
    
    sem = asyncio.Semaphore(max_parallel)
    
    logger.info(f"Starting continuous background loop. Interval: {interval}s")
    logger.info(f"Loaded {len(lm_groups)} LM groups and {len(http_groups)} HTTP sources.")

    while True:
        # 1. Fire off LM tasks (lmutil / rlmutil)
        for group in lm_groups:
            mode = group.get("mode", "individual").lower()
            
            if mode in ("triad", "individual"):
                # Run failover logic (stop on first success)
                asyncio.create_task(run_triad_group(group, BASE_DIR, timeout, sem))
                
            elif mode == "distributed":
                # Run all servers concurrently (don't skip any)
                for server in group.get("servers", []):
                    asyncio.create_task(process_server(group, server, BASE_DIR, timeout, sem))
                
        # 2. Fire off HTTP tasks (Tasking 422, etc.)
        for http_source in http_groups:
            source_id = f"http_{http_source['name']}"
            if source_id not in active_tasks:
                active_tasks.add(source_id)
                # Background execution for web scraping
                asyncio.create_task(run_http_with_lock(http_source, BASE_DIR, http_timeout, source_id))
        
        
        # 3. Fire off Dassault Systemes (Catia)
        ds_groups = config.get("ds_family", [])
        for group in ds_groups:
            for server in group.get("servers", []):
                # FIXED: Added BASE_DIR to the arguments
                asyncio.create_task(process_ds_server(group, server, BASE_DIR, timeout))

        # Wait exactly the configured interval before the next wave
        await asyncio.sleep(interval)


if __name__ == "__main__":
    if sys.platform == "win32":
        # Ensures clean event loop behavior on Windows
        asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())
        
    try:
        asyncio.run(main_loop())
    except KeyboardInterrupt:
        logger.info("Monitor stopped by user (Ctrl+C)")
    except Exception as e:
        logger.exception(f"Unexpected error in main: {e}")