import asyncio
import json
from pathlib import Path
from loguru import logger
from datetime import datetime, timedelta, timezone

# 1. Create three separate, dedicated queues (our "Message Broker" topics)
log_queues = {
    "lmutil": asyncio.Queue(),
    "rlmutil": asyncio.Queue(),
    "http": asyncio.Queue(),
    "catia": asyncio.Queue()
}

async def log_cleanup_worker(base_dir: Path, retention_days: int = 30):
    """
    Dedicated background janitor. 
    Wakes up once every 24 hours to delete logs older than retention_days.
    """
    logger.info(f"Started log cleanup worker (Retention: {retention_days} days)")
    
    while True:
        try:
            # Calculate the exact cutoff date
            cutoff_date = datetime.now(timezone.utc) - timedelta(days=retention_days)
            log_dir = base_dir / "logs"
            
            if log_dir.exists():
                # .rglob() recursively finds all .jsonl files in all subfolders
                for log_file in log_dir.rglob("*.jsonl"):
                    
                    # Get the file's last modified time
                    file_mtime = datetime.fromtimestamp(log_file.stat().st_mtime, tz=timezone.utc)
                    
                    # If it's older than our cutoff, delete it
                    if file_mtime < cutoff_date:
                        log_file.unlink() # Deletes the file
                        logger.info(f"Deleted old log file: {log_file.name}")
                        
        except Exception as e:
            logger.error(f"Log cleanup task encountered an error: {e}")
            
        # Go to sleep for 24 hours (86,400 seconds) before checking again
        await asyncio.sleep(86400)

async def file_writer_worker(tool: str, base_dir: Path):
    """
    Dedicated background consumer. 
    Because ONLY this single function ever touches this tool's file,
    we completely eliminate 'file in use' and resource locking errors.
    """
    logger.info(f"Started dedicated queue writer for: {tool}")
    
    while True:
        # Wait for a message to arrive in the queue
        entry = await log_queues[tool].get()
        
        try:
            # Determine file path (rolls over dynamically at midnight)
            date_str = datetime.now(timezone.utc).strftime("%Y-%m-%d")
            log_dir = base_dir / "logs" / tool
            log_dir.mkdir(parents=True, exist_ok=True)
            log_file = log_dir / f"{tool}-{date_str}.jsonl"

            # Write the single line instantly. 
            # We don't need threads here because this worker has an exclusive lock on the logic.
            with log_file.open("a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")
                
        except Exception as e:
            logger.error(f"Queue write failed for {tool}: {e}")
        finally:
            # Tell the queue the message was successfully processed
            log_queues[tool].task_done()