import asyncio
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Dict, Tuple, Optional
from loguru import logger
from license_parser import parse_lm_output
from queue_logger import log_queues
import redis.asyncio as redis


# Initialize global Redis Connection Pool
redis_client = redis.Redis(host='localhost', port=6379, decode_responses=True)

class DSManager:
    def __init__(self):
        self.process = None

    async def _read_until_prompt(self):
        """Reads stream until 'admin >' prompt appears to clear buffer."""
        output = ""
        try:
            while True:
                line = await asyncio.wait_for(self.process.stdout.readline(), timeout=5)
                if not line: break
                decoded = line.decode(errors="replace")
                output += decoded
                if "admin >" in decoded: break
        except asyncio.TimeoutError:
            pass
        return output

    async def get_session(self, exe_path, host, port, password):
        if self.process and self.process.returncode is None:
            return self.process

        self.process = await asyncio.create_subprocess_exec(
            exe_path, "-admin",
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        
        # Initial login
        self.process.stdin.write(f"connect {host} {port}\n".encode())
        await self.process.stdin.drain()
        await asyncio.sleep(1) # wait for password prompt
        
        self.process.stdin.write(f"{password}\n".encode())
        await self.process.stdin.drain()
        await self._read_until_prompt() # Clear greeting text
        return self.process

    async def fetch_usage(self, exe_path, host, port, password, timeout):
        try:
            proc = await self.get_session(exe_path, host, port, password)
            proc.stdin.write(b"getLicenseUsage -all\n")
            await proc.stdin.drain()
            
            # Read until prompt returns
            output = await self._read_until_prompt()
            return output, None
        except Exception as e:
            self.process = None # Force reconnect on next loop
            return None, str(e)

async def save_log(base_dir, tool, group_name, server, features, status="ok", error_msg=None):
    ts_str = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    queue_name = "catia" if tool == "dslicsrv" else ("lmutil" if tool == "lmutilnew" else tool)
    
    if status == "ok" and features:
        for feat in features:
            # 1. EXTRACT USERS (To prevent polluting Graylog logs)
            users_list = feat.pop("active_users", [])
            
            # 2. WRITE SUMMARY TO GRAYLOG (Unchanged pipeline)
            entry = {
                "ts": ts_str,
                "group": group_name,
                "tool": tool,
                "hostname": server["hostname"],
                "region": server.get("region", "—"),
                "port": server.get("port", "—"),
                "feature": feat["feature"],
                "total_issued": feat["total_issued"],
                "in_use": feat["in_use"],
                "status": "ok"
            }
            if "region_distribution" in feat:
                entry["region_distribution"] = feat["region_distribution"]
                
            log_queues[queue_name].put_nowait(entry)
            
            # 3. WRITE USERS TO REDIS (For React Frontend)
            if tool in ("lmutil", "lmutilnew", "rlmutil", "dslicsrv"):
                redis_key = f"license:live:{group_name}:{feat['feature']}"
                cleaned_users = []
                for u in users_list:
                    cleaned_users.append({
                        "Username": u.get("username", "—"),
                        "Hostname": u.get("hostname", "—"),
                        "Timestamp": u.get("checkout_time", "—")
                    })
                
                redis_payload = {
                    "Name": group_name,
                    "Feature": feat["feature"],
                    "Total Issued": feat["total_issued"],
                    "In Use": feat["in_use"],
                    "Last Updated": ts_str,
                    "users": cleaned_users
                }
                
                try:
                    # Set value with a 120-second TTL
                    await redis_client.setex(redis_key, 120, json.dumps(redis_payload))
                except Exception as e:
                    logger.error(f"Failed to push {redis_key} to Redis: {e}")

        logger.info(f"Queued {len(features)} features for {tool.upper()} / {group_name} ({server['hostname']})")
    else:
        # FIX 2: Catch and print errors so you aren't debugging blindly
        target_host = server.get("hostname", "Unknown")
        
        if status == "error":
            clean_err = str(error_msg).replace('\n', ' | ').replace('\r', '')
            logger.error(f"[TOOL: {tool}] | [GROUP: {group_name}] | [HOST: {target_host}] -> FAILED: {clean_err}")
        else:
            logger.error(f"[TOOL: {tool}] | [GROUP: {group_name}] | [HOST: {target_host}] -> FAILED: No features returned.")

async def run_command_safe(cmd: List[str], timeout: int, sem: asyncio.Semaphore) -> Tuple[Optional[str], Optional[str]]:
    """Standard runner for lmutil and rlmutil commands."""
    async with sem:
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
            
            if proc.returncode != 0:
                return None, stderr.decode(errors="replace")
            return stdout.decode(errors="replace"), None
        except asyncio.TimeoutError:
            return None, "Command timed out"
        except Exception as e:
            return None, str(e)

async def run_ds_command_interactive(exe_path, host, port, password, timeout):
    """Fallback interactive runner (optional, used if session manager is bypassed)."""
    try:
        proc = await asyncio.create_subprocess_exec(
            exe_path, "-admin",
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        proc.stdin.write(f"connect {host} {port}\n{password}\ngetLicenseUsage\nexit\n".encode())
        await proc.stdin.drain()
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        return stdout.decode(errors="replace"), None
    except Exception as e:
        return None, str(e)

# Global instance to maintain the session across loops
ds_session_manager = DSManager()