import re
from typing import List, Dict
from datetime import datetime

REGION_MAP = {
    'IN': 'Asia', 'CH': 'Asia', 'TW': 'Asia', 'JP': 'Asia',
    'DE': 'Europe', 'UK': 'Europe', 'FR': 'Europe', 'BG': 'Europe', 'RO': 'Europe',
    'US': 'North America', 'MX': 'North America', 'BR': 'South America'
}

# ==============================================================================
# 1. GLOBAL REGEX CONFIGURATION FOR USER EXTRACTION
# ==============================================================================
USER_REGEX = {
    "IBM": {
        "pattern": re.compile(r'^\s*(\S+)\s+(\S+)(?:\s+\S+)?\s+(.*?)\s+\([^)]+\)\s+\([^)]+\),?\s+start\s+(.+)$', re.IGNORECASE | re.MULTILINE),
        "mapping": ["username", "hostname", "token", "checkout_time"]
    },
    "SALT": {
        "pattern": re.compile(r'^\s*(\b\w+\b)\s+(\S+)\s+.*?start \w+ (\d{1,2}/\d{1,2} \d{1,2}:\d{2})', re.MULTILINE | re.IGNORECASE),
        "mapping": ["username", "hostname", "checkout_time"]
    },
    "DEFAULT_LMUTIL": {
        "pattern": re.compile(r'^\s*(.+?)\s+(\S+)(?:\s+\S+)?\s+.*?\([^)]+\),?\s+start\s+(.+)$', re.MULTILINE | re.IGNORECASE),
        "mapping": ["username", "hostname", "checkout_time"]
    }
}

# ==============================================================================
# 2. SYSTEM REGEX CONFIGURATION FOR STRUCTURAL PARSING
# ==============================================================================
SYSTEM_REGEX = {
    "DS_BLOCK": re.compile(r'\n\s*(\w+)\s+maxReleaseNumber:'),
    "DS_COUNT": re.compile(r'count:\s*(\d+)'),
    "DS_INUSE": re.compile(r'inuse:\s*(\d+)'),
    "DS_HOST":  re.compile(r'on host:\s*(\w+)'),
    "DS_USER":  re.compile(r'granted since:\s*(\d{1,2}/\d{1,2}/\d{2,4},\s*\d{1,2}:\d{2}:\d{2}\s*[APM]{2}).*?by user:\s*(\S+)\s+on host:\s*([A-Za-z0-9_-]+)', re.IGNORECASE | re.DOTALL),
    
    "LM_BLOCK":    re.compile(r'(?i)Users of\s+'),
    "LM_HEADER":   re.compile(r'^([^:]+):\s*\((.*?)\)'),
    "LM_TOTALS":   re.compile(r'Total of\s+(\d+).*?Total of\s+(\d+)', re.IGNORECASE),
    "LM_LICENSES": re.compile(r'(.*?),\s*(\d+)\s+licenses?', re.IGNORECASE),
    
    "RLM_POOL":  re.compile(r'^\s*([^,\n]+)[^\n]*\n\s*count:\s*(\d+).*?inuse:\s*(\d+)', re.IGNORECASE | re.MULTILINE),
    "RLM_USAGE": re.compile(r'([^:\n]+):\s+([^@\s]+)@(\S+)\s+(\d+)/\d+\s+at\s+(.*?)\s*\(handle:', re.IGNORECASE)
}

def normalize_timestamp(raw_time_str: str) -> str:
    """
    Converts varied vendor timestamps ('06/22 19:55', 'Mon 6/22 12:46')
    into a strict 'DD-MM-YYYY HH:MM:SS' format with year inference.
    """
    if not raw_time_str or raw_time_str == "—":
        return raw_time_str

    try:
        # 1. Isolate the date and time parts (ignores words like "Mon")
        parts = raw_time_str.split()
        if len(parts) < 2:
            return raw_time_str
            
        date_part, time_part = parts[-2], parts[-1]
        
        # 2. Extract the numbers
        month, day = map(int, date_part.split('/'))
        hour, minute = map(int, time_part.split(':'))
        
        # 3. Infer the Year
        now = datetime.now()
        year = now.year
        
        # If it's currently January, but the parsed month is December, 
        # the checkout happened last year.
        if month > now.month + 1:
            year -= 1
            
        # 4. Construct the datetime object (Defaulting seconds to 00)
        dt = datetime(year, month, day, hour, minute, 0)
        
        # 5. Return the exact requested format: DD-MM-YYYY HH:MM:SS
        return dt.strftime("%d-%m-%Y %H:%M:%S")
        
    except Exception:
        # If anything fails, return the original string so it doesn't crash
        return raw_time_str

def get_region_from_host(hostname: str) -> str:
    prefix = hostname[:2].upper()
    return REGION_MAP.get(prefix, "Unknown")

def parse_catia_timestamp(raw_time_str: str) -> str:
    """Converts Catia '6/23/26, 8:55:45 PM' to '23-06-2026 20:55:45'"""
    try:
        dt = datetime.strptime(raw_time_str.strip(), "%m/%d/%y, %I:%M:%S %p")
        return dt.strftime("%d-%m-%Y %H:%M:%S")
    except Exception:
        return raw_time_str

def parse_ds_output(output: str) -> List[Dict]:
    if not output: return []
    output = output.replace('\r', '') 
    
    feature_totals = {}
    blocks = SYSTEM_REGEX["DS_BLOCK"].split(output)
    
    for i in range(1, len(blocks), 2):
        name = blocks[i].strip()
        content = blocks[i+1]
        
        count_match = SYSTEM_REGEX["DS_COUNT"].search(content)
        inuse_match = SYSTEM_REGEX["DS_INUSE"].search(content)
        
        if count_match and inuse_match:
            total = int(count_match.group(1))
            used = int(inuse_match.group(1))
            
            # AGGREGATION: Handles multiple blocks of the same feature (e.g., HD2)
            if name not in feature_totals:
                feature_totals[name] = {
                    "feature": name,
                    "total_issued": 0,
                    "in_use": 0,
                    "active_users": []
                }
            
            feature_totals[name]["total_issued"] += total
            feature_totals[name]["in_use"] += used
            
            # Extract concurrent users
            for user_match in SYSTEM_REGEX["DS_USER"].finditer(content):
                raw_time = user_match.group(1).strip()
                username = user_match.group(2).strip()
                hostname = user_match.group(3).strip()
                
                clean_time = parse_catia_timestamp(raw_time)
                
                feature_totals[name]["active_users"].append({
                    "username": username,
                    "hostname": hostname,
                    "checkout_time": clean_time
                })
                
    return list(feature_totals.values())

def parse_lm_output(output: str, tool: str, group_name: str) -> List[Dict]:
    if not output:
        return []
        
    output = output.replace('\r', '') 
    features = []

    if tool in ("lmutil", "lmutilnew"):
        regex_config = USER_REGEX.get(group_name, USER_REGEX["DEFAULT_LMUTIL"])
        pattern = regex_config["pattern"]
        mapping = regex_config["mapping"]

        blocks = SYSTEM_REGEX["LM_BLOCK"].split(output)[1:] 
        
        for block in blocks:
            header_match = SYSTEM_REGEX["LM_HEADER"].search(block)
            if not header_match:
                continue
                
            feature_name = header_match.group(1).strip()
            details = header_match.group(2).strip()
            
            total_issued = 0
            in_use = 0
            is_uncounted = False
            
            if "Uncounted" in details:
                is_uncounted = True
                total_issued = 9999999 
            else:
                counts = SYSTEM_REGEX["LM_TOTALS"].search(details)
                if counts:
                    total_issued = int(counts.group(1))
                    in_use = int(counts.group(2))
                else:
                    continue

            feature_dict = {
                "feature": feature_name,
                "total_issued": total_issued,
                "in_use": in_use,
                "active_users": []
            }

            if is_uncounted or feature_dict["in_use"] > 0:
                for user_match in pattern.finditer(block):
                    user_obj = {}
                    for i, key in enumerate(mapping):
                        val = user_match.group(i+1)
                        user_obj[key] = val.strip() if val else "—"
                            
                    user_obj["licenses_used"] = 1 
                    
                    if "checkout_time" in user_obj:
                        if "license" in user_obj["checkout_time"].lower():
                            lic_match = SYSTEM_REGEX["LM_LICENSES"].search(user_obj["checkout_time"])
                            if lic_match:
                                user_obj["checkout_time"] = lic_match.group(1).strip()
                                user_obj["licenses_used"] = int(lic_match.group(2))
                                
                        user_obj["checkout_time"] = normalize_timestamp(user_obj["checkout_time"])

                    feature_dict["active_users"].append(user_obj)
                
                if is_uncounted:
                    feature_dict["in_use"] = sum(u.get("licenses_used", 1) for u in feature_dict["active_users"])
                
            features.append(feature_dict)

    elif tool == "rlmutil":
        feature_map = {}
        
        for match in SYSTEM_REGEX["RLM_POOL"].finditer(output):
            feat_name = match.group(1).strip().split()[0]
            feature_map[feat_name] = {
                "feature": feat_name,
                "total_issued": int(match.group(2)),
                "in_use": int(match.group(3)),
                "active_users": [] 
            }

        for match in SYSTEM_REGEX["RLM_USAGE"].finditer(output):
            feat_name = match.group(1).strip().split()[0]
            
            user_obj = {
                "username": match.group(2).strip(),
                "hostname": match.group(3).strip(),
                "licenses_used": int(match.group(4)),
                "checkout_time": normalize_timestamp(match.group(5).strip())
            }
            
            if feat_name in feature_map:
                feature_map[feat_name]["active_users"].append(user_obj)
            else:
                feature_map[feat_name] = {
                    "feature": feat_name,
                    "total_issued": 9999999, 
                    "in_use": 0,
                    "active_users": [user_obj]
                }
                
        # 3. Synchronize usage counts & Deduplicate Shared Licenses
        for feat in feature_map.values():
            
            # Deduplicate RLM users by username + hostname
            unique_users = {}
            for u in feat["active_users"]:
                key = f"{u['username']}@{u['hostname']}"
                if key not in unique_users:
                    unique_users[key] = u
                    
            feat["active_users"] = list(unique_users.values())

            # Recalculate
            calc_in_use = sum(u.get("licenses_used", 1) for u in feat["active_users"])
            
            # If dynamic token licenses were added, or if sum of active users exceeds reported in_use, fix it.
            if calc_in_use > feat["in_use"]:
                feat["in_use"] = calc_in_use
                
        features = list(feature_map.values())

    return features