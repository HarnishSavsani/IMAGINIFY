import sys
from pathlib import Path
from loguru import logger

def setup_logger(base_dir: Path):
    error_log = base_dir / "logs" / "errors" / "error-{time:YYYY-MM-DD}.log"
    error_log.parent.mkdir(parents=True, exist_ok=True)

    logger.remove()
    
    # Console output
    logger.add(
        sys.stderr,
        format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{message}</cyan>",
        level="INFO",
        colorize=True
    )
    
    # Rotating error file
    logger.add(
        str(error_log),
        rotation="00:00",
        retention="14 days",
        level="ERROR",
        encoding="utf-8"
    )