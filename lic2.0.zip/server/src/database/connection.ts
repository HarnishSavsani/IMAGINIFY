import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';
import { config } from '../config';

const dbPath = path.resolve(process.cwd(), config.SQLITE_DB_PATH);
const dirPath = path.dirname(dbPath);

if (!fs.existsSync(dirPath)) {
  fs.mkdirSync(dirPath, { recursive: true });
}

export const db = new Database(dbPath);

// Use simple DELETE journal mode — no WAL/SHM files, perfect for single-container setups
db.pragma('journal_mode = DELETE');

// Performance: keep synchronous writes safe but not overly slow
db.pragma('synchronous = NORMAL');

export function initDatabase() {
  // Create tables if they do not exist
  db.exec(`
    CREATE TABLE IF NOT EXISTS licenses (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      ab TEXT NOT NULL,
      type TEXT NOT NULL,
      port INTEGER NOT NULL,
      sv INTEGER NOT NULL,
      reg TEXT NOT NULL,
      col TEXT NOT NULL,
      desc TEXT NOT NULL,
      expiry TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Active',
      osType TEXT,
      lingerTime TEXT,
      dashboardUrl TEXT,
      title TEXT,
      aliases TEXT
    );

    CREATE TABLE IF NOT EXISTS applications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Active',
      health_status TEXT DEFAULT 'Active',
      latency INTEGER,
      url TEXT NOT NULL,
      category TEXT NOT NULL,
      auth_type TEXT DEFAULT 'none',
      auth_token TEXT,
      last_checked TEXT
    );

    CREATE TABLE IF NOT EXISTS admins (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      cdsid TEXT NOT NULL UNIQUE,
      email TEXT NOT NULL,
      role TEXT DEFAULT 'admin',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS notification_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sender_cdsid TEXT NOT NULL,
      target_username TEXT NOT NULL,
      license_name TEXT NOT NULL,
      feature TEXT NOT NULL,
      sent_at TEXT NOT NULL,
      status TEXT NOT NULL
    );
  `);

  // Migration for health_status column if missing in older schema
  try {
    db.exec(`ALTER TABLE applications ADD COLUMN health_status TEXT DEFAULT 'Active'`);
  } catch (e) {}

  // Migration for title and aliases column if missing in older schema
  try {
    db.exec(`ALTER TABLE licenses ADD COLUMN title TEXT`);
  } catch (e) {}
  try {
    db.exec(`ALTER TABLE licenses ADD COLUMN aliases TEXT`);
  } catch (e) {}

  // Backfill title and aliases for existing rows
  try {
    db.exec(`UPDATE licenses SET title = name WHERE title IS NULL OR title = ''`);
    db.exec(`UPDATE licenses SET aliases = '["' || name || '"]' WHERE aliases IS NULL OR aliases = ''`);
  } catch (e) {}

  // Ensure default admin exists
  try {
    const adminCount = (db.prepare('SELECT COUNT(*) as count FROM admins').get() as any).count;
    if (adminCount === 0) {
      db.prepare(`
        INSERT INTO admins (cdsid, email, role, created_at)
        VALUES ('admin', 'admin@visteon.com', 'admin', datetime('now'))
      `).run();
      console.log('🌱 Seeded default admin account.');
    }
  } catch (e) {}

  console.log('✅ SQLite Database initialized at:', dbPath);
}

// Close database cleanly on exit
process.on('exit', () => { try { db.close(); } catch (e) {} });
process.on('SIGINT', () => { try { db.close(); } catch (e) {} process.exit(0); });
process.on('SIGTERM', () => { try { db.close(); } catch (e) {} process.exit(0); });
