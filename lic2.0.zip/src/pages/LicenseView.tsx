import { useState, useMemo, useRef, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import {
  ChevronLeft,
  Search,
  Download,
  Bell,
  ChevronDown,
  ChevronUp,
  ChevronsUpDown,
  Check,
  MoreHorizontal,
  CirclePlus,
  SlidersHorizontal,
  Filter,
  ChevronsLeft,
  ChevronRight,
  ChevronsRight,
  Loader2,
  Globe,
  Monitor,
  Timer,
  Clipboard,
  Eye
} from 'lucide-react';
import { FaWindows, FaApple, FaUbuntu, FaLinux } from 'react-icons/fa';
import { SiCentos, SiRedhat } from 'react-icons/si';
import { toast } from 'sonner';
import { useLiveUsage } from '../hooks/useLiveUsage';
import { ApiClient } from '../lib/api';
import { StorageService } from '../utils/storage';
import { License } from '../types';

const ENABLE_NOTIFICATIONS = false; // Toggle email notification features


function OsIcon({ os }: { os: string }) {
  const osLower = os.toLowerCase();
  if (osLower.includes('windows')) return <FaWindows {...({ className: "w-3.5 h-3.5 text-purple-500" } as any)} />;
  if (osLower.includes('ubuntu')) return <FaUbuntu {...({ className: "w-3.5 h-3.5 text-orange-500" } as any)} />;
  if (osLower.includes('mac') || osLower.includes('apple')) return <FaApple {...({ className: "w-3.5 h-3.5 text-gray-700 dark:text-zinc-300" } as any)} />;
  if (osLower.includes('centos')) return <SiCentos {...({ className: "w-3.5 h-3.5 text-green-600" } as any)} />;
  if (osLower.includes('redhat') || osLower.includes('rhel')) return <SiRedhat {...({ className: "w-3.5 h-3.5 text-red-500" } as any)} />;
  if (osLower.includes('linux')) return <FaLinux {...({ className: "w-3.5 h-3.5 text-yellow-500" } as any)} />;
  return <Monitor className="w-3.5 h-3.5 text-purple-500" />;
}

const DEFAULT_LICENSE: any = { id: "-1", name: "License", type: "FlexLM", col: "#2563eb", ab: "LC" };

const ALL_COLUMNS = ['User', 'Host Name', 'Region', 'Timestamp'];
const DEFAULT_VISIBLE_COLUMNS = ['User', 'Host Name', 'Region', 'Timestamp'];

function getUsageColor(inUse: number, total: number) {

  const percent = inUse / total;
  if (percent >= 0.8) return "text-red-700 dark:text-red-400 bg-red-100 dark:bg-red-900/30 border-red-200 dark:border-red-900";
  if (percent >= 0.5) return "text-orange-700 dark:text-orange-400 bg-orange-100 dark:bg-orange-900/30 border-orange-200 dark:border-orange-900";
  return "text-green-700 dark:text-green-400 bg-green-100 dark:bg-green-900/30 border-green-200 dark:border-green-900";
}

function getUsageColorScale(inUse: number, total: number) {
  const percent = inUse / total;
  if (percent >= 0.8) return 3;
  if (percent >= 0.5) return 2;
  return 1;
}

function getRegionFromHost(host: string) {
  if (!host) return "N/A";
  const h = host.toUpperCase();
  if (h.startsWith("IN")) return "India";
  if (h.startsWith("FR")) return "France";
  if (h.startsWith("BG")) return "Bulgaria";
  if (h.startsWith("US")) return "USA";
  if (h.startsWith("MX")) return "Mexico";
  if (h.startsWith("DE")) return "Germany";
  if (h.startsWith("CN")) return "China";
  if (h.startsWith("JP")) return "Japan";
  if (h.startsWith("GB") || h.startsWith("UK")) return "United Kingdom";
  if (h.startsWith("BR")) return "Brazil";
  if (h.startsWith("SG")) return "Singapore";
  if (h.startsWith("AU")) return "Australia";
  return "N/A";
}

const getBadgeStyle = (type: string) => {
  if (type === 'FlexLM') return "bg-blue-100/50 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400 border-blue-200 dark:border-blue-800";
  if (type === 'RLM') return "bg-emerald-100/50 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800";
  if (type === 'Tasking') return "bg-amber-100/50 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400 border-amber-200 dark:border-amber-800";
  if (type === 'DSLS') return "bg-red-100/50 text-red-700 dark:bg-red-900/30 dark:text-red-400 border-red-200 dark:border-red-800";
  let hash = 0;
  for (let i = 0; i < type.length; i++) {
    hash = type.charCodeAt(i) + ((hash << 5) - hash);
  }
  const i = Math.abs(hash) % 4;
  const classes = [
    "bg-purple-100/50 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400 border-purple-200 dark:border-purple-800",
    "bg-cyan-100/50 text-cyan-700 dark:bg-cyan-900/30 dark:text-cyan-400 border-cyan-200 dark:border-cyan-800",
    "bg-indigo-100/50 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-400 border-indigo-200 dark:border-indigo-800",
    "bg-pink-100/50 text-pink-700 dark:bg-pink-900/30 dark:text-pink-400 border-pink-200 dark:border-pink-800",
  ];
  return classes[i];
};

export default function LicenseView() {
  const { id } = useParams();
  const [license, setLicense] = useState<any>(DEFAULT_LICENSE);

  useEffect(() => {
    if (id) {
      ApiClient.getLicenseById(id)
        .then(data => {
          if (data) setLicense(data);
        })
        .catch(() => { });
    }
  }, [id]);

  const { usageData: liveRawData, isLoading, isOnline, isConnected } = useLiveUsage(license.name, license.aliases);


  const [usageData, setUsageData] = useState<any[]>([]);
  const [featureStats, setFeatureStats] = useState<Record<string, { inUse: number, total: number }>>({});
  const [availableColumns, setAvailableColumns] = useState<string[]>([...ALL_COLUMNS]);

  useEffect(() => {
    if (!liveRawData) {
      setUsageData([]);
      setFeatureStats({});
      return;
    }

    const newUsageData: any[] = [];
    const newFeatureStats: Record<string, { inUse: number, total: number }> = {};
    const newCols = new Set([...ALL_COLUMNS]);



    let rowId = 0;
    liveRawData.forEach(featureGroup => {
      newFeatureStats[featureGroup.Feature] = {
        inUse: featureGroup["In Use"],
        total: featureGroup["Total Issued"]
      };

      featureGroup.users.forEach(u => {
        const row: any = {
          id: (rowId++).toString(),
          feature: featureGroup.Feature,
          user: u.Username,
          host: u.Hostname,
          timestamp: u.Timestamp,
          region: featureGroup.Region || getRegionFromHost(u.Hostname),
          name: featureGroup.Name
        };

        Object.keys(u).forEach(k => {
          if (!['Username', 'Hostname', 'Timestamp'].includes(k)) {
            row[k] = u[k];
            newCols.add(k);
          }
        });

        newUsageData.push(row);
      });
    });

    setAvailableColumns(Array.from(newCols));
    setUsageData(newUsageData);
    setFeatureStats(newFeatureStats);
  }, [liveRawData]);

  const handleRequestRelease = async (row: any) => {
    const senderCdsid = StorageService.getItem<string>('portal_cdsid', 'User');
    const toastId = toast.loading(`Sending release request to ${row.user}...`);
    try {
      const res = await ApiClient.sendReleaseRequest({
        senderCdsid,
        targetUsername: row.user,
        licenseName: license.name,
        feature: row.feature,
        hostname: row.host,
        checkoutTimestamp: row.timestamp,
      });
      if (res.success) {
        toast.success(`Release request email sent to ${row.user}`, { id: toastId });
      } else {
        toast.error(res.message || 'Failed to send request', { id: toastId });
      }
    } catch (err: any) {
      toast.error(err.message || 'Failed to send release request', { id: toastId });
    }
  };


  const dashboardUrl = useMemo(() => {
    return (license as any).dashboardUrl || undefined;
  }, [license]);


  const hasLiveUsage = usageData.length > 0;

  const [search, setSearch] = useState("");
  const [selectedFeatureDetail, setSelectedFeatureDetail] = useState<string | null>(null);

  useEffect(() => {
    setSelectedFeatureDetail(null);
    setSelectedRows(new Set());
    setSearch("");
    setCurrentPage(1);
    setSelectedRegions(new Set());
  }, [id, license.name]);

  const [selectedFeatures, setSelectedFeatures] = useState<Set<string>>(new Set());
  const [isFeatureDropdownOpen, setIsFeatureDropdownOpen] = useState(false);
  const [featureSearch, setFeatureSearch] = useState("");
  const [selectedStatuses, setSelectedStatuses] = useState<Set<number>>(new Set());
  const [isStatusDropdownOpen, setIsStatusDropdownOpen] = useState(false);
  const [selectedRegions, setSelectedRegions] = useState<Set<string>>(new Set());
  const [isRegionDropdownOpen, setIsRegionDropdownOpen] = useState(false);
  const regionDropdownRef = useRef<HTMLDivElement>(null);
  const [selectedRows, setSelectedRows] = useState<Set<string>>(new Set());
  const [visibleColumns, setVisibleColumns] = useState<Set<string>>(new Set(DEFAULT_VISIBLE_COLUMNS));
  const [isViewDropdownOpen, setIsViewDropdownOpen] = useState(false);
  const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false);
  const [cdsid, setCdsid] = useState("");
  const [password, setPassword] = useState("");
  const [authError, setAuthError] = useState("");

  const featureRows = useMemo(() => {
    if (!liveRawData) return [];
    return liveRawData.map((group, idx) => ({
      id: `f-${idx}`,
      feature: group.Feature,
      inUse: group["In Use"] || 0,
      total: group["Total Issued"] || 0,
      region: group.Region
    }));
  }, [liveRawData]);

  const uniqueRegions = useMemo(() => {
    const set = new Set<string>();
    featureRows.forEach(r => { if (r.region) set.add(r.region); });
    usageData.forEach(d => { if (d.region) set.add(d.region); });
    return Array.from(set).filter(Boolean).sort();
  }, [featureRows, usageData]);

  const REGION_COUNTS = useMemo(() => {
    const counts: Record<string, number> = {};
    if (selectedFeatureDetail === null) {
      featureRows.forEach(row => {
        if (row.region) counts[row.region] = (counts[row.region] || 0) + 1;
      });
    } else {
      usageData.forEach(d => {
        if (d.feature === selectedFeatureDetail && d.region) {
          counts[d.region] = (counts[d.region] || 0) + 1;
        }
      });
    }
    return counts;
  }, [selectedFeatureDetail, featureRows, usageData]);

  const featureDropdownRef = useRef<HTMLDivElement>(null);
  const statusDropdownRef = useRef<HTMLDivElement>(null);
  const viewDropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (featureDropdownRef.current && !featureDropdownRef.current.contains(event.target as Node)) {
        setIsFeatureDropdownOpen(false);
      }
      if (statusDropdownRef.current && !statusDropdownRef.current.contains(event.target as Node)) {
        setIsStatusDropdownOpen(false);
      }
      if (viewDropdownRef.current && !viewDropdownRef.current.contains(event.target as Node)) {
        setIsViewDropdownOpen(false);
      }
      if (regionDropdownRef.current && !regionDropdownRef.current.contains(event.target as Node)) {
        setIsRegionDropdownOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const [sortConfig, setSortConfig] = useState<{ key: string, direction: 'asc' | 'desc' | null }>({ key: '', direction: null });

  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const UNIQUE_FEATURES = useMemo(() => {
    return Array.from(new Set(usageData.map(d => d.feature)))
      .filter(Boolean)
      .sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' }));
  }, [usageData]);


  const FEATURE_COUNTS = useMemo(() => {
    const counts: Record<string, number> = {};
    usageData.forEach(d => {
      counts[d.feature] = (counts[d.feature] || 0) + 1;
    });
    return counts;
  }, [usageData]);



  const STATUS_COUNTS = useMemo(() => {
    const counts: Record<number, number> = { 1: 0, 2: 0, 3: 0 };
    if (selectedFeatureDetail === null) {
      featureRows.forEach(row => {
        const scale = getUsageColorScale(row.inUse, row.total);
        if (counts[scale] !== undefined) counts[scale] += 1;
      });
    } else {
      usageData.forEach(d => {
        const stats = featureStats[d.feature] || { inUse: 1, total: 2 };
        const scale = getUsageColorScale(stats.inUse, stats.total);
        if (counts[scale] !== undefined) counts[scale] += 1;
      });
    }
    return counts;
  }, [selectedFeatureDetail, featureRows, usageData, featureStats]);

  const STATUS_OPTIONS = useMemo(() => [
    { value: 3, label: "Critical (≥ 80%)", colorClass: "bg-red-500" },
    { value: 2, label: "Warning (50%-79%)", colorClass: "bg-orange-500" },
    { value: 1, label: "Healthy (< 50%)", colorClass: "bg-green-500" },
  ], []);

  const toggleFeature = (feature: string) => {
    const next = new Set(selectedFeatures);
    if (next.has(feature)) next.delete(feature);
    else next.add(feature);
    setSelectedFeatures(next);
    setCurrentPage(1);
  };

  const toggleColumn = (col: string) => {
    const next = new Set(visibleColumns);
    if (next.has(col)) next.delete(col);
    else next.add(col);
    setVisibleColumns(next);
  };

  const handleSort = (key: string) => {
    let direction: 'asc' | 'desc' | null = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') direction = 'desc';
    else if (sortConfig.key === key && sortConfig.direction === 'desc') direction = null;
    setSortConfig({ key, direction });
  };

  const getSortIcon = (key: string) => {
    if (sortConfig.key !== key || !sortConfig.direction) return <ChevronsUpDown className="w-4 h-4 opacity-50" />;
    if (sortConfig.direction === 'asc') return <ChevronUp className="w-4 h-4 opacity-70" />;
    return <ChevronDown className="w-4 h-4 opacity-70" />;
  };

  const clearFeatureFilter = () => {
    setSelectedFeatures(new Set());
    setCurrentPage(1);
  };

  const toggleStatus = (status: number) => {
    const next = new Set(selectedStatuses);
    if (next.has(status)) next.delete(status);
    else next.add(status);
    setSelectedStatuses(next);
    setCurrentPage(1);
  };

  const clearStatusFilter = () => {
    setSelectedStatuses(new Set());
    setCurrentPage(1);
  };

  const toggleRegion = (reg: string) => {
    const next = new Set(selectedRegions);
    if (next.has(reg)) next.delete(reg);
    else next.add(reg);
    setSelectedRegions(next);
    setCurrentPage(1);
  };

  const clearRegionFilter = () => {
    setSelectedRegions(new Set());
    setCurrentPage(1);
  };

  const toggleRow = (rowId: string) => {
    const next = new Set(selectedRows);
    if (next.has(rowId)) next.delete(rowId);
    else next.add(rowId);
    setSelectedRows(next);
  };

  const toggleAllRows = () => {
    if (selectedRows.size === currentTableData.length && currentTableData.length > 0) {
      setSelectedRows(new Set());
    } else {
      setSelectedRows(new Set(currentTableData.map(d => d.id)));
    }
  };



  const filteredData = useMemo(() => {
    if (selectedFeatureDetail === null) {
      // View 1: List of all Features
      return featureRows.filter(row => {
        if (search) {
          const q = search.toLowerCase();
          if (!row.feature.toLowerCase().includes(q) && !(row.region || '').toLowerCase().includes(q)) return false;
        }
        if (selectedStatuses.size > 0) {
          const statusScale = getUsageColorScale(row.inUse, row.total);
          if (!selectedStatuses.has(statusScale)) return false;
        }
        if (selectedRegions.size > 0 && !selectedRegions.has(row.region)) return false;
        return true;
      });
    } else {
      // View 2: Checkouts for a specific selected Feature
      return usageData.filter(row => {
        if (row.feature !== selectedFeatureDetail) return false;
        if (selectedStatuses.size > 0) {
          const stats = featureStats[row.feature] || { inUse: 1, total: 2 };
          const statusScale = getUsageColorScale(stats.inUse, stats.total);
          if (!selectedStatuses.has(statusScale)) return false;
        }
        if (selectedRegions.size > 0 && !selectedRegions.has(row.region)) return false;
        if (search) {
          const q = search.toLowerCase();
          return (row.user || '').toLowerCase().includes(q) ||
            (row.host || '').toLowerCase().includes(q) ||
            (row.region || '').toLowerCase().includes(q);
        }
        return true;
      });
    }
  }, [search, selectedFeatureDetail, featureRows, usageData, selectedStatuses, selectedRegions, featureStats]);

  const sortedData = useMemo(() => {
    let sortableItems = [...filteredData];
    if (sortConfig.direction !== null && sortConfig.key) {
      sortableItems.sort((a, b) => {
        let aValue: any = a[sortConfig.key];
        let bValue: any = b[sortConfig.key];

        // Map common columns to their row property names
        if (sortConfig.key === 'Feature') { aValue = a.feature; bValue = b.feature; }
        else if (sortConfig.key === 'User') { aValue = a.user; bValue = b.user; }
        else if (sortConfig.key === 'Host Name') { aValue = a.host; bValue = b.host; }
        else if (sortConfig.key === 'Timestamp') { aValue = a.timestamp; bValue = b.timestamp; }
        else if (sortConfig.key === 'Region') { aValue = a.region; bValue = b.region; }

        if (sortConfig.key === 'In use' || sortConfig.key === 'Total Issued') {
          if (selectedFeatureDetail === null) {
            aValue = sortConfig.key === 'In use' ? a.inUse : a.total;
            bValue = sortConfig.key === 'In use' ? b.inUse : b.total;
          } else {
            const statsA = featureStats[a.feature] || { inUse: 1, total: 2 };
            const statsB = featureStats[b.feature] || { inUse: 1, total: 2 };

            if (sortConfig.key === 'In use') {
              aValue = getUsageColorScale(statsA.inUse, statsA.total);
              bValue = getUsageColorScale(statsB.inUse, statsB.total);
              if (aValue === bValue) {
                aValue = statsA.inUse;
                bValue = statsB.inUse;
              }
            } else if (sortConfig.key === 'Total Issued') {
              aValue = statsA.total;
              bValue = statsB.total;
            }
          }
        }

        if (aValue < bValue) return sortConfig.direction === 'asc' ? -1 : 1;
        if (aValue > bValue) return sortConfig.direction === 'asc' ? 1 : -1;
        return 0;
      });
    }
    return sortableItems;
  }, [filteredData, sortConfig, selectedFeatureDetail, featureStats]);

  const totalPages = Math.ceil(sortedData.length / pageSize);
  const currentTableData = sortedData.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  const handleSendNotification = () => {
    if (selectedRows.size === 0) return;
    setIsConfirmModalOpen(true);
    setCdsid("");
    setPassword("");
    setAuthError("");
  };

  const handleCopyCdsids = () => {
    if (selectedRows.size === 0) return;
    const selectedList = usageData.filter(r => selectedRows.has(r.id));
    const cdsids = Array.from(new Set(selectedList.map(r => r.user).filter(Boolean)));
    const cdsidString = cdsids.join('; ');

    navigator.clipboard.writeText(cdsidString).then(() => {
      toast.success(`Copied ${cdsids.length} unique CDSID(s) to clipboard: ${cdsidString}`);
      setSelectedRows(new Set());
    }).catch(() => {
      toast.error('Failed to copy CDSIDs to clipboard.');
    });
  };


  const confirmNotification = async () => {
    if (!cdsid || !password) {
      setAuthError("Please enter your CDSID and password.");
      return;
    }

    const selectedList = usageData.filter(r => selectedRows.has(r.id));
    if (selectedList.length === 0) return;

    const toastId = toast.loading(`Sending release requests to ${selectedList.length} user(s)...`);
    let successCount = 0;

    for (const row of selectedList) {
      try {
        const res = await ApiClient.sendReleaseRequest({
          senderCdsid: cdsid,
          targetUsername: row.user,
          licenseName: license.name,
          feature: row.feature,
          hostname: row.host,
          checkoutTimestamp: row.timestamp,
        });
        if (res.success) successCount++;
      } catch { }
    }

    if (successCount > 0) {
      toast.success(`Release request email sent to ${successCount} user(s).`, { id: toastId });
      setSelectedRows(new Set());
      setIsConfirmModalOpen(false);
      setCdsid("");
      setPassword("");
      setAuthError("");
    } else {
      toast.error(`Failed to send release requests. Please check credentials.`, { id: toastId });
      setAuthError("Authentication or notification failed. Please verify credentials.");
    }
  };


  const cancelNotification = () => {
    setIsConfirmModalOpen(false);
    setCdsid("");
    setPassword("");
    setAuthError("");
  };

  return (
    <div className="min-h-screen pt-24 pb-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <Link to="/licenses" className="inline-flex items-center text-sm font-medium text-gray-500 hover:text-gray-900 dark:text-zinc-400 dark:hover:text-zinc-100 mb-6 transition-colors">
        <ChevronLeft className="w-4 h-4 mr-1" />
        Back to Licenses
      </Link>

      <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 mb-8">
        <div className="flex flex-col gap-2">
          <div className="flex flex-wrap items-center gap-x-4 gap-y-3">
            <div className="flex items-center gap-3">
              <div className="relative flex h-3 w-3">
                {isLoading ? (
                  <Loader2 className="w-4 h-4 animate-spin text-blue-500" />
                ) : (isOnline && hasLiveUsage) ? (
                  <>
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
                  </>
                ) : (
                  <>
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
                  </>
                )}

              </div>
              <h1 className="text-3xl font-bold text-gray-900 dark:text-zinc-50 tracking-tight">
                {license.name || `License #${id}`}
              </h1>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <span className={`px-3 py-1 rounded-full border text-xs font-bold tracking-wide uppercase shadow-sm ${getBadgeStyle(license.type || "FlexLM")}`}>
                {license.type || "FlexLM"}
              </span>
              {(() => {
                const regList = (((license as any).reg && (license as any).reg.length > 0) ? (license as any).reg : uniqueRegions) as string[];
                if (!regList || regList.length === 0) return null;
                const fullText = regList.join(", ");
                const label = regList.length <= 3
                  ? regList.join(", ")
                  : `${regList.slice(0, 3).join(", ")} +${regList.length - 3} MORE`;


                return (
                  <span
                    title={`Regions: ${fullText}`}
                    className="flex items-center gap-1.5 px-3 py-1 rounded-full border bg-gray-50 dark:bg-zinc-800/40 text-gray-700 dark:text-zinc-300 border-gray-200/80 dark:border-zinc-700/80 text-xs font-bold tracking-wide uppercase shadow-sm cursor-help"
                  >
                    <Globe className="w-3.5 h-3.5 text-gray-500 dark:text-zinc-400" />
                    {label}
                  </span>
                );
              })()}
            </div>

          </div>

          {((license as any).osType || (license as any).lingerTime) && (
            <div className="flex flex-wrap items-center gap-2 mt-1 pl-6">
              {(license as any).osType && (
                <span className="flex items-center gap-1.5 px-3 py-1 rounded-full border bg-purple-50 dark:bg-purple-900/20 text-purple-700 dark:text-purple-400 border-purple-200/60 dark:border-purple-800/50 text-xs font-bold tracking-wide uppercase shadow-sm">
                  <OsIcon os={(license as any).osType} />
                  {(license as any).osType}
                </span>
              )}
              {(license as any).lingerTime && (
                <span className="flex items-center gap-1.5 px-3 py-1 rounded-full border bg-amber-50 dark:bg-amber-900/20 text-amber-700 dark:text-amber-400 border-amber-200/60 dark:border-amber-800/50 text-xs font-bold tracking-wide shadow-sm uppercase">
                  <Timer className="w-3.5 h-3.5 text-amber-500 dark:text-amber-400/80" />
                  {(license as any).lingerTime} mins
                </span>
              )}
            </div>
          )}

          <p className="text-gray-500 dark:text-zinc-400 pl-6 text-lg mt-1">
            Live usage monitoring
          </p>
        </div>
        {dashboardUrl && (
          <div className="flex-shrink-0 mt-2 md:mt-0">
            <a href={dashboardUrl} target="_blank" rel="noopener noreferrer" className="inline-flex items-center justify-center h-10 px-5 bg-blue-600 hover:bg-blue-700 text-white rounded-md text-sm font-medium transition-colors shadow-sm">
              View Dashboard
            </a>
          </div>
        )}

      </div>

      <div className="bg-white dark:bg-[#111] border border-gray-200 dark:border-zinc-800 rounded-xl shadow-sm relative">

        {isLoading ? (
          <div className="flex flex-col items-center justify-center py-20 px-4 text-center">
            <Loader2 className="w-8 h-8 animate-spin text-blue-500 mb-4" />
            <p className="text-gray-500 dark:text-zinc-400 text-sm">Loading live data from Redis...</p>
          </div>
        ) : !hasLiveUsage ? (
          <div className="flex flex-col items-center justify-center py-20 px-4 text-center">
            <div className="w-16 h-16 bg-gray-50 dark:bg-zinc-800/50 rounded-full flex items-center justify-center mx-auto mb-6">
              <Search className="w-8 h-8 text-gray-400 dark:text-zinc-500" strokeWidth={1.5} />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 dark:text-zinc-50 mb-2">No live usage found</h3>
            <p className="text-gray-500 dark:text-zinc-400 max-w-sm mb-6">
              There is currently no active usage data reported for {license.name}. Usage might have dropped, or the sync pipeline is catching up.
            </p>
            <Link to="/licenses" className="inline-flex items-center justify-center gap-2 h-10 px-6 bg-gray-100 hover:bg-gray-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-gray-900 dark:text-zinc-100 rounded-lg text-sm font-medium transition-colors w-full sm:w-auto">
              <ChevronLeft className="w-4 h-4" />
              View other licenses
            </Link>
          </div>
        ) : (
          <>
            {selectedFeatureDetail !== null && (() => {
              const stats = featureStats[selectedFeatureDetail] || { inUse: 0, total: 0 };
              return (
                <div className="px-5 py-3.5 border-b border-gray-200 dark:border-zinc-800 bg-gray-50/50 dark:bg-zinc-900/10 flex flex-wrap items-center gap-x-6 gap-y-2">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold text-gray-400 dark:text-zinc-500 uppercase tracking-wider">Feature</span>
                    <span className="text-sm font-semibold text-gray-800 dark:text-zinc-200">{selectedFeatureDetail}</span>
                  </div>
                  <div className="w-px h-4 bg-gray-300 dark:bg-zinc-700 hidden sm:block"></div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold text-gray-400 dark:text-zinc-500 uppercase tracking-wider">In Use</span>
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold border ${getUsageColor(stats.inUse, stats.total)}`}>
                      {stats.inUse}
                    </span>
                  </div>
                  <div className="w-px h-4 bg-gray-300 dark:bg-zinc-700 hidden sm:block"></div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold text-gray-400 dark:text-zinc-500 uppercase tracking-wider">Total Issued</span>
                    <span className="text-sm font-semibold text-gray-800 dark:text-zinc-200">{stats.total}</span>
                  </div>
                </div>
              );
            })()}
            {/* Table Toolbar */}
            <div className="p-4 border-b border-gray-200 dark:border-zinc-800 flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
              <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
                <div className="relative w-full sm:w-64 max-w-sm">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    type="text"
                    placeholder={selectedFeatureDetail === null ? "Search features..." : "Search users, host name..."}
                    value={search}
                    onChange={(e) => { setSearch(e.target.value); setCurrentPage(1); }}
                    className="w-full pl-9 pr-4 py-2 bg-white dark:bg-zinc-900 border border-gray-200 dark:border-zinc-700 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all dark:text-zinc-100"
                  />
                </div>

                {selectedFeatureDetail === null && (
                  <div className="relative" ref={statusDropdownRef}>
                    <button
                      onClick={() => setIsStatusDropdownOpen(!isStatusDropdownOpen)}
                      className="inline-flex h-8 items-center justify-center gap-1.5 whitespace-nowrap rounded-md border border-dashed border-gray-300 dark:border-zinc-700 bg-white dark:bg-[#111] px-2.5 text-sm font-medium text-gray-700 dark:text-zinc-300 transition-colors hover:bg-gray-100 dark:hover:bg-zinc-800 shadow-sm"
                    >
                      <CirclePlus className="w-4 h-4 text-gray-500" />
                      Status
                      {selectedStatuses.size > 0 && (
                        <>
                          <span className="w-px h-4 bg-gray-300 dark:bg-zinc-700 mx-1"></span>
                          <span className="bg-gray-100 dark:bg-zinc-800 text-gray-900 dark:text-zinc-100 text-xs px-1.5 py-0.5 rounded-sm">
                            {selectedStatuses.size}
                          </span>
                        </>
                      )}
                    </button>

                    {isStatusDropdownOpen && (
                      <div className="absolute top-full left-0 mt-1 sm:w-64 w-[calc(100vw-2rem)] z-50 bg-white dark:bg-[#111] border border-gray-200 dark:border-zinc-800 rounded-lg shadow-lg overflow-hidden">
                        <div className="max-h-[250px] overflow-y-auto p-1 scrollbar-thin scrollbar-thumb-gray-300 dark:scrollbar-thumb-zinc-600">
                          {STATUS_OPTIONS.map(opt => {
                            const isSelected = selectedStatuses.has(opt.value);
                            return (
                              <button
                                key={opt.value}
                                onClick={() => toggleStatus(opt.value)}
                                className="w-full flex items-center justify-between px-2 py-1.5 text-sm rounded-md hover:bg-gray-100 dark:hover:bg-zinc-800 text-gray-700 dark:text-zinc-300 transition-colors"
                              >
                                <div className="flex items-center gap-2">
                                  <div className={`w-4 h-4 border rounded flex items-center justify-center transition-colors ${isSelected ? 'bg-blue-600 border-blue-600' : 'border-gray-300 dark:border-zinc-600 bg-white dark:bg-zinc-900'}`}>
                                    {isSelected && <Check className="w-3 h-3 text-white" />}
                                  </div>
                                  <span className="flex items-center gap-2 text-sm font-normal text-gray-700 dark:text-zinc-300">
                                    <span className={`w-2 h-2 rounded-full ${opt.colorClass}`}></span>
                                    {opt.label}
                                  </span>
                                </div>
                                <span className="text-sm text-blue-600 dark:text-blue-400 font-medium">
                                  {STATUS_COUNTS[opt.value] || 0}
                                </span>
                              </button>
                            );
                          })}
                        </div>
                        {selectedStatuses.size > 0 && (
                          <div className="p-2 border-t border-gray-100 dark:border-zinc-800 text-center">
                            <button
                              onClick={clearStatusFilter}
                              className="text-xs text-blue-600 hover:text-blue-700 font-medium"
                            >
                              Clear filters
                            </button>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}

                {selectedFeatureDetail !== null && (
                  <div className="relative" ref={regionDropdownRef}>
                    <button
                      onClick={() => setIsRegionDropdownOpen(!isRegionDropdownOpen)}
                      className="inline-flex h-8 items-center justify-center gap-1.5 whitespace-nowrap rounded-md border border-dashed border-gray-300 dark:border-zinc-700 bg-white dark:bg-[#111] px-2.5 text-sm font-medium text-gray-700 dark:text-zinc-300 transition-colors hover:bg-gray-100 dark:hover:bg-zinc-800 shadow-sm"
                    >
                      <Globe className="w-4 h-4 text-gray-500" />
                      Region
                      {selectedRegions.size > 0 && (
                        <>
                          <span className="w-px h-4 bg-gray-300 dark:bg-zinc-700 mx-1"></span>
                          <span className="bg-gray-100 dark:bg-zinc-800 text-gray-900 dark:text-zinc-100 text-xs px-1.5 py-0.5 rounded-sm">
                            {selectedRegions.size}
                          </span>
                        </>
                      )}
                    </button>

                    {isRegionDropdownOpen && (
                      <div className="absolute top-full left-0 mt-1 sm:w-64 w-[calc(100vw-2rem)] z-50 bg-white dark:bg-[#111] border border-gray-200 dark:border-zinc-800 rounded-lg shadow-lg overflow-hidden">
                        <div className="max-h-[250px] overflow-y-auto p-1 scrollbar-thin scrollbar-thumb-gray-300 dark:scrollbar-thumb-zinc-600">
                          {uniqueRegions.map(reg => {
                            const isSelected = selectedRegions.has(reg);
                            return (
                              <button
                                key={reg}
                                onClick={() => toggleRegion(reg)}
                                className="w-full flex items-center justify-between px-2 py-1.5 text-sm rounded-md hover:bg-gray-100 dark:hover:bg-zinc-800 text-gray-700 dark:text-zinc-300 transition-colors text-left"
                              >
                                <div className="flex items-center gap-2">
                                  <div className={`w-4 h-4 border rounded flex items-center justify-center transition-colors ${isSelected ? 'bg-blue-600 border-blue-600' : 'border-gray-300 dark:border-zinc-600 bg-white dark:bg-zinc-900'}`}>
                                    {isSelected && <Check className="w-3 h-3 text-white" />}
                                  </div>
                                  <span className="text-sm font-normal text-gray-700 dark:text-zinc-300">
                                    {reg}
                                  </span>
                                </div>
                                <span className="text-sm text-blue-600 dark:text-blue-400 font-medium">
                                  {REGION_COUNTS[reg] || 0}
                                </span>
                              </button>
                            );
                          })}
                        </div>
                        {selectedRegions.size > 0 && (
                          <div className="p-2 border-t border-gray-100 dark:border-zinc-800 text-center">
                            <button
                              onClick={clearRegionFilter}
                              className="text-xs text-blue-600 hover:text-blue-700 font-medium"
                            >
                              Clear filters
                            </button>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>

              <div className="flex items-center gap-3 w-full sm:w-auto mt-4 sm:mt-0">
                {selectedFeatureDetail !== null && selectedRows.size > 0 && (
                  ENABLE_NOTIFICATIONS ? (
                    <button
                      onClick={handleSendNotification}
                      className="inline-flex items-center gap-1.5 h-8 px-3 bg-blue-600 hover:bg-blue-700 text-white rounded-md text-sm font-medium transition-colors shadow-sm justify-center"
                    >
                      <Bell className="w-4 h-4" />
                      Notify ({selectedRows.size})
                    </button>
                  ) : (
                    <button
                      onClick={handleCopyCdsids}
                      className="inline-flex items-center gap-1.5 h-8 px-3 bg-blue-600 hover:bg-blue-700 text-white rounded-md text-sm font-medium transition-colors shadow-sm justify-center"
                    >
                      <Clipboard className="w-4 h-4" />
                      Copy CDSIDs ({Array.from(new Set(usageData.filter(r => selectedRows.has(r.id)).map(r => r.user).filter(Boolean))).length})
                    </button>
                  )
                )}

                {selectedFeatureDetail !== null && (
                  <button
                    onClick={() => {
                      setSelectedFeatureDetail(null);
                      setSelectedRows(new Set());
                      setSearch("");
                      setCurrentPage(1);
                    }}
                    className="inline-flex h-8 items-center justify-center gap-1.5 rounded-md border border-gray-200 dark:border-zinc-700 bg-white dark:bg-[#111] px-3 text-sm font-medium text-gray-700 dark:text-zinc-300 hover:bg-gray-100 dark:hover:bg-zinc-800 transition-colors shadow-sm"
                  >
                    <ChevronLeft className="w-4 h-4" />
                    Back to Features
                  </button>
                )}
              </div>
            </div>

            {/* Table wrapper */}
            <div className="overflow-x-auto w-full">
              {selectedFeatureDetail === null ? (
                // View 1: List of all Features (Monitored Features list)
                <table className="w-full text-left border-collapse text-sm whitespace-nowrap">
                  <thead>
                    <tr className="border-b border-gray-200 dark:border-zinc-800 hover:bg-muted/50 dark:hover:bg-zinc-800/10 transition-colors bg-gray-50/50 dark:bg-zinc-900/20">
                      <th className="px-6 py-3 text-gray-900 dark:text-zinc-100 font-semibold whitespace-nowrap">
                        <button onClick={() => handleSort('Feature')} className="flex items-center gap-2 hover:bg-gray-100 dark:hover:bg-zinc-800 px-2 py-1 -ml-2 rounded-md transition-colors">
                          Feature
                          {getSortIcon('Feature')}
                        </button>
                      </th>
                      <th className="px-6 py-3 text-gray-900 dark:text-zinc-100 font-semibold whitespace-nowrap">
                        <button onClick={() => handleSort('In use')} className="flex items-center gap-2 hover:bg-gray-100 dark:hover:bg-zinc-800 px-2 py-1 -ml-2 rounded-md transition-colors">
                          In use
                          {getSortIcon('In use')}
                        </button>
                      </th>
                      <th className="px-6 py-3 text-gray-900 dark:text-zinc-100 font-semibold whitespace-nowrap">
                        <button onClick={() => handleSort('Total Issued')} className="flex items-center gap-2 hover:bg-gray-100 dark:hover:bg-zinc-800 px-2 py-1 -ml-2 rounded-md transition-colors">
                          Total Issued
                          {getSortIcon('Total Issued')}
                        </button>
                      </th>
                      <th className="px-6 py-3 text-gray-900 dark:text-zinc-100 font-semibold whitespace-nowrap">
                        Status
                      </th>
                      <th className="px-6 py-3 text-gray-900 dark:text-zinc-100 font-semibold whitespace-nowrap">
                        Action
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 dark:divide-zinc-800/80">
                    {currentTableData.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="px-6 py-12 text-center text-gray-500 dark:text-zinc-400">
                          No features found.
                        </td>
                      </tr>
                    ) : currentTableData.map(row => {
                      const percent = row.inUse / row.total;
                      let statusText = "Healthy";
                      let badgeColor = "bg-green-100 text-green-700 border-green-200 dark:bg-green-900/30 dark:text-green-400 dark:border-green-800";
                      if (percent >= 0.8) {
                        statusText = "Critical";
                        badgeColor = "bg-red-100 text-red-700 border-red-200 dark:bg-red-900/30 dark:text-red-400 dark:border-red-800";
                      } else if (percent >= 0.5) {
                        statusText = "Warning";
                        badgeColor = "bg-orange-100 text-orange-700 border-orange-200 dark:bg-orange-900/30 dark:text-orange-400 dark:border-orange-800";
                      }

                      return (
                        <tr
                          key={row.feature}
                          className="transition-colors hover:bg-gray-50/50 dark:hover:bg-zinc-800/30"
                        >
                          <td className="px-6 py-3.5 align-middle text-sm font-semibold text-gray-800 dark:text-zinc-200">
                            {row.feature}
                          </td>
                          <td className="px-6 py-3.5 align-middle">
                            <span
                              title={`Usage is ${((row.inUse / row.total) * 100).toFixed(0)}% (Critical ≥ 80%, Warning 50-79%, Healthy < 50%)`}
                              className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold border ${getUsageColor(row.inUse, row.total)} cursor-help`}
                            >
                              {row.inUse}
                            </span>
                          </td>
                          <td className="px-6 py-3.5 align-middle text-sm font-medium text-gray-800 dark:text-zinc-200">
                            {row.total}
                          </td>
                          <td className="px-6 py-3.5 align-middle">
                            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold border ${badgeColor}`}>
                              {statusText}
                            </span>
                          </td>
                          <td className="px-6 py-3.5 align-middle">
                            {row.inUse > 0 && (
                              <button
                                onClick={() => {
                                  setSelectedFeatureDetail(row.feature);
                                  setSelectedRows(new Set());
                                  setSearch("");
                                  setCurrentPage(1);
                                }}
                                className="inline-flex items-center gap-1.5 h-7 px-3 bg-blue-50 hover:bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:hover:bg-blue-900/50 dark:text-blue-400 rounded text-xs font-semibold transition-colors"
                              >
                                <Eye className="w-3.5 h-3.5" />
                                View
                              </button>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              ) : (
                // View 2: Checkouts for a specific selected Feature (NO Action column)
                <table className="w-full text-left border-collapse text-sm whitespace-nowrap">
                  <thead>
                    <tr className="border-b border-gray-200 dark:border-zinc-800 hover:bg-muted/50 dark:hover:bg-zinc-800/10 transition-colors bg-gray-50/50 dark:bg-zinc-900/20">
                      <th className="px-3 py-3 w-12 text-gray-900 dark:text-zinc-100 font-medium">
                        <div className="flex items-center">
                          <button
                            onClick={toggleAllRows}
                            className={`w-4 h-4 border rounded flex items-center justify-center transition-colors ${selectedRows.size > 0 && selectedRows.size === currentTableData.length ? 'bg-blue-600 border-blue-600' : 'border-gray-300 dark:border-zinc-600 bg-white dark:bg-zinc-900'}`}
                          >
                            {selectedRows.size > 0 && <Check className="w-3 h-3 text-white" opacity={selectedRows.size === currentTableData.length ? 1 : 0.5} />}
                          </button>
                        </div>
                      </th>
                      {['User', 'Host Name', 'Region', 'Timestamp'].filter(col => visibleColumns.has(col)).map(col => (
                        <th key={col} className="px-3 py-3 text-gray-900 dark:text-zinc-100 font-semibold whitespace-nowrap">
                          {col === 'Timestamp' ? (
                            <span className="flex h-8 items-center px-2 -ml-2">{col}</span>
                          ) : (
                            <button onClick={() => handleSort(col)} className="flex items-center gap-2 hover:bg-gray-100 dark:hover:bg-zinc-800 px-2 py-1 -ml-2 rounded-md transition-colors">
                              {col}
                              {getSortIcon(col)}
                            </button>
                          )}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 dark:divide-zinc-800/80">
                    {currentTableData.length === 0 ? (
                      <tr>
                        <td colSpan={['User', 'Host Name', 'Region', 'Timestamp'].filter(col => visibleColumns.has(col)).length + 1} className="px-4 py-12 text-center text-gray-500 dark:text-zinc-400">
                          No active usage records found.
                        </td>
                      </tr>
                    ) : currentTableData.map(row => {
                      const isSelected = selectedRows.has(row.id);

                      return (
                        <tr
                          key={row.id}
                          className={`transition-colors hover:bg-gray-50/50 dark:hover:bg-zinc-800/30 ${isSelected ? 'bg-blue-50/40 dark:bg-blue-900/10' : ''}`}
                          onClick={() => toggleRow(row.id)}
                        >
                          <td className="px-3 py-2 align-middle" onClick={(e) => e.stopPropagation()}>
                            <div className="flex items-center ml-[4px]">
                              <button
                                onClick={() => toggleRow(row.id)}
                                className={`w-4 h-4 border rounded flex items-center justify-center transition-colors ${isSelected ? 'bg-blue-600 border-blue-600' : 'border-gray-300 dark:border-zinc-600 bg-white dark:bg-zinc-900'}`}
                              >
                                {isSelected && <Check className="w-3 h-3 text-white" />}
                              </button>
                            </div>
                          </td>
                          {['User', 'Host Name', 'Region', 'Timestamp'].filter(col => visibleColumns.has(col)).map(col => {
                            if (col === 'User') {
                              return (
                                <td key={col} className="px-3 py-2 align-middle text-sm font-semibold text-gray-800 dark:text-zinc-200">
                                  {row.user}
                                </td>
                              );
                            } else if (col === 'Host Name') {
                              return (
                                <td key={col} className="px-3 py-2 align-middle text-sm font-medium text-gray-800 dark:text-zinc-200">
                                  {row.host}
                                </td>
                              );
                            } else if (col === 'Timestamp') {
                              return (
                                <td key={col} className="px-3 py-2 align-middle text-sm font-medium text-gray-850 dark:text-zinc-350">
                                  {row.timestamp}
                                </td>
                              );
                            } else if (col === 'Region') {
                              return (
                                <td key={col} className="px-3 py-2 align-middle text-sm font-medium text-gray-800 dark:text-zinc-200">
                                  {row.region}
                                </td>
                              );
                            } else {
                              return (
                                <td key={col} className="px-3 py-2 align-middle text-sm font-medium text-gray-800 dark:text-zinc-200">
                                  {row[col] !== undefined ? row[col] : '-'}
                                </td>
                              );
                            }
                          })}
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              )}
            </div>

            {/* Pagination */}
            <div className="flex flex-col gap-4 px-4 py-4 sm:flex-row sm:items-center sm:justify-between border-t border-gray-200 dark:border-zinc-800">
              <div className="flex-1 text-center text-sm text-gray-500 dark:text-zinc-400 sm:text-left">
                <span className="font-medium">Showing {Math.min((currentPage - 1) * pageSize + 1, sortedData.length)} to {Math.min(currentPage * pageSize, sortedData.length)} of {sortedData.length} records</span>
              </div>

              <div className="flex flex-col items-center gap-4 sm:flex-row sm:gap-6 lg:gap-8">
                <div className="flex items-center gap-2">
                  <p className="text-sm font-medium whitespace-nowrap text-gray-800 dark:text-zinc-300">Rows per page</p>
                  <div className="relative">
                    <select
                      value={pageSize}
                      onChange={(e) => { setPageSize(Number(e.target.value)); setCurrentPage(1); }}
                      className="appearance-none h-8 w-[70px] rounded-md border border-gray-200 dark:border-zinc-700 bg-transparent dark:bg-zinc-900 pl-3 pr-8 text-sm shadow-sm transition-colors focus:ring-2 focus:ring-blue-500 outline-none text-gray-900 dark:text-zinc-100"
                    >
                      <option value={10}>10</option>
                      <option value={20}>20</option>
                      <option value={50}>50</option>
                    </select>
                    <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-2">
                      <ChevronDown className="h-4 w-4 text-gray-500" />
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div className="text-sm font-medium whitespace-nowrap text-gray-800 dark:text-zinc-300">Page {currentPage} of {Math.max(1, totalPages)}</div>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => setCurrentPage(1)}
                      disabled={currentPage === 1}
                      className="rounded-md border border-gray-200 dark:border-zinc-700 bg-white dark:bg-[#111] text-gray-700 dark:text-zinc-300 hover:bg-gray-100 dark:hover:bg-zinc-800 disabled:opacity-50 disabled:cursor-not-allowed hidden h-8 w-8 lg:flex items-center justify-center transition-colors"
                    >
                      <ChevronsLeft className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                      disabled={currentPage === 1}
                      className="rounded-md border border-gray-200 dark:border-zinc-700 bg-white dark:bg-[#111] text-gray-700 dark:text-zinc-300 hover:bg-gray-100 dark:hover:bg-zinc-800 disabled:opacity-50 disabled:cursor-not-allowed flex h-8 w-8 items-center justify-center transition-colors"
                    >
                      <ChevronLeft className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                      disabled={currentPage === totalPages || totalPages === 0}
                      className="rounded-md border border-gray-200 dark:border-zinc-700 bg-white dark:bg-[#111] text-gray-700 dark:text-zinc-300 hover:bg-gray-100 dark:hover:bg-zinc-800 disabled:opacity-50 disabled:cursor-not-allowed flex h-8 w-8 items-center justify-center transition-colors"
                    >
                      <ChevronRight className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => setCurrentPage(totalPages)}
                      disabled={currentPage === totalPages || totalPages === 0}
                      className="rounded-md border border-gray-200 dark:border-zinc-700 bg-white dark:bg-[#111] text-gray-700 dark:text-zinc-300 hover:bg-gray-100 dark:hover:bg-zinc-800 disabled:opacity-50 disabled:cursor-not-allowed hidden h-8 w-8 lg:flex items-center justify-center transition-colors"
                    >
                      <ChevronsRight className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </>
        )}

        {/* Confirmation Modal */}
        {isConfirmModalOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/50 backdrop-blur-sm px-4">
            <div className="bg-white dark:bg-[#111] border border-gray-200 dark:border-zinc-800 rounded-xl shadow-xl w-full max-w-sm overflow-hidden animate-in fade-in zoom-in-95 duration-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-zinc-50 mb-2">Notify Users</h3>
              <p className="text-sm text-gray-600 dark:text-zinc-400 mb-4">
                Are you sure you want to notify them to release License <span className="font-semibold text-gray-900 dark:text-zinc-200">{license.name || 'CST'}</span> they are not using?
              </p>

              <div className="space-y-3 mb-6">
                <div>
                  <label className="block text-xs font-medium text-gray-700 dark:text-zinc-300 mb-1">CDSID</label>
                  <input
                    type="text"
                    value={cdsid}
                    onChange={(e) => setCdsid(e.target.value)}
                    className="w-full px-3 py-2 text-sm bg-gray-50 dark:bg-zinc-800/50 border border-gray-200 dark:border-zinc-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/50 dark:text-zinc-100"
                    placeholder="Enter your CDSID"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-700 dark:text-zinc-300 mb-1">Password</label>
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full px-3 py-2 text-sm bg-gray-50 dark:bg-zinc-800/50 border border-gray-200 dark:border-zinc-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/50 dark:text-zinc-100"
                    placeholder="Enter your password"
                  />
                </div>
                {authError && (
                  <p className="text-red-500 dark:text-red-400 text-xs mt-1 font-medium">{authError}</p>
                )}
              </div>

              <div className="flex items-center gap-3 w-full">
                <button
                  onClick={cancelNotification}
                  className="flex-1 px-4 py-2 bg-gray-100 hover:bg-gray-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-gray-900 dark:text-zinc-100 rounded-lg text-sm font-medium transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={confirmNotification}
                  className="flex-1 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-medium transition-colors shadow-sm"
                >
                  Confirm
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
