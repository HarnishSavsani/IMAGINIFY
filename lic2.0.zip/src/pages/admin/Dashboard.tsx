import { Activity, Users, Server, AppWindow, ChevronLeft, ChevronRight } from "lucide-react";
import { useState, useEffect, useMemo } from "react";
import { ApiClient } from "../../lib/api";

export default function Dashboard() {
  const [activeSessions, setActiveSessions] = useState(1842);
  const [calendarDate, setCalendarDate] = useState(() => new Date());
  const [activeLicensesCount, setActiveLicensesCount] = useState(0);
  const [activeServersCount, setActiveServersCount] = useState(0);
  const [activeAppsCount, setActiveAppsCount] = useState(0);

  useEffect(() => {
    // Fetch licenses
    ApiClient.getLicenses()
      .then(licenses => {
        const activeLics = licenses.filter((lic: any) => lic.status !== 'Inactive');
        setActiveLicensesCount(activeLics.length);
        const serverSum = activeLics.reduce((sum: number, lic: any) => sum + (lic.sv || 0), 0);
        setActiveServersCount(serverSum);
      })
      .catch(() => {});

    // Fetch applications
    ApiClient.getApps()
      .then(apps => {
        const activeApps = apps.filter((app: any) => app.status === 'Active');
        setActiveAppsCount(activeApps.length);
      })
      .catch(() => {});

    const interval = setInterval(() => {
      setActiveSessions(prev => Math.max(1800, Math.min(2000, prev + Math.floor(Math.random() * 11) - 5)));
    }, 2500);
    return () => clearInterval(interval);
  }, []);

  const stats = [
    { name: 'Total Monitored Licenses', value: activeLicensesCount.toString(), icon: Activity },
    { name: 'Active Sessions', value: activeSessions.toLocaleString(), icon: Users },
    { name: 'Server Nodes Status', value: activeServersCount.toString(), icon: Server },
    { name: 'Applications Added', value: activeAppsCount.toString(), icon: AppWindow },
  ];

  const licenseTypes = [
    { id: 'FlexLM', name: 'FlexLM', color: 'bg-blue-600' },
    { id: 'NonFlexLM', name: 'Non FlexLM', color: 'bg-blue-300' },
  ];

  const chartData = useMemo(() => {
    return Array.from({ length: 48 }).map((_, i) => {
      const timeStr = `${Math.floor(i / 2).toString().padStart(2, '0')}:${i % 2 === 0 ? '00' : '30'}`;
      const time = i % 8 === 0 ? `${Math.floor(i / 2).toString().padStart(2, '0')}:00` : ''; 
      const baseVol = 30 + Math.sin(i / 6) * 20 + Math.cos(i / 3) * 10 + Math.random() * 5;
      const flexLm = baseVol * 2.5;
      const nonFlexLm = baseVol * 1.5;
      
      return {
        time,
        timeStr,
        flexLm,
        nonFlexLm,
        total: flexLm + nonFlexLm
      };
    });
  }, []);

  const totalBlocks = 15;
  const maxVal = Math.max(...chartData.map(d => d.total));

  // Calendar logic
  const handlePrevMonth = () => {
    setCalendarDate(new Date(calendarDate.getFullYear(), calendarDate.getMonth() - 1, 1));
  };
  const handleNextMonth = () => {
    setCalendarDate(new Date(calendarDate.getFullYear(), calendarDate.getMonth() + 1, 1));
  };

  const currentMonth = calendarDate.toLocaleString('default', { month: 'long' });
  const currentYear = calendarDate.getFullYear();
  const daysInMonth = new Date(currentYear, calendarDate.getMonth() + 1, 0).getDate();
  const firstDay = new Date(currentYear, calendarDate.getMonth(), 1).getDay();

  const { highDays, medDays } = useMemo(() => {
    const hd = [];
    const md = [];
    // Randomize on month change
    for (let i = 1; i <= daysInMonth; i++) {
      const rand = Math.random();
      if (rand > 0.85) hd.push(i);
      else if (rand > 0.6) md.push(i);
    }
    return { highDays: hd, medDays: md };
  }, [calendarDate.getMonth(), currentYear, daysInMonth]);

  const realToday = new Date();
  const isDisplayingCurrentMonth = realToday.getMonth() === calendarDate.getMonth() && realToday.getFullYear() === calendarDate.getFullYear();

  return (
    <div className="space-y-6 max-w-[1400px] mx-auto">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.name} className="bg-white dark:bg-zinc-900 p-5 rounded-xl border border-gray-200 dark:border-zinc-800 shadow-sm flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500 dark:text-zinc-400">{stat.name}</p>
                <h3 className="text-2xl font-bold text-gray-900 dark:text-zinc-100 mt-1">{stat.value}</h3>
              </div>
              <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-xl">
                <Icon className="w-6 h-6 text-blue-600 dark:text-blue-400" />
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Chart Area */}
        <div className="lg:col-span-2 bg-white dark:bg-zinc-900 p-6 rounded-xl border border-gray-200 dark:border-zinc-800 shadow-sm flex flex-col">
          <div className="flex justify-between items-center mb-8">
            <div>
              <h3 className="text-xs font-bold tracking-wider text-gray-500 dark:text-zinc-400 uppercase mb-1">Global Utilization</h3>
              <div className="flex items-baseline gap-2">
                <h2 className="text-4xl font-bold text-gray-900 dark:text-zinc-100">8,241</h2>
                <span className="text-sm text-gray-500 dark:text-zinc-400">total checkouts today</span>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-4 text-sm max-w-sm justify-end">
              {licenseTypes.map(lt => (
                <div key={lt.id} className="flex items-center gap-1.5">
                  <div className={`w-3 h-3 rounded-[2px] ${lt.color}`}></div>
                  <span className="font-semibold text-gray-900 dark:text-zinc-100">{lt.name}</span>
                </div>
              ))}
            </div>
          </div>
          
          <div className="flex-1 flex flex-col justify-end pt-4 min-h-[300px]">
            <div className="flex items-end justify-between gap-[2px] sm:gap-1 w-full h-[250px] mb-4">
              {chartData.map((d, i) => {
                const flexBlocks = Math.round((d.flexLm / maxVal) * totalBlocks);
                const nonFlexBlocks = Math.round((d.nonFlexLm / maxVal) * totalBlocks);
                return (
                  <div key={i} className="flex-1 flex flex-col-reverse gap-[2px] sm:gap-1 justify-start h-full group relative">
                    {Array.from({ length: totalBlocks }).map((_, j) => {
                       let bgColor = "bg-gray-100 dark:bg-zinc-800";
                       if (j < flexBlocks) bgColor = "bg-blue-600";
                       else if (j < flexBlocks + nonFlexBlocks) bgColor = "bg-blue-300";
                       return <div key={j} className={`w-full h-[12px] sm:h-[14px] md:h-[16px] lg:h-[18px] rounded-[2px] ${bgColor} transition-colors group-hover:brightness-110`}></div>
                    })}
                  </div>
                )
              })}
            </div>
            <div className="flex justify-between text-xs font-semibold text-gray-500 dark:text-zinc-400 px-1 mt-2">
              {chartData.filter(d => d.time).map(d => (
                <span key={d.timeStr}>{d.time}</span>
              ))}
            </div>
          </div>
        </div>

        {/* Calendar Area */}
        <div className="bg-white dark:bg-zinc-900 p-6 rounded-xl border border-gray-200 dark:border-zinc-800 shadow-sm flex flex-col">
          <div className="flex justify-between items-center mb-6">
            <button onClick={handlePrevMonth} className="p-1.5 border border-gray-200 dark:border-zinc-700 rounded-md hover:bg-gray-50 dark:hover:bg-zinc-800 text-gray-600 dark:text-zinc-300 transition-colors">
              <ChevronLeft className="w-4 h-4" />
            </button>
            <h3 className="font-semibold text-gray-900 dark:text-zinc-100">
              {currentMonth} {currentYear}
            </h3>
            <button onClick={handleNextMonth} className="p-1.5 border border-gray-200 dark:border-zinc-700 rounded-md hover:bg-gray-50 dark:hover:bg-zinc-800 text-gray-600 dark:text-zinc-300 transition-colors">
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-7 gap-y-4 gap-x-2 text-center text-sm mb-4">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
              <div key={day} className="text-xs font-medium text-gray-500 dark:text-zinc-400">{day}</div>
            ))}
            
            {Array.from({ length: firstDay }).map((_, i) => (
              <div key={`empty-${i}`}></div>
            ))}
            
            {Array.from({ length: daysInMonth }).map((_, i) => {
              const date = i + 1;
              const isToday = isDisplayingCurrentMonth && date === realToday.getDate();
              
              const isHigh = highDays.includes(date);
              const isMed = !isHigh && medDays.includes(date);
              
              let style = "bg-gray-50 dark:bg-zinc-800/50 text-gray-900 dark:text-zinc-300"; // default available (low)
              if (isHigh) style = "bg-gray-900 dark:bg-white text-white dark:text-zinc-900 font-medium"; 
              else if (isMed) style = "bg-blue-100/50 dark:bg-blue-900/30 text-blue-900 dark:text-blue-100";
              else if (isToday) style = "border-2 border-blue-500 bg-gray-50 dark:bg-zinc-800/50 font-bold text-blue-600 dark:text-blue-400";
              
              return (
                <div key={date} className={`h-10 w-10 mx-auto flex items-center justify-center rounded-xl cursor-default transition-transform hover:scale-105 ${style}`}>
                  {date}
                </div>
              );
            })}
          </div>
          
          <div className="mt-auto pt-6 border-t border-gray-100 dark:border-zinc-800 flex justify-between items-center text-xs text-gray-500 dark:text-zinc-400">
            <div className="flex gap-4">
              <div className="flex items-center gap-1.5"><div className="w-2.5 h-2.5 rounded-full border border-gray-300 dark:border-zinc-600"></div> Low</div>
              <div className="flex items-center gap-1.5"><div className="w-2.5 h-2.5 rounded-full bg-blue-100 dark:bg-blue-900"></div> Med</div>
              <div className="flex items-center gap-1.5"><div className="w-2.5 h-2.5 rounded-full bg-gray-900 dark:bg-white"></div> High</div>
            </div>
            <span>{currentMonth}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
