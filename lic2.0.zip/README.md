# 🚀 Enterprise License Monitoring System (ELMS)

> **The Ultimate Architecture, Engineering, & Operations Grimoire** 🧙‍♂️📘

Welcome to the definitive engineering master-document for the Enterprise License Monitoring System (ELMS). This highly resilient, cross-platform, asynchronous Python and PowerShell architecture is precision-engineered to continuously fetch, parse, normalize, and route software license usage data across a complex global network.

---

## 🌟 1. The Grand Vision: Why This Architecture Exists

Modern engineering organizations rely on fiercely expensive, concurrently pooled software licenses (MATLAB, Catia, Tasking, Klocwork, etc.). Tracking who is using what—and whether you are running out of seats—requires querying chaotic, legacy vendor servers.

To achieve real-time visibility without crushing your databases, this architecture acts as a **Global Aggregator**. It performs a worldwide network sweep every **60 seconds** ⏱️ and executes the **"Data Splitter Pattern"**, dividing the chaotic vendor data into two pristine streams:

1. 🔴 **The Live UI Cache (Redis):** A fast, transient, in-memory cache holding _exact, high-fidelity_ user details (Who is using the license? What machine are they on? Since exactly what second?). This powers the React frontend.
2. 🟢 **The Historical Vault (Graylog):** Lightweight, mathematically aggregated `.jsonl` files written to disk. By stripping out individual user names before saving, your long-term storage remains lightning-fast and cheap, tracking only the macro metrics (Total Issued vs. Total In-Use).

---

## 🗺️ 2. System Connections & Network Flow

The system operates across mixed OS environments, utilizing both **Pull** (Linux querying outwards) and **Push** (Windows sending inwards) methodologies.

```mermaid
graph TD
    subgraph "Vendor License Servers (The Edge) 🏢"
        F[FlexLM Servers\nlmutil / Port 27000+]
        R[Reprise Servers\nrlmutil / Port 5053]
        D[Dassault Servers\nCatia / Port 4084]
        T[Tasking Web Dashboards\nHTTP / Port 9090]
    end

    subgraph "Windows Node (glcpp480) 🪟"
        KW_Agent[PowerShell Task Scheduler\nklockwork_usage_parser.ps1]
        KW_Local[Local Klocwork RLM]
        KW_Agent -.->|1. Reads Local Data| KW_Local
    end

    subgraph "Linux Worker Node (chiprx022) 🐧"
        M((main.py\nAsync Event Loop))
        API[FastAPI Receiver\nkw_api.py / Port 8000]

        %% Pull Connections
        F -->|Subprocess| M
        R -->|Subprocess| M
        D -->|Interactive Shell| M
        T -->|HTTP GET Request| M

        %% Internal Processing
        M --> P{license_parser.py\nRegex Engine & BS4}
        P --> G[The Splitter\nexecutor.py]
    end

    subgraph "The Dual Pipeline 🛤️"
        G -->|1. Pop Users| REDIS[(Redis In-Memory\nPort 6379\nTTL: 120s)]
        G -->|2. Summary Numbers| Q[Async Queues\nqueue_logger.py]
        API -->|Direct Push| REDIS
    end

    subgraph "Data Destinations 🎯"
        REDIS <--> UI[React Live Dashboard ⚛️\nNode.js Backend]
        Q -->|JSONL Files| GL[Graylog Database 📊]
    end

    %% Push Connection
    KW_Agent ==>|2. HTTP POST JSON\nOver VPN| API
```


### 🔌 Network Connection Details:

- **Linux Worker (`chiprx022`):** The brain of the operation. It proactively dials out via SSH/CLI and HTTP to all global servers configured in the `license-monitor-config.yaml`.
- **Windows Agent (`glcpp480`):** Because the Klocwork server blocks inbound SSH requests, it uses an inverted architecture. A PowerShell script wakes up every 60 seconds, queries the local `.exe`, and **pushes** the JSON payload over the network to the FastAPI receiver listening on `chiprx022:8000`.
- **Redis Localhost:** Both the async Python worker and the FastAPI receiver dump their normalized JSON payloads directly into the Redis instance running on port `6379` on the Linux box.

---

## ⚙️ 3. The Core Brain (`main.py` & `executor.py`)

The orchestration layer is built on Python's `asyncio` to handle dozens of global servers simultaneously without locking up the CPU or hanging on dead connections.

- 🚦 **Concurrency Control (`asyncio.Semaphore`):** The system caps parallel queries at **50** (configurable in YAML). This ensures the Linux host isn't choked by spawning 200 concurrent subprocesses.
- 🛡️ **Active Task Tracking:** A global `active_tasks = set()` tracks exactly which queries are running. If the `SALT` server in India hangs for 5 minutes, the next 60-second loop will silently skip it, preventing a cascading memory leak of frozen queries.
- 🔁 **Triad Failover Logic:** For mission-critical FlexLM triads (3 redundant servers sharing one pool), `run_triad_group()` queries them sequentially. The absolute microsecond _one_ server responds successfully with data, the loop `break`s and skips the backup servers, slashing unnecessary network bandwidth.
- 🌐 **Distributed Mode:** For tools like `rlmutil` (Kanzi), the system queries _all_ listed servers simultaneously and processes every single one, as they hold distinct, non-redundant license pools.

---

## 🛠️ 4. The 5-Pillar Extraction Engine

Vendor tools output wildly different formats. `license_parser.py` and `http_scraper.py` employ aggressive, minute-detail normalization.

### 🅰️ FlexLM (`lmutil` / `lmutilnew`)

- **The Command:** `lmutil lmstat -c <port>@<host> -a`
- **The Regex Engine:** Splits the massive output by the phrase `Users of...`. It uses specific regex profiles (`IBM`, `SALT`, `DEFAULT_LMUTIL`) to handle vendor-specific whitespace and date anomalies.
- **The "Uncounted" Anomaly:** Some vendors mark specific licenses as "Uncounted", causing the tool to output `Total Issued: 0` despite people using it. The parser intercepts the word "Uncounted", hardcodes Total Issued to `9999999`, and mathematically sums the active checkout lines to derive the true "In Use" number.

### 🅱️ Reprise License Manager (`rlmutil`)

- **The Command:** `rlmutil rlmstat -c <port>@<host> -a`
- **The Topology:** RLM prints aggregate totals at the top of the file and user lists at the bottom. The parser builds a dictionary and maps them together.
- **The Deduplication Matrix:** RLM notorious for listing a single user 5 times if they consume 5 token handles. The parser explicitly combines `<Username>@<Hostname>` into a unique key. It deduplicates the array and mathematically sums their `licenses_used` into a single, clean UI object.

### 🇨️ Tasking (HTTP Web Scraper)

- **The Command:** Issues asynchronous `requests.get()` via `asyncio.to_thread()` to avoid blocking the main loop.
- **HTML Parsing (BS4):** Scans the DOM for `<table>` tags, dynamically finding the "License Seats In Use" table by sniffing the `<th>` headers.
- **Edge Case 1 - Ghost Tables:** If nobody is using Tasking, the vendor's web server deletes the table entirely. The parser catches `if not tables:` and gracefully returns an empty array `[]` so the React UI can safely show "0 Users".
- **Edge Case 2 - The "Blank Row" Inheritance:** If User A and User B share a license key, the HTML table leaves the License Key cell _blank_ for User B (e.g., the `vision` user on host `MXDJ66W4K3`). The parser variable `current_license_key` tracks the _last seen_ key and injects it into blank rows to ensure flawless attribution.

### 🇩️ Dassault Systemes / Catia (`DSLicSrv`)

- **The Command:** This requires a highly complex Interactive Shell session (`subprocess.PIPE`). It injects `connect <host> <port>`, waits 1 second, injects the password `Vist@123`, and crucially issues `getLicenseUsage -all` (the `-all` flag forces the server to reveal the usernames).
- **Feature Aggregation:** Catia splits the same feature (e.g., `HD2`) into multiple text blocks if they belong to different pricing tiers (ALC vs YLC). The parser establishes a running tally (`feature_totals[name]["total_issued"] += total`), flawlessly adding `Count: 2` and `Count: 100` into a master `Total Issued: 102`.
- **Time Travel Protocol:** Catia outputs timestamps as `6/23/26, 8:55:45 PM`. The `parse_catia_timestamp()` function explicitly translates this via `%I:%M:%S %p` into the universal 24-hour React standard: `23-06-2026 20:55:45`.

### 🇪️ Klocwork (The Windows Push Pipeline)

- **The Agent:** A PowerShell script runs via Windows Task Scheduler.
- **The Stealth Bypass:** It launches via `-ExecutionPolicy Bypass -WindowStyle Hidden -NoProfile` to ensure it runs completely invisibly in the background, surviving server reboots without a user needing to log in.
- **The Checkbox of Death:** Task Scheduler's default "Stop task if it runs longer than 3 days" is explicitly disabled so the infinite `while ($true)` loop can run eternally. Multiple instances are blocked via the "Do not start a new instance" setting.

---

## 🗃️ 5. Data Schemas (The "Splitter" Pattern)

This is the architectural crown jewel. To keep Graylog fast and affordable, we **NEVER** send individual user data to the logs.

### ✂️ The Surgical Split

Inside `executor.py` and `http_scraper.py`, you will find this exact line of code:

```python
users_list = feat.pop("active_users", [])

```

By using `.pop()`, the massive array of users is permanently ripped out of the dictionary in RAM. The remaining "hollow" summary dictionary routes to Graylog, while the extracted `users_list` routes to Redis.

### 📊 Destination 1: Historical Logs (Graylog / Disk)

Written dynamically to `logs/<tool>/<tool>-YYYY-MM-DD.jsonl`.

```json
{
  "ts": "2026-06-24T10:45:00Z",
  "group": "MATLAB - India",
  "tool": "lmutil",
  "hostname": "glcpd422.vistcorp.ad.visteon.com",
  "region": "India",
  "port": 27001,
  "feature": "MATLAB",
  "total_issued": 50,
  "in_use": 2,
  "status": "ok"
}
```

### ⚛️ Destination 2: Real-Time Cache (Redis / React UI)

The backend formats the keys into pristine **Title Case** so the React frontend developer can map them directly into UI table column headers without writing messy UI conversion logic.
**Redis Key Structure:** `license:live:<Name>:<Feature>`
_(Automatically self-destructs via `setex` TTL of 120 seconds)._

#### 1. LMUTIL Structural Blueprint

**Redis Key:** `license:live:MATLAB - India:MATLAB`

```json
{
  "Name": "MATLAB - India",
  "Feature": "MATLAB",
  "Total Issued": 50,
  "In Use": 2,
  "Last Updated": "2026-06-24T10:45:00Z",
  "users": [
    {
      "Username": "jdoe",
      "Hostname": "INDC12345",
      "Timestamp": "24-06-2026 09:15:00"
    }
  ]
}
```

#### 2. RLMUTIL Structural Blueprint

**Redis Key:** `license:live:Kanzi:kanzi_studio`

```json
{
  "Name": "Kanzi",
  "Feature": "kanzi_studio",
  "Total Issued": 10,
  "In Use": 1,
  "Last Updated": "2026-06-24T10:45:00Z",
  "users": [
    {
      "Username": "mchen",
      "Hostname": "MXDJ55555",
      "Timestamp": "24-06-2026 08:30:00"
    }
  ]
}
```

#### 3. TASKING Structural Blueprint

**Redis Key:** `license:live:Tasking 422:11c0-6c09-f5c9-7137`

```json
{
  "Name": "Tasking 422",
  "Region": "India",
  "Feature": "11c0-6c09-f5c9-7137",
  "Total Issued": 3,
  "In Use": 2,
  "Last Updated": "2026-06-24T10:45:00Z",
  "users": [
    {
      "Username": "rvaithi1",
      "Hostname": "INDC30T7H4",
      "Timestamp": "2026-06-23 01:23:12"
    },
    {
      "Username": "vision",
      "Hostname": "MXDJ66W4K3",
      "Timestamp": "2026-06-23 01:40:03"
    }
  ]
}
```
---

## 🛡️ 6. Reliability, Queues & The Janitors

To ensure the Linux server literally never runs out of hard drive space, memory, or crashes from file-locking conflicts:

1. **The Message Broker (`queue_logger.py`):** It creates 4 distinct `asyncio.Queue()` topics (`lmutil`, `rlmutil`, `http`, `catia`). If the disk slows down, payloads safely wait in RAM.
2. **The Highlander Rule (Exclusive File Writers):** Only _one_ async task (`file_writer_worker`) is legally allowed to write to a tool's `.jsonl` file. This completely eliminates race conditions and "File in Use" OS errors.
3. **The Nightly Janitor (`log_cleanup_worker`):** An infinite loop that goes to sleep for `86400` seconds (24 hours). When it wakes up, it runs an `.rglob()` sweep across the disk, permanently `.unlink()`ing any `.jsonl` file older than **30 days**.
4. **Error Log Rotation (`logger_setup.py`):** The `loguru` engine rotates terminal errors into `/logs/errors/error-YYYY-MM-DD.log` at midnight, with a strict retention policy of **14 days**.

---

## 💻 7. Operations & Debugging Cheat Sheet

### 🩺 Real-Time Log Tailing (Linux)

Watch the exact microsecond the data arrives or fails:

```bash
# Watch the primary polling engine for tool failures
tail -f /home/ospadm/kw_usage/logs/errors/error-*.log

# Watch Klocwork FastAPI Receiver (Validating Windows Pushes)
tail -f /home/ospadm/kw_usage/logs/kw_api.log

```

### 🧠 Redis Direct Queries

Verify the backend payload before blaming the React frontend:

```bash
# List every single active license across the entire globe
redis-cli KEYS "license:live:*"

# List only Catia licenses
redis-cli KEYS "license:live:Catia:*"

# View the exact JSON payload for a specific feature
redis-cli GET "license:live:Catia:HD2"

```

### 🪟 Windows PowerShell Debugging

If the Klocwork data stops flowing, open a normal, visible PowerShell window to test the pipeline manually:

```powershell
cd C:\LicenseMonitorAgent\
Test-NetConnection -ComputerName chiprx022.vistcorp.ad.visteon.com -Port 8000
powershell.exe -ExecutionPolicy Bypass -NoProfile -File ".\klockwork_usage_parser.ps1"

```

_(If it succeeds, close the window and re-enable the Task Scheduler background agent)._

```

```
````
