-- ============================================================
-- OneStopPortal — Schema Migration for Existing Ubuntu DB
-- Run this ONLY if the Ubuntu DB is an OLD copy that does NOT
-- have the 'title' and 'aliases' columns yet.
-- 
-- Safe to run multiple times — each ALTER TABLE is wrapped in
-- a transaction and will silently skip if column already exists.
-- ============================================================

PRAGMA journal_mode = DELETE;

-- Add 'title' column (skip if already exists)
BEGIN;
  ALTER TABLE licenses ADD COLUMN title TEXT;
COMMIT;

BEGIN;
  ALTER TABLE licenses ADD COLUMN aliases TEXT;
COMMIT;

-- Backfill: set title = name where missing
UPDATE licenses SET title = name WHERE title IS NULL OR title = '';

-- Backfill: set aliases = ["name"] where missing
UPDATE licenses SET aliases = '["' || name || '"]' WHERE aliases IS NULL OR aliases = '';

-- ── New data rows (licenses added/updated since last deploy) ──
-- These use INSERT OR REPLACE so they upsert without duplicating.
INSERT OR REPLACE INTO licenses VALUES('1785155640015','GreenHills','GR','SW',27000,1,'["Global"]','#2563eb','MULTI Integrated Development Environment','2027-12-31','Active',NULL,NULL,'http://chiprx022.vistcorp.ad.visteon.com:9000/dashboards/6a3cf01d4ae7774c139b4bd6','GreenHills','["GreenHills"]');
INSERT OR REPLACE INTO licenses VALUES('1785157202477','Klockwork','KL','SW',27000,1,'["Global"]','#2563eb','Perforce Klocwork static analysis','2027-12-31','Active',NULL,NULL,'http://chiprx022.vistcorp.ad.visteon.com:9000/dashboards/6a4ce2848d90e715b9ace928','Klockwork','["Klockwork"]');

-- Verify
SELECT '✅ Migration complete. License count: ' || COUNT(*) FROM licenses;
SELECT '   Licenses with title: ' || COUNT(*) FROM licenses WHERE title IS NOT NULL;
SELECT '   Licenses with aliases: ' || COUNT(*) FROM licenses WHERE aliases IS NOT NULL;
