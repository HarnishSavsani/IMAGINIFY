PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE licenses (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      ab TEXT NOT NULL,
      type TEXT NOT NULL,
      port INTEGER NOT NULL,
      sv INTEGER NOT NULL,
      reg TEXT NOT NULL,
      col TEXT NOT NULL,
      desc TEXT NOT NULL,
      expiry TEXT NOT NULL,
      status TEXT NOT NULL,
      osType TEXT,
      lingerTime TEXT,
      dashboardUrl TEXT
    , title TEXT, aliases TEXT);
INSERT INTO licenses VALUES('1','CST','CS','ECAD',27015,3,'["India, Bulgaria, Mexico"]','#185FA5','CAD/EMC simulation suite','2026-12-31','Active',NULL,NULL,NULL,'CST','["CST"]');
INSERT INTO licenses VALUES('2','Altia','AL','SW',5058,3,'["India, Bulgaria, Mexico"]','#534AB7','HMI design and testing platform','2026-12-31','Active',NULL,NULL,NULL,'Altia','["Altia"]');
INSERT INTO licenses VALUES('3','ProveTech','PR','SW',27070,3,'["Global"]','#993C1D','Test automation and validation','2026-12-31','Active',NULL,NULL,'http://chiprx022.vistcorp.ad.visteon.com:9000/dashboards/6a478e0abc6acba3f0f69b68','ProveTech','["ProveTech"]');
INSERT INTO licenses VALUES('4','QNX V7','QN','SW',7130,1,'["Global"]','#0F6E56','QNX real-time OS v7 toolchain','2026-12-31','Active',NULL,NULL,NULL,'QNX V7','["QNX V7"]');
INSERT INTO licenses VALUES('5','QNX V8','QN','SW',7131,1,'["Global"]','#085041','QNX real-time OS v8 toolchain','2026-12-31','Active',NULL,NULL,NULL,'QNX V8','["QNX V8"]');
INSERT INTO licenses VALUES('6','NI','NI','MCAD',27018,3,'["Global"]','#854F0B','National Instruments test tools','','Active',NULL,NULL,'http://chiprx022.vistcorp.ad.visteon.com:9000/dashboards/6a6c671beae20469f92c2584','NI','["NI"]');
INSERT INTO licenses VALUES('7','MATLAB - US','MA','SW',27000,1,'["US"]','#A32D2D','MathWorks MATLAB — US pool','2100-12-31','Active',NULL,NULL,NULL,'MATLAB - US','["MATLAB - US"]');
INSERT INTO licenses VALUES('8','MATLAB - India','MA','SW',27001,1,'["India"]','#791F1F','MathWorks MATLAB — India pool','2100-12-31','Active',NULL,NULL,NULL,'MATLAB - India','["MATLAB - India"]');
INSERT INTO licenses VALUES('10','MATHCAD - US','MA','ECAD',7788,1,'["US"]','#26215C','PTC Mathcad — US pool','2100-12-31','Active',NULL,NULL,NULL,'MATHCAD - US','["MATHCAD - US"]');
INSERT INTO licenses VALUES('11','Windchill','WI','MCAD',7788,2,'["Global"]','#0C447C','PTC Windchill PLM platform','2100-12-31','Active',NULL,NULL,NULL,'Windchill','["Windchill"]');
INSERT INTO licenses VALUES('12','GBC','GB','PLM',8575,3,'["Global"]','#27500A','Teamcenter GBC engineering suite','2100-12-31','Active',NULL,NULL,NULL,'GBC','["GBC"]');
INSERT INTO licenses VALUES('13','ARM','AR','SW',7581,3,'["Global"]','#633806','Arm Development Studio toolchain','2100-12-31','Active',NULL,NULL,NULL,'ARM','["ARM"]');
INSERT INTO licenses VALUES('14','COSMIC','CO','SW',5059,3,'["Global"]','#042C53','COSMIC C compiler for embedded','2026-12-31','Active',NULL,NULL,NULL,'COSMIC','["COSMIC"]');
INSERT INTO licenses VALUES('15','Saber','SA','ECAD',27020,3,'["Global"]','#185FA5','Synopsys SABER simulation suite','2026-12-21','Active',NULL,NULL,NULL,'Saber','["Saber"]');
INSERT INTO licenses VALUES('16','PSPICE','PS','ECAD',5280,1,'["Global"]','#993556','Cadence PSpice circuit simulator','2026-12-31','Active',NULL,NULL,NULL,'PSPICE','["PSPICE"]');
INSERT INTO licenses VALUES('17','Metroworks/Codewarrior','ME','SW',1700,1,'["Global"]','#0F6E56','Codewarrior embedded IDE','2100-12-31','Active',NULL,NULL,NULL,'Metroworks/Codewarrior','["Metroworks/Codewarrior"]');
INSERT INTO licenses VALUES('18','Xtensa','XT','SW',27002,1,'["Global"]','#993C1D','Cadence Xtensa processor tools','2027-04-12','Active',NULL,NULL,NULL,'Xtensa','["Xtensa"]');
INSERT INTO licenses VALUES('19','Xilinx','XI','SW',2100,1,'["Global"]','#A32D2D','AMD Xilinx FPGA design tools','2100-12-31','Active',NULL,NULL,NULL,'Xilinx','["Xilinx"]');
INSERT INTO licenses VALUES('20','Tasking Flexlm','TA','SW',27012,1,'["Global"]','#0C447C','Tasking compiler — FlexLM pool','2026-12-31','Active',NULL,NULL,NULL,'Tasking Flexlm','["Tasking Flexlm"]');
INSERT INTO licenses VALUES('21','3DCS','3D','MCAD',1808,1,'["Global"]','#3B6D11','Dimensional analysis & simulation','2100-12-31','Active',NULL,NULL,NULL,'3DCS','["3DCS"]');
INSERT INTO licenses VALUES('22','T System India','T ','MCAD',1580,1,'["India"]','#534AB7','T-Systems platform — India','','Active',NULL,NULL,NULL,'T System India','["T System India"]');
INSERT INTO licenses VALUES('23','T System sofia','T ','MCAD',1580,1,'["Sofia"]','#3C3489','T-Systems platform — Sofia','2027-01-31','Active',NULL,NULL,NULL,'T System sofia','["T System sofia"]');
INSERT INTO licenses VALUES('24','ISOGRAPH','IS','SW',27001,1,'["Global"]','#0C447C','Reliability and safety analysis','2100-12-31','Active',NULL,NULL,NULL,'ISOGRAPH','["ISOGRAPH"]');
INSERT INTO licenses VALUES('25','Plecs','PL','SW',27020,1,'["Global"]','#3B6D11','Power electronics simulation','2100-12-31','Active',NULL,NULL,NULL,'Plecs','["Plecs"]');
INSERT INTO licenses VALUES('26','Defensic','DE','MCAD',4595,1,'["Global"]','#185FA5','Automotive cybersecurity testing','2027-04-27','Active',NULL,NULL,NULL,'Defensic','["Defensic"]');
INSERT INTO licenses VALUES('27','ETAS','ET','SW',3827,1,'["Global"]','#854F0B','ETAS embedded development suite','2100-12-31','Active',NULL,NULL,NULL,'ETAS','["ETAS"]');
INSERT INTO licenses VALUES('28','Electrobit','EL','SW',13991,1,'["Global"]','#27500A','Electrobit AUTOSAR tools (new)','2027-01-31','Active',NULL,NULL,NULL,'Electrobit','["Electrobit"]');
INSERT INTO licenses VALUES('29','IBM','IB','SW',1950,3,'["Global"]','#0C447C','IBM engineering software suite','','Active',NULL,NULL,NULL,'IBM','["IBM"]');
INSERT INTO licenses VALUES('30','VectorCast','VE','SW',27070,3,'["Global"]','#72243E','VECTOR unit test automation','2100-12-31','Active',NULL,NULL,NULL,'VectorCast','["VectorCast"]');
INSERT INTO licenses VALUES('31','PRQA','PR','SW',1800,3,'["Global"]','#712B13','Perforce PRQA static analysis','2100-12-31','Active',NULL,NULL,NULL,'PRQA','["PRQA"]');
INSERT INTO licenses VALUES('33','Kanzi','KA','SW',5053,4,'["India, Bulgaria, Mexico, USA"]','#3B6D11','Rightware Kanzi HMI platform','2100-12-31','Active',NULL,NULL,NULL,'Kanzi','["Kanzi"]');
INSERT INTO licenses VALUES('35','Viewmate','VI','ECAD',5053,1,'["Global"]','#085041','Gerber Viewmate PCB viewer','2100-12-31','Active',NULL,NULL,NULL,'Viewmate','["Viewmate"]');
INSERT INTO licenses VALUES('36','Tasking 422','TA','SW',9090,1,'["India"]','#854F0B','7 keys · GLCPD422 · Linux & Windows','2026-12-31','Active','Linux','25','http://chiprx022.vistcorp.ad.visteon.com:9000/dashboards/6a68318320eb28ab24732d00','Tasking 422','["Tasking 422"]');
INSERT INTO licenses VALUES('37','Tasking 423','TA','SW',9090,1,'["Mexico"]','#633806','3 keys · GLCPD423 · Linux','2026-12-31','Active','Linux',NULL,NULL,'Tasking 423','["Tasking 423"]');
INSERT INTO licenses VALUES('38','Tasking 424','TA','SW',9090,1,'["Sofia"]','#412402','2 keys · GLCPD424 · Linux & Windows','2026-12-31','Active','Windows',NULL,NULL,'Tasking 424','["Tasking 424"]');
INSERT INTO licenses VALUES('39','Tasking 479','TA','SW',9090,1,'["Sofia CI"]','#993C1D','1 key · GLCPP479 · CI license','2026-12-31','Active','Linux','10',NULL,'Tasking 479','["Tasking 479"]');
INSERT INTO licenses VALUES('40','Tasking 480','TA','SW',9090,1,'["US"]','#712B13','1 key · GLCPP480 · Linux','2026-12-31','Active','Linux','25',NULL,'Tasking 480','["Tasking 480"]');
INSERT INTO licenses VALUES('41','Tasking 481','TA','SW',9090,1,'["India CI"]','#BA7517','1 key · GLCPP481 · CI license','2026-12-31','Active','Linux','10',NULL,'Tasking 481','["Tasking 481"]');
INSERT INTO licenses VALUES('43','Catia','CA','MCAD',4084,1,'["Global"]','#534AB7','Dassault Systemes Catia','2027-12-31','Active','Windows',NULL,'http://chiprx022.vistcorp.ad.visteon.com:9000/dashboards/6a27a69dba71b57e155edfe3','Catia','["Catia"]');
INSERT INTO licenses VALUES('44','Autodesk','AU','MCAD',27005,1,'["Global"]','#0C447C','Autodesk AutoCAD & Inventor design suite','2100-12-31','Active',NULL,NULL,NULL,'Autodesk','["Autodesk"]');
INSERT INTO licenses VALUES('45','Electrobit - Guide','EL','SW',13992,1,'["Global"]','#27500A','Electrobit Guide AUTOSAR tooling','2099-12-31','Active',NULL,NULL,NULL,'Electrobit - Guide','["Electrobit - Guide"]');
INSERT INTO licenses VALUES('46','Electrobit - Tresos','EL','SW',13993,1,'["Global"]','#3B6D11','Electrobit Tresos AUTOSAR stack','2027-01-31','Active',NULL,NULL,NULL,'Electrobit - Tresos','["Electrobit - Tresos"]');
INSERT INTO licenses VALUES('47','KeysightADS Pathwave','KE','ECAD',27009,1,'["Global"]','#A32D2D','Keysight ADS Pathwave RF simulation','','Active',NULL,NULL,NULL,'KeysightADS Pathwave','["KeysightADS Pathwave"]');
INSERT INTO licenses VALUES('48','Tasking punpdv015','TA','SW',9090,1,'["China"]','#854F0B','1 key · GLCPP481 · Linux','2026-12-31','Active','Linux','25',NULL,'Tasking punpdv015','["Tasking punpdv015"]');
INSERT INTO licenses VALUES('49','Windriver','WI','SW',27003,1,'["Global"]','#0F6E56','Wind River VxWorks development tools','2100-12-31','Active',NULL,NULL,NULL,'Windriver','["Windriver"]');
INSERT INTO licenses VALUES('1785128960912','MATHCAD - Global','MA','ECAD',27000,1,'["Global"]','#2563eb','PTC Mathcad — Global pool','2100-12-31','Active',NULL,NULL,NULL,'MATHCAD - Global','["MATHCAD - Global"]');
INSERT INTO licenses VALUES('1785155640015','GreenHills','GR','SW',27000,1,'["Global"]','#2563eb','MULTI Integrated Development Environment','2027-12-31','Active',NULL,NULL,'http://chiprx022.vistcorp.ad.visteon.com:9000/dashboards/6a3cf01d4ae7774c139b4bd6','GreenHills','["GreenHills"]');
INSERT INTO licenses VALUES('1785157202477','Klockwork','KL','SW',27000,1,'["Global"]','#2563eb','Perforce Klocwork static analysis','2027-12-31','Active',NULL,NULL,'http://chiprx022.vistcorp.ad.visteon.com:9000/dashboards/6a4ce2848d90e715b9ace928','Klockwork','["Klockwork"]');
CREATE TABLE applications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      status TEXT NOT NULL,
      latency INTEGER,
      url TEXT NOT NULL,
      category TEXT NOT NULL,
      auth_type TEXT DEFAULT 'none',
      auth_token TEXT,
      last_checked TEXT
    , health_status TEXT DEFAULT 'Active');
INSERT INTO applications VALUES(4,'Artifactory-Bangalore','Active',5000,'http://jfrog.bangalore.visteon.com','Artifacts','none',NULL,'2026-08-11 14:30:05','Slow');
INSERT INTO applications VALUES(5,'Artifactory-Chennai','Active',5000,'http://jfrog.chennai.visteon.com/ui','Artifacts','none',NULL,'2026-08-11 14:30:05','Slow');
INSERT INTO applications VALUES(6,'Artifactory-China','Active',5000,'http://jfrog.china.visteon.com/ui','Artifacts','none',NULL,'2026-08-11 14:30:05','Slow');
INSERT INTO applications VALUES(7,'Artifactory-GLCC','Active',5000,'http://jfrog.glcc.visteon.com/ui','Artifacts','none',NULL,'2026-08-11 14:30:05','Slow');
INSERT INTO applications VALUES(8,'Artifactory-JLR','Active',5000,'https://jlr.jfrog.visteon.com','Artifacts','none',NULL,'2026-08-11 14:30:05','Slow');
INSERT INTO applications VALUES(9,'Artifactory-Mexico','Active',5000,'http://jfrog.mexico.visteon.com/ui','Artifacts','none',NULL,'2026-08-11 14:30:05','Slow');
INSERT INTO applications VALUES(10,'Artifactory-Pune','Active',5000,'http://jfrog.pune.visteon.com/ui','Artifacts','none',NULL,'2026-08-11 14:30:05','Slow');
INSERT INTO applications VALUES(11,'Artifactory-Sofia','Active',5000,'http://jfrog.sofia.visteon.com/ui','Artifacts','none',NULL,'2026-08-11 14:30:05','Slow');
INSERT INTO applications VALUES(12,'Artifactory-Wuhan','Active',5000,'http://jfrog.wuhan.visteon.com/ui','Artifacts','none',NULL,'2026-08-11 14:30:05','Slow');
INSERT INTO applications VALUES(13,'DataX','Active',5000,'https://datax.visteon.com:8444','Data','none',NULL,'2026-08-11 14:30:05','Slow');
INSERT INTO applications VALUES(16,'GBC','Active',5000,'http://gbc.visteon.com','Engineering Tools','none',NULL,'2026-08-11 14:30:05','Slow');
INSERT INTO applications VALUES(17,'GBCLite','Active',5000,'http://gbc.visteon.com/gbclite/controller/home','Engineering Tools','none',NULL,'2026-08-11 14:30:05','Slow');
INSERT INTO applications VALUES(18,'GIT','Active',5000,'https://git.visteon.com','VCS','none',NULL,'2026-08-11 14:30:05','Slow');
INSERT INTO applications VALUES(19,'GIT-Bangalore','Active',5000,'https://bangalore.git.visteon.com','VCS','none',NULL,'2026-08-11 14:30:05','Slow');
INSERT INTO applications VALUES(20,'GIT-BLR','Active',5000,'https://blr.git.visteon.com','VCS','none',NULL,'2026-08-11 14:30:05','Slow');
INSERT INTO applications VALUES(21,'GIT-BSP-OS','Active',5000,'https://bsp-os.git.visteon.com','VCS','none',NULL,'2026-08-11 14:30:05','Slow');
INSERT INTO applications VALUES(22,'GIT-China','Slow',5000,'http://git.china.visteon.com','VCS','none',NULL,'2026-08-11 14:30:05','Slow');
INSERT INTO applications VALUES(23,'GIT-Chennai','Active',5000,'https://chennai.git.visteon.com','VCS','none',NULL,'2026-08-11 14:30:05','Slow');
INSERT INTO applications VALUES(24,'GIT-Customer','Active',5000,'https://customer.git.visteon.com','VCS','none',NULL,'2026-08-11 14:30:05','Slow');
INSERT INTO applications VALUES(25,'GIT-EU','Active',5000,'https://eu.git.visteon.com','VCS','none',NULL,'2026-08-11 14:30:05','Slow');
INSERT INTO applications VALUES(26,'GIT-GLCC','Active',5000,'https://glcc.git.visteon.com','VCS','none',NULL,'2026-08-11 14:30:05','Slow');
INSERT INTO applications VALUES(27,'GIT-JLR','Active',5000,'https://jlr.git.visteon.com','VCS','none',NULL,'2026-08-11 14:30:05','Slow');
INSERT INTO applications VALUES(28,'GIT-Pune','Active',5000,'http://git.pune.visteon.com','VCS','none',NULL,'2026-08-11 14:30:05','Slow');
INSERT INTO applications VALUES(29,'GIT-RTC','Active',5000,'https://rtc-proj.git.visteon.com','VCS','none',NULL,'2026-08-11 14:30:05','Slow');
INSERT INTO applications VALUES(30,'GIT-Sofia','Active',5000,'https://sofia.git.visteon.com','VCS','none',NULL,'2026-08-11 14:30:05','Slow');
INSERT INTO applications VALUES(31,'GIT-Wuhan','Active',5000,'http://git.wuhan.visteon.com','VCS','none',NULL,'2026-08-11 14:30:05','Slow');
INSERT INTO applications VALUES(32,'Jenkins','Active',5000,'http://jenkins-mfa2.sofia.visteon.com:8080/','CI/CD','none',NULL,'2026-08-11 14:30:05','Slow');
INSERT INTO applications VALUES(33,'Jenkins-chipd007','Active',5000,'http://chipd007.chennai.visteon.com:9090','CI/CD','none',NULL,'2026-08-11 14:30:05','Slow');
INSERT INTO applications VALUES(34,'Jenkins-chipd008','Active',5000,'http://chipd008.chennai.visteon.com:8080/','CI/CD','none',NULL,'2026-08-11 14:30:05','Slow');
INSERT INTO applications VALUES(35,'Jenkins-chipd010','Active',5000,'http://chipd010.chennai.visteon.com:8080','CI/CD','none',NULL,'2026-08-11 14:30:05','Slow');
INSERT INTO applications VALUES(37,'Jenkins-chipdvxr01','Active',5000,'http://chipdvxr01.chennai.visteon.com:8080','CI/CD','none',NULL,'2026-08-11 14:30:05','Slow');
INSERT INTO applications VALUES(38,'Jenkins-vtcepp0011','Active',5000,'http://vtcepp0011.vtci.visteon.com:9090/jenkins/','CI/CD','none',NULL,'2026-08-11 14:30:05','Slow');
INSERT INTO applications VALUES(43,'Klockwork1','Active',5000,'https://kw.group1.visteon.com:8443/review/insight-review.html','Code Quality','none',NULL,'2026-08-11 14:30:05','Slow');
INSERT INTO applications VALUES(44,'Klockwork2','Active',5000,'https://kw.group2.visteon.com:8443/review/insight-review.html','Code Quality','none',NULL,'2026-08-11 14:30:05','Slow');
INSERT INTO applications VALUES(45,'Klockwork3','Active',5000,'https://kw.group3.visteon.com:8443/review/insight-review.html','Code Quality','none',NULL,'2026-08-11 14:30:05','Slow');
INSERT INTO applications VALUES(46,'Klockwork4','Active',5000,'https://kw.group4.visteon.com:8443/review/insight-review.html','Code Quality','none',NULL,'2026-08-11 14:30:05','Slow');
INSERT INTO applications VALUES(47,'Klockwork5','Active',5000,'https://kw.group5.visteon.com:8443/review/insight-review.html','Code Quality','none',NULL,'2026-08-11 14:30:05','Slow');
INSERT INTO applications VALUES(49,'vBuyer','Active',5000,'http://vbuyer.visteon.com/','Procurement','none',NULL,'2026-08-11 14:30:05','Slow');
CREATE TABLE admins (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      cdsid TEXT NOT NULL UNIQUE,
      email TEXT NOT NULL,
      role TEXT DEFAULT 'admin',
      created_at TEXT NOT NULL
    );
INSERT INTO admins VALUES(1,'admin','admin@visteon.com','admin','2026-07-23 13:03:16');
INSERT INTO admins VALUES(2,'hatul','hatul@visteon.com','admin','2026-07-25 05:07:15');
INSERT INTO admins VALUES(3,'sbhola','sbhola@visteon.com','admin','2026-07-27 05:27:36');
INSERT INTO admins VALUES(4,'smuruga4','smuruga4@visteon.com','admin','2026-08-10 06:33:52');
CREATE TABLE notification_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sender_cdsid TEXT NOT NULL,
      target_username TEXT NOT NULL,
      license_name TEXT NOT NULL,
      feature TEXT NOT NULL,
      sent_at TEXT NOT NULL,
      status TEXT NOT NULL
    );
INSERT INTO notification_logs VALUES(1,'hatul','Tester','NI','LabVIEW_PID','2026-07-23 13:48:45','SUCCESS');
INSERT INTO notification_logs VALUES(2,'hatul','Admin','NI','LabVIEW_PID','2026-07-23 13:49:03','SUCCESS');
INSERT INTO sqlite_sequence VALUES('applications',53);
INSERT INTO sqlite_sequence VALUES('admins',4);
INSERT INTO sqlite_sequence VALUES('notification_logs',2);
COMMIT;
