import { Router } from 'express';
import licenseRoutes from './license.routes';
import authRoutes from './auth.routes';
import notifyRoutes from './notify.routes';
import adminRoutes from './admin.routes';

const router = Router();

router.use('/licenses', licenseRoutes);
router.use('/auth', authRoutes);
router.use('/notify', notifyRoutes);
router.use('/admin', adminRoutes);

export default router;
