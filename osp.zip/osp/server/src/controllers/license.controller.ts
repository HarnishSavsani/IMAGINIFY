import { Request, Response } from 'express';
import { DbService } from '../services/db.service';
import { RedisService } from '../services/redis.service';

export class LicenseController {
  static getAllLicenses(req: Request, res: Response) {
    try {
      const licenses = DbService.getAllLicenses();
      res.json(licenses);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  }

  static getLicenseById(req: Request, res: Response) {
    try {
      const license = DbService.getLicenseById(req.params.id);
      if (!license) {
        return res.status(404).json({ error: 'License not found' });
      }
      res.json(license);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  }

  static async getLiveUsage(req: Request, res: Response) {
    try {
      const { name } = req.params;
      const license = DbService.getLicenseByName(name) || DbService.getLicenseById(name);
      const aliases = license ? license.aliases : [name];
      
      const allData = await RedisService.getAllLiveLicenseData();
      const result: any[] = [];

      const normTargets = aliases.map((alias: string) => alias.toLowerCase().replace(/[^a-z0-9]/g, ''));

      Object.values(allData).forEach(item => {
        if (!item || !item.Name) return;
        const normItem = item.Name.toLowerCase().replace(/[^a-z0-9]/g, '');
        const matches = normTargets.some((target: string) => normItem.includes(target) || target.includes(normItem));
        if (matches) {
          result.push(item);
        }
      });

      res.json(result);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  }

  static createLicense(req: Request, res: Response) {
    try {
      const created = DbService.createLicense(req.body);
      res.status(201).json(created);
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  }

  static updateLicense(req: Request, res: Response) {
    try {
      const updated = DbService.updateLicense(req.params.id, req.body);
      if (!updated) {
        return res.status(404).json({ error: 'License not found' });
      }
      res.json(updated);
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  }

  static deleteLicense(req: Request, res: Response) {
    try {
      const success = DbService.deleteLicense(req.params.id);
      if (!success) {
        return res.status(404).json({ error: 'License not found' });
      }
      res.json({ message: 'License deleted successfully' });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  }
}
