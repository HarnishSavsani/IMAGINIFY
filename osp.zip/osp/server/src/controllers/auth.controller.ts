import { Request, Response } from 'express';
import { LdapService } from '../services/ldap.service';
import { DbService } from '../services/db.service';
import { config } from '../config';

export class AuthController {
  static async login(req: Request, res: Response) {
    try {
      const { cdsid, email, password } = req.body;

      if (!cdsid) {
        return res.status(400).json({ error: 'CDSID is required' });
      }

      // 1. Check if the user is registered in the SQLite admins table first
      const admins = DbService.getAllAdmins();
      const isAdmin = admins.some(
        (admin: any) => admin.cdsid.toLowerCase() === cdsid.toLowerCase()
      );

      if (!isAdmin) {
        return res.status(403).json({ error: 'Access Denied: You are not authorized as an administrator.' });
      }

      const targetEmail = email || `${cdsid}@visteon.com`;

      // 2. If cdsid is 'admin', verify password against SYSTEM_ADMIN_PASSWORD configured in .env
      if (cdsid.toLowerCase() === 'admin') {
        if (!password || password !== config.SYSTEM_ADMIN_PASSWORD) {
          return res.status(401).json({ error: 'Invalid password for system administrator.' });
        }
      } else {
        // 3. For all other users, perform actual LDAP credential bind check
        const ldapResult = await LdapService.verifyUser(cdsid, targetEmail, password);
        if (!ldapResult.success) {
          return res.status(401).json({ error: ldapResult.message });
        }
      }

      res.json({
        success: true,
        message: 'Login successful',
        user: {
          cdsid,
          email: targetEmail,
        },
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  }
}
