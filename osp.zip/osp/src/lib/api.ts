const API_BASE = import.meta.env.VITE_API_URL || '/api';

export class ApiClient {
  private static async request<T>(endpoint: string, options?: RequestInit): Promise<T> {
    const res = await fetch(`${API_BASE}${endpoint}`, {
      headers: {
        'Content-Type': 'application/json',
        ...options?.headers,
      },
      ...options,
    });

    if (!res.ok) {
      const errData = await res.json().catch(() => ({ error: res.statusText }));
      throw new Error(errData.error || 'API Request failed');
    }

    return res.json();
  }

  // --- LICENSES ---
  static getLicenses() {
    return this.request<any[]>('/licenses');
  }

  static getLicenseById(id: string) {
    return this.request<any>(`/licenses/${id}`);
  }

  static getLiveUsage(name: string) {
    return this.request<any[]>(`/licenses/usage/${encodeURIComponent(name)}`);
  }

  static createLicense(data: any) {
    return this.request<any>('/licenses', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  static updateLicense(id: string, data: any) {
    return this.request<any>(`/licenses/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  }

  static deleteLicense(id: string) {
    return this.request<{ message: string }>(`/licenses/${id}`, {
      method: 'DELETE',
    });
  }


  // --- AUTH & NOTIFICATIONS ---
  static login(cdsid: string, password?: string, email?: string) {
    return this.request<{ success: boolean; user: any }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ cdsid, password, email }),
    });
  }

  static sendReleaseRequest(data: {
    senderCdsid: string;
    senderEmail?: string;
    targetUsername: string;
    targetEmail?: string;
    licenseName: string;
    feature: string;
    hostname?: string;
    checkoutTimestamp?: string;
  }) {
    return this.request<{ success: boolean; message: string }>('/notify/release-request', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  static sendContactMessage(data: { cdsid: string; email: string; message: string }) {
    return this.request<{ success: boolean; message: string }>('/notify/contact', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }


  // --- ADMINS ---
  static getAdmins() {
    return this.request<any[]>('/admin');
  }

  static createAdmin(cdsid: string, email: string, role?: string) {
    return this.request<any>('/admin', {
      method: 'POST',
      body: JSON.stringify({ cdsid, email, role }),
    });
  }

  static deleteAdmin(id: number) {
    return this.request<{ message: string }>(`/admin/${id}`, {
      method: 'DELETE',
    });
  }
}
