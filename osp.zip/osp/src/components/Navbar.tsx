import { useState } from "react";
import { ChevronDown, Cloud, Shield, Key, Database, Moon, Sun, Menu, X, Activity } from "lucide-react";
import { useTheme } from "./ThemeProvider";
import { Link } from "react-router-dom";

import { Logo } from "./Logo";


export default function Navbar() {
  const { theme, toggleTheme } = useTheme();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleLogoClick = (e: import("react").MouseEvent<HTMLAnchorElement>) => {
    if (window.location.pathname === "/") {
      e.preventDefault();
      window.scrollTo({ top: 0, behavior: "smooth" });
      setIsMobileMenuOpen(false);
    }
  };

  const handleNavClick = (e: import("react").MouseEvent<HTMLAnchorElement>, hash: string) => {
    if (window.location.pathname === "/") {
      const element = document.getElementById(hash.replace("#", ""));
      if (element) {
        e.preventDefault();
        element.scrollIntoView({ behavior: "smooth" });
        setIsMobileMenuOpen(false);
        window.history.pushState(null, "", hash);
      }
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/80 dark:bg-[#0a0a0a]/80 backdrop-blur-md border-b border-gray-100 dark:border-zinc-800 transition-colors duration-300">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Left: OSP Logo */}
        <Link to="/" onClick={handleLogoClick} className="flex items-center gap-2">
          <Logo className="text-2xl" />
        </Link>

        {/* Center: Nav links and theme toggle */}
        <div className="hidden lg:flex items-center gap-6">
          <ul className="flex items-center gap-1 text-sm font-medium text-gray-700 dark:text-zinc-300">
            <li className="relative group p-2">
               <Link to="/licenses" className="flex items-center gap-1 hover:text-gray-900 dark:hover:text-white transition-colors py-2 px-3 rounded-md hover:bg-gray-50 dark:hover:bg-zinc-900/50">
                 Licenses
               </Link>
            </li>
            <li className="relative group p-2">
               <Link to="/#faq-contact" onClick={(e) => handleNavClick(e, "#faq-contact")} className="flex items-center gap-1 hover:text-gray-900 dark:hover:text-white transition-colors py-2 px-3 rounded-md hover:bg-gray-50 dark:hover:bg-zinc-900/50">
                 Contact
               </Link>
            </li>
          </ul>

          <button onClick={toggleTheme} className="p-2 text-gray-500 dark:text-zinc-400 bg-gray-50 dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 hover:text-gray-900 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-zinc-800 rounded-full transition-colors">
            {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
        </div>

        {/* Right: Visteon Logo & Mobile Trigger */}
        <div className="flex items-center gap-4">
          <div className="h-8 flex items-center">
            <img src="/logo.png" alt="Visteon Logo" className="h-8 w-auto object-contain dark:brightness-0 dark:invert" />
          </div>
          
          <button 
            className="lg:hidden p-2.5 text-gray-500 dark:text-zinc-400 bg-gray-50 dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 hover:text-gray-900 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-zinc-800 rounded-lg transition-colors"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </nav>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="lg:hidden bg-white dark:bg-[#0a0a0a] border-b border-gray-100 dark:border-zinc-800">
          <ul className="px-4 pt-2 pb-4 space-y-1">
            <li>
              <Link to="/licenses" onClick={() => setIsMobileMenuOpen(false)} className="w-full flex items-center justify-between text-left px-3 py-3 font-medium text-gray-900 dark:text-zinc-100 rounded-lg hover:bg-gray-50 dark:hover:bg-zinc-900/50 transition-colors">
                Licenses
              </Link>
            </li>
            <li>
              <Link to="/#faq-contact" onClick={(e) => handleNavClick(e, "#faq-contact")} className="w-full flex items-center justify-between text-left px-3 py-3 font-medium text-gray-900 dark:text-zinc-100 rounded-lg hover:bg-gray-50 dark:hover:bg-zinc-900/50 transition-colors">
                Contact
              </Link>
            </li>
            <li className="px-3 py-3 flex items-center justify-between">
              <span className="text-sm font-medium text-gray-700 dark:text-zinc-300">Theme</span>
              <button onClick={toggleTheme} className="p-2 text-gray-500 dark:text-zinc-400 bg-gray-50 dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-full">
                {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
              </button>
            </li>
          </ul>
        </div>
      )}
    </header>
  );
}
