import { useState, useEffect } from 'react';
import { ApiClient } from '../lib/api';
import { useWebSocket } from './useWebSocket';
import { RedisLicenseFeature } from '../types';

export function useLiveUsage(licenseName: string, aliases?: string[]) {
  const [usageData, setUsageData] = useState<RedisLicenseFeature[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isOnline, setIsOnline] = useState(true);

  const { isConnected, lastMessage } = useWebSocket(licenseName);
  const matchTargets = aliases && aliases.length > 0 ? aliases : [licenseName];

  // 1. Initial REST API load
  useEffect(() => {
    let isMounted = true;
    setIsLoading(true);

    ApiClient.getLiveUsage(licenseName)
      .then((data) => {
        if (!isMounted) return;
        if (data && data.length > 0) {
          setUsageData(data);
          setIsOnline(true);
        } else {
          setIsOnline(false);
          setUsageData([]);
        }
      })
      .catch(() => {
        if (!isMounted) return;
        setIsOnline(false);
        setUsageData([]);
      })
      .finally(() => {
        if (isMounted) setIsLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [licenseName]);

  // 2. Real-time WebSocket updates
  useEffect(() => {
    if (!lastMessage) return;

    const matchesGroup = lastMessage.type === 'license_group_update' &&
      lastMessage.group &&
      matchTargets.some(alias => lastMessage.group.toLowerCase().includes(alias.toLowerCase()));

    if (matchesGroup) {
      if (lastMessage.fullGroupData && lastMessage.fullGroupData.length > 0) {
        setUsageData(lastMessage.fullGroupData);
        setIsOnline(true);
      }
    } else if (lastMessage.type === 'redis_update' && lastMessage.data) {
      const normTargets = matchTargets.map(alias => alias.toLowerCase().replace(/[^a-z0-9]/g, ''));
      const matched: RedisLicenseFeature[] = [];

      Object.values(lastMessage.data).forEach((item: any) => {
        if (!item || !item.Name) return;
        const normItem = item.Name.toLowerCase().replace(/[^a-z0-9]/g, '');
        const isMatch = normTargets.some(target => normItem.includes(target) || target.includes(normItem));
        if (isMatch) {
          matched.push(item);
        }
      });

      if (matched.length > 0) {
        setUsageData(matched);
        setIsOnline(true);
      }
    }
  }, [lastMessage, licenseName, aliases]);

  return { usageData, isLoading, isOnline, isConnected };
}
