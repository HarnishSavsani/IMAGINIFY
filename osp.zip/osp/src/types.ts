export interface NavItem {
  title: string;
  href: string;
}

export interface RedisUser {
  Username: string;
  Hostname: string;
  Timestamp: string;
  [key: string]: any;
}

export interface RedisLicenseFeature {
  Name: string;
  Region: string;
  Feature: string;
  "Total Issued": number;
  "In Use": number;
  "Last Updated": string;
  users: RedisUser[];
}

export interface License {
  id: string;
  name: string;
  ab: string;
  type: string;
  port: number;
  sv: number;
  reg: string[];
  col: string;
  vendor: string;
  expiry: string;
  status: 'Active' | 'Inactive';
  title?: string;
  aliases?: string[];
  osType?: string;
  lingerTime?: string;
  dashboardUrl?: string;
}
