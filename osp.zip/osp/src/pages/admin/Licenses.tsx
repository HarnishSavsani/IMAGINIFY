import { useState, useMemo, useRef, useEffect } from "react";
import { Search, Plus, FileEdit, Trash2, Download, X, AlertCircle, ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight, CirclePlus, Check, ChevronDown, ChevronUp, ChevronsUpDown } from "lucide-react";
import { FaWindows, FaApple, FaUbuntu, FaLinux } from 'react-icons/fa';
import { SiCentos, SiRedhat } from 'react-icons/si';
import { ApiClient } from "../../lib/api";
import { toast } from "sonner";


const getBadgeStyle = (type: string) => {
  if (type === 'FlexLM') return "bg-blue-100/50 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400 border-blue-200 dark:border-blue-800";
  if (type === 'RLM') return "bg-emerald-100/50 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800";
  if (type === 'Tasking') return "bg-amber-100/50 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400 border-amber-200 dark:border-amber-800";
  if (type === 'DSLS') return "bg-red-100/50 text-red-700 dark:bg-red-900/30 dark:text-red-400 border-red-200 dark:border-red-800";
  let hash = 0;
  for (let i = 0; i < type.length; i++) {
    hash = type.charCodeAt(i) + ((hash << 5) - hash);
  }
  const i = Math.abs(hash) % 4;
  const classes = [
    "bg-purple-100/50 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400 border-purple-200 dark:border-purple-800",
    "bg-cyan-100/50 text-cyan-700 dark:bg-cyan-900/30 dark:text-cyan-400 border-cyan-200 dark:border-cyan-800",
    "bg-indigo-100/50 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-400 border-indigo-200 dark:border-indigo-800",
    "bg-pink-100/50 text-pink-700 dark:bg-pink-900/30 dark:text-pink-400 border-pink-200 dark:border-pink-800",
  ];
  return classes[i];
};

const OS_OPTIONS = [
  { value: "", label: "Select OS...", icon: <div className="w-4 h-4"></div> },
  { value: "Windows", label: "Windows", icon: <FaWindows {...({ className: "w-4 h-4 text-purple-500" } as any)} /> },
  { value: "Linux", label: "Linux", icon: <FaLinux {...({ className: "w-4 h-4 text-yellow-500" } as any)} /> },
  { value: "Ubuntu", label: "Ubuntu", icon: <FaUbuntu {...({ className: "w-4 h-4 text-orange-500" } as any)} /> },
  { value: "RedHat", label: "RedHat", icon: <SiRedhat {...({ className: "w-4 h-4 text-red-500" } as any)} /> },
  { value: "CentOS", label: "CentOS", icon: <SiCentos {...({ className: "w-4 h-4 text-green-600" } as any)} /> },
  { value: "Mac", label: "Mac OS", icon: <FaApple {...({ className: "w-4 h-4 text-gray-700 dark:text-zinc-300" } as any)} /> },
  { value: "Other", label: "Other", icon: <div className="w-4 h-4 rounded-full border-2 border-gray-400"></div> }
];

const OSSelect = ({ value, onChange }: { value: string; onChange: (val: string) => void }) => {
  const [isOpen, setIsOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (ref.current && !ref.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const selectedOpt = OS_OPTIONS.find(o => o.value === value) || OS_OPTIONS.find(o => value.toLowerCase().includes(o.value.toLowerCase())) || OS_OPTIONS[0];

  return (
    <div className="relative" ref={ref}>
      <div 
        onClick={() => setIsOpen(!isOpen)}
        className="w-full px-3 py-2 h-[38px] text-sm border border-gray-300 dark:border-zinc-700 rounded-lg flex items-center justify-between cursor-pointer bg-transparent dark:text-zinc-100 focus-within:ring-2 focus-within:ring-blue-500"
      >
        <div className="flex items-center gap-2">
          {selectedOpt.icon}
          <span className={!selectedOpt.value ? "text-gray-400" : ""}>{selectedOpt.label}</span>
        </div>
        <ChevronDown className="w-4 h-4 text-gray-500" />
      </div>
      {isOpen && (
        <div className="absolute z-[110] top-full left-0 right-0 mt-1 bg-white dark:bg-zinc-800 border border-gray-200 dark:border-zinc-700 rounded-lg shadow-lg py-1 max-h-48 overflow-y-auto">
          {OS_OPTIONS.map(opt => (
            <div
              key={opt.value}
              onClick={() => { onChange(opt.value); setIsOpen(false); }}
              className="px-3 py-2 text-sm flex items-center gap-2 hover:bg-gray-100 dark:hover:bg-zinc-700 cursor-pointer dark:text-zinc-100"
            >
              {opt.icon}
              <span className={!opt.value ? "text-gray-400" : ""}>{opt.label}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default function Licenses() {
  const [licenses, setLicenses] = useState<any[]>([]);

  useEffect(() => {
    ApiClient.getLicenses()
      .then(data => {
        if (Array.isArray(data)) setLicenses(data);
      })
      .catch(() => {});
  }, []);

  
  // UI State
  const [searchTerm, setSearchTerm] = useState("");
  const [page, setPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [sortConfig, setSortConfig] = useState<{ key: string, direction: 'asc' | 'desc' | null }>({ key: 'Type', direction: 'asc' });

  // Dropdown UI states
  const [selectedTypes, setSelectedTypes] = useState<Set<string>>(new Set());
  const [isTypeDropdownOpen, setIsTypeDropdownOpen] = useState(false);
  const [typeSearch, setTypeSearch] = useState("");
  
  // Modals state
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [selectedLicense, setSelectedLicense] = useState<any | null>(null);
  const [isAdding, setIsAdding] = useState(false);
  const [formTypeChoice, setFormTypeChoice] = useState("");
  const [formTypeCustom, setFormTypeCustom] = useState("");
  const [formAliases, setFormAliases] = useState<string[]>([]);
  const [formStep, setFormStep] = useState(1);

  // Controlled form state
  const [formName, setFormName] = useState("");
  const [formRegion, setFormRegion] = useState("");
  const [formStatus, setFormStatus] = useState(true);
  const [formSv, setFormSv] = useState(1);
  const [formExpiry, setFormExpiry] = useState("");
  const [formOsType, setFormOsType] = useState("");
  const [formLingerTime, setFormLingerTime] = useState("");
  const [formDashboardUrl, setFormDashboardUrl] = useState("");
  const [formVendorChoice, setFormVendorChoice] = useState("");
  const [formVendorCustom, setFormVendorCustom] = useState("");

  const typeDropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (typeDropdownRef.current && !typeDropdownRef.current.contains(event.target as Node)) {
        setIsTypeDropdownOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const UNIQUE_TYPES = useMemo(() => Array.from(new Set(licenses.map(d => d.type))), [licenses]);
  const typeOptions = useMemo(() => {
    const list = Array.from(new Set([...UNIQUE_TYPES, "FlexLM", "RLM", "Tasking", "DSLS"]));
    return list.filter(Boolean);
  }, [UNIQUE_TYPES]);

  const UNIQUE_VENDORS = useMemo(() => Array.from(new Set(licenses.map(d => d.vendor).filter(Boolean))), [licenses]);
  const vendorOptions = useMemo(() => {
    const list = Array.from(new Set([...UNIQUE_VENDORS, "MathWorks", "Autodesk", "Ansys", "Siemens"]));
    return list.filter(Boolean);
  }, [UNIQUE_VENDORS]);
  const TYPE_COUNTS = useMemo(() => {
    const counts: Record<string, number> = {};
    licenses.forEach(d => {
      counts[d.type] = (counts[d.type] || 0) + 1;
    });
    return counts;
  }, [licenses]);

  const toggleTypeFilter = (t: string) => {
    const next = new Set(selectedTypes);
    if (next.has(t)) next.delete(t);
    else next.add(t);
    setSelectedTypes(next);
    setPage(1);
  };

  const handleSort = (key: string) => {
    let direction: 'asc' | 'desc' | null = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') direction = 'desc';
    else if (sortConfig.key === key && sortConfig.direction === 'desc') direction = null;
    setSortConfig({ key, direction });
  };

  const getSortIcon = (key: string) => {
    if (sortConfig.key !== key || !sortConfig.direction) return <ChevronsUpDown className="w-4 h-4 opacity-50" />;
    if (sortConfig.direction === 'asc') return <ChevronUp className="w-4 h-4 opacity-70" />;
    return <ChevronDown className="w-4 h-4 opacity-70" />;
  };

  const filteredData = useMemo(() => {
    return licenses.filter(row => {
      if (selectedTypes.size > 0 && !selectedTypes.has(row.type)) return false;
      if (searchTerm) {
        const q = searchTerm.toLowerCase();
        return row.name.toLowerCase().includes(q) || 
               row.type.toLowerCase().includes(q) ||
               ((row.vendor || row.desc) && (row.vendor || row.desc).toLowerCase().includes(q));
      }
      return true;
    });
  }, [searchTerm, selectedTypes, licenses]);

  const sortedData = useMemo(() => {
    let sortableItems = [...filteredData];
    if (sortConfig.direction !== null && sortConfig.key) {
      sortableItems.sort((a, b) => {
        let aValue: any = a.name;
        let bValue: any = b.name;
        if (sortConfig.key === 'Name') { aValue = a.name; bValue = b.name; }
        if (sortConfig.key === 'Type') { aValue = a.type; bValue = b.type; }
        if (sortConfig.key === 'Expiry Date') { aValue = a.expiry; bValue = b.expiry; }
        if (sortConfig.key === 'Vendor') { aValue = a.vendor || a.desc || ''; bValue = b.vendor || b.desc || ''; }
        if (sortConfig.key === 'Status') { aValue = a.status || 'Active'; bValue = b.status || 'Active'; }
        if (sortConfig.key === 'Servers') { aValue = a.sv; bValue = b.sv; }

        if (aValue < bValue) return sortConfig.direction === 'asc' ? -1 : 1;
        if (aValue > bValue) return sortConfig.direction === 'asc' ? 1 : -1;
        return 0;
      });
    }
    return sortableItems;
  }, [filteredData, sortConfig]);

  const totalPages = Math.ceil(sortedData.length / rowsPerPage);
  const currentTableData = sortedData.slice((page - 1) * rowsPerPage, page * rowsPerPage);

  const openAddModal = () => {
    setIsAdding(true);
    setSelectedLicense({
      id: Date.now().toString(),
      name: "",
      type: "FlexLM",
      vendor: "",
      sv: 1,
      expiry: "",
      ab: "NN"
    });
    setFormName("");
    setFormTypeChoice("FlexLM");
    setFormTypeCustom("");
    setFormRegion("");
    setFormAliases([]);
    setFormStatus(true);
    setFormSv(1);
    setFormExpiry("");
    setFormOsType("");
    setFormLingerTime("");
    setFormDashboardUrl("");
    setFormVendorChoice(vendorOptions[0] || "");
    setFormVendorCustom("");
    setFormStep(1);
    setIsEditModalOpen(true);
  };

  const openEditModal = (lic: any) => {
    setIsAdding(false);
    setSelectedLicense(lic);
    setFormName(lic.name || "");
    if (typeOptions.includes(lic.type)) {
      setFormTypeChoice(lic.type);
      setFormTypeCustom("");
    } else {
      setFormTypeChoice("Other");
      setFormTypeCustom(lic.type);
    }
    setFormRegion(lic.reg?.[0] || "");
    setFormAliases(lic.aliases || [lic.name]);
    setFormStatus(lic.status !== 'Inactive');
    setFormSv(lic.sv || 1);
    setFormExpiry(lic.expiry || "");
    setFormOsType(lic.osType || "");
    setFormLingerTime(lic.lingerTime ? lic.lingerTime.toString().replace(/\D/g, '') : "");
    setFormDashboardUrl(lic.dashboardUrl || "");
    const vendorVal = lic.vendor || lic.desc || "";
    if (vendorOptions.includes(vendorVal)) {
      setFormVendorChoice(vendorVal);
      setFormVendorCustom("");
    } else {
      setFormVendorChoice("Other");
      setFormVendorCustom(vendorVal);
    }
    setFormStep(1);
    setIsEditModalOpen(true);
  };

  const openDeleteModal = (lic: any) => {
    setSelectedLicense(lic);
    setIsDeleteModalOpen(true);
  };

  const handleDelete = () => {
    if (selectedLicense) {
      ApiClient.deleteLicense(selectedLicense.id)
        .then(() => {
          setLicenses(licenses.filter(l => l.id !== selectedLicense.id));
          toast.success(`License ${selectedLicense.name} deleted successfully`);
          setIsDeleteModalOpen(false);
        })
        .catch((err) => {
          toast.error(err.message || 'Failed to delete license');
        });
    }
  };

  const handleEditSave = (e: import("react").FormEvent) => {
    e.preventDefault();
    if (formStep !== 2) {
      setFormStep(2);
      return;
    }
    if (selectedLicense) {
      const nameVal = formName;
      const aliasesArray = [...formAliases];
      if (aliasesArray.length === 0) {
        aliasesArray.push(nameVal);
      }

      const duplicates: { alias: string; licName: string }[] = [];
      aliasesArray.forEach((newAlias: string) => {
        licenses.forEach(lic => {
          if (lic.id === selectedLicense.id) return;
          const match = (lic.aliases || []).some((alias: string) => alias.toLowerCase() === newAlias.toLowerCase());
          if (match) {
            duplicates.push({ alias: newAlias, licName: lic.name });
          }
        });
      });

      if (duplicates.length > 0) {
        duplicates.forEach(d => {
          toast.error(`Alias "${d.alias}" is taken by license "${d.licName}"`);
        });
        return;
      }

      const formType = formTypeChoice === "Other" ? formTypeCustom.trim() : formTypeChoice;
      const formVendor = formVendorChoice === "Other" ? formVendorCustom.trim() : formVendorChoice;
      const regArray = [formRegion.trim()].filter(Boolean);
      if (regArray.length === 0) regArray.push("Global");
      const updated = {
        ...selectedLicense,
        name: nameVal,
        title: nameVal,
        aliases: aliasesArray,
        ab: nameVal.substring(0, 2).toUpperCase(),
        type: formType,
        expiry: formExpiry,
        vendor: formVendor,
        sv: formSv,
        reg: regArray,
        osType: formOsType || undefined,
        lingerTime: formLingerTime || undefined,
        dashboardUrl: formDashboardUrl || undefined,
        status: formStatus ? 'Active' : 'Inactive',
      };
      
      if (isAdding) {
        ApiClient.createLicense(updated)
          .then((newLicense) => {
            setLicenses([newLicense, ...licenses]);
            toast.success(`License ${newLicense.name} added successfully`);
            setIsEditModalOpen(false);
          })
          .catch((err) => {
            toast.error(err.message || 'Failed to add license');
          });
      } else {
        ApiClient.updateLicense(selectedLicense.id, updated)
          .then((updatedLicense) => {
            setLicenses(licenses.map(l => l.id === selectedLicense.id ? updatedLicense : l));
            toast.success(`License ${updatedLicense.name} updated successfully`);
            setIsEditModalOpen(false);
          })
          .catch((err) => {
            toast.error(err.message || 'Failed to update license');
          });
      }
    }
  };

  const handleExport = () => {
    const headers = ['Name', 'Type', 'Vendor', 'Servers', 'Expiry Date'];
    const csvContent = [
      headers.join(','),
      ...sortedData.map(lic => [
        `"${lic.name}"`,
        `"${lic.type}"`,
        `"${lic.vendor || lic.desc || ''}"`,
        lic.sv,
        `"${lic.expiry}"`
      ].join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', 'licenses_export.csv');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success("Licenses exported successfully");
  };

  return (
    <div className="max-w-[1400px] mx-auto flex flex-col h-full space-y-4">
      {/* Top action row outside card */}
      <div className="flex justify-between items-center">
         <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-zinc-100">License Management</h1>
          <p className="text-sm text-gray-500 dark:text-zinc-400 mt-1">Manage and monitor all application licenses</p>
         </div>
      </div>

      {/* Main Card */}
      <div className="bg-white dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 rounded-xl shadow-sm flex flex-col">
        
        {/* Controls Bar */}
        <div className="p-4 border-b border-gray-200 dark:border-zinc-800 flex flex-col sm:flex-row items-center font-sans">
          <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input 
                type="text" 
                placeholder="Search everywhere..." 
                value={searchTerm}
                onChange={(e) => { setSearchTerm(e.target.value); setPage(1); }}
                className="w-full pl-9 pr-4 py-2 border border-gray-200 dark:border-zinc-700 bg-white dark:bg-zinc-900 rounded-lg text-sm focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none text-gray-900 dark:text-zinc-100 transition-all shadow-sm"
              />
            </div>
            
            {/* TYPE Dropdown */}
            <div className="relative" ref={typeDropdownRef}>
              <button 
                onClick={() => setIsTypeDropdownOpen(!isTypeDropdownOpen)}
                className="inline-flex h-9 items-center justify-center gap-1.5 whitespace-nowrap rounded-lg border border-dashed border-gray-300 dark:border-zinc-700 bg-white dark:bg-zinc-900 px-3 text-sm font-medium text-gray-700 dark:text-zinc-300 transition-colors hover:bg-gray-50 dark:hover:bg-zinc-800 shadow-sm"
              >
                <CirclePlus className="w-4 h-4 text-gray-500" />
                Type
                {selectedTypes.size > 0 && (
                  <>
                    <span className="w-px h-4 bg-gray-300 dark:bg-zinc-700 mx-1"></span>
                    <span className="bg-gray-100 dark:bg-zinc-800 text-gray-900 dark:text-zinc-100 text-xs px-1.5 py-0.5 rounded-sm">
                      {selectedTypes.size}
                    </span>
                  </>
                )}
              </button>

              {isTypeDropdownOpen && (
                <div className="absolute top-full left-0 mt-1 sm:w-56 w-[calc(100vw-2rem)] z-50 bg-white dark:bg-[#111] border border-gray-200 dark:border-zinc-800 rounded-lg shadow-lg overflow-hidden">
                  <div className="p-2 border-b border-gray-100 dark:border-zinc-800">
                    <div className="relative">
                      <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <input 
                        type="text" 
                        placeholder="Type filter..."
                        value={typeSearch}
                        onChange={(e) => setTypeSearch(e.target.value)}
                        className="w-full pl-8 pr-2 py-1.5 text-sm bg-gray-50 dark:bg-zinc-800 border border-gray-200 dark:border-zinc-700 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500 dark:text-zinc-200"
                      />
                    </div>
                  </div>
                  <div className="max-h-[250px] overflow-y-auto p-1">
                    {UNIQUE_TYPES.filter(f => f.toLowerCase().includes(typeSearch.toLowerCase())).map(typeVal => {
                      const isSelected = selectedTypes.has(typeVal);
                      return (
                        <button
                          key={typeVal}
                          onClick={() => toggleTypeFilter(typeVal)}
                          className="w-full flex items-center justify-between px-2 py-1.5 text-sm rounded-md hover:bg-gray-100 dark:hover:bg-zinc-800 text-gray-700 dark:text-zinc-300 transition-colors"
                        >
                          <div className="flex items-center gap-2">
                            <div className={`w-4 h-4 border rounded flex items-center justify-center transition-colors ${isSelected ? 'bg-blue-600 border-blue-600' : 'border-gray-300 dark:border-zinc-600 bg-white dark:bg-zinc-900'}`}>
                              {isSelected && <Check className="w-3 h-3 text-white" />}
                            </div>
                            <span className="text-sm font-normal text-gray-700 dark:text-zinc-300">{typeVal}</span>
                          </div>
                          <span className="text-sm text-blue-600 dark:text-blue-400 font-medium">
                            {TYPE_COUNTS[typeVal] || 0}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                  {selectedTypes.size > 0 && (
                    <div className="p-2 border-t border-gray-100 dark:border-zinc-800 text-center">
                      <button onClick={() => { setSelectedTypes(new Set()); setPage(1); }} className="text-xs text-blue-600 font-medium">
                        Clear filters
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto sm:ml-auto mt-4 sm:mt-0">
            <button onClick={handleExport} className="flex items-center justify-center h-9 gap-1.5 px-4 bg-white dark:bg-zinc-800 hover:bg-gray-50 dark:hover:bg-zinc-700 text-gray-700 dark:text-zinc-300 border border-gray-200 dark:border-zinc-700 rounded-lg text-sm font-medium transition-colors shadow-sm">
              <Download className="w-4 h-4" /> Export
            </button>
            <button onClick={openAddModal} className="flex items-center justify-center h-9 gap-1.5 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-medium transition-colors shadow-sm">
              <Plus className="w-4 h-4" /> Add
            </button>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-gray-700 dark:text-zinc-300 whitespace-nowrap font-sans">
            <thead className="bg-[#f9fafb] dark:bg-zinc-900/50">
              <tr className="border-b border-gray-200 dark:border-zinc-800 transition-colors">
                <th className="px-4 py-3 text-gray-900 dark:text-zinc-100 font-medium w-1/5">
                  <button onClick={() => handleSort('Name')} className="flex items-center gap-2 hover:bg-gray-100 dark:hover:bg-zinc-800 px-2 py-1 -ml-2 rounded-md transition-colors">
                    Name {getSortIcon('Name')}
                  </button>
                </th>
                <th className="px-3 py-3 text-gray-900 dark:text-zinc-100 font-medium">
                  <button onClick={() => handleSort('Type')} className="flex items-center gap-2 hover:bg-gray-100 dark:hover:bg-zinc-800 px-2 py-1 -ml-2 rounded-md transition-colors">
                    Type {getSortIcon('Type')}
                  </button>
                </th>
                 <th className="px-4 py-3 text-gray-900 dark:text-zinc-100 font-medium w-1/3 text-left">
                  <button onClick={() => handleSort('Vendor')} className="flex items-center gap-2 hover:bg-gray-100 dark:hover:bg-zinc-800 px-2 py-1 -ml-2 rounded-md transition-colors">
                    Vendor {getSortIcon('Vendor')}
                  </button>
                </th>
                <th className="px-4 py-3 text-gray-900 dark:text-zinc-100 font-medium w-1/6">
                  <button onClick={() => handleSort('Expiry Date')} className="flex items-center gap-2 hover:bg-gray-100 dark:hover:bg-zinc-800 px-2 py-1 -ml-2 rounded-md transition-colors">
                    Expiry Date {getSortIcon('Expiry Date')}
                  </button>
                </th>
                <th className="px-4 py-3 text-gray-900 dark:text-zinc-100 font-medium text-left">
                  <button onClick={() => handleSort('Status')} className="flex items-center gap-2 hover:bg-gray-100 dark:hover:bg-zinc-800 px-2 py-1 -ml-2 rounded-md transition-colors">
                    Status {getSortIcon('Status')}
                  </button>
                </th>
                <th className="px-4 py-3 font-medium text-right text-gray-900 dark:text-zinc-100 w-24">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-zinc-800/80">
              {currentTableData.map((lic) => {
                return (
                  <tr key={lic.id} className="transition-colors hover:bg-gray-50/50 dark:hover:bg-zinc-800/30 group">
                    <td className="px-4 py-2 align-middle font-medium text-gray-900 dark:text-zinc-100">{lic.name}</td>
                    <td className="px-3 py-2 align-middle">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold tracking-wide border ${getBadgeStyle(lic.type)}`}>
                        {lic.type}
                      </span>
                    </td>
                    <td className="px-4 py-2 align-middle text-sm text-gray-600 dark:text-zinc-400 truncate max-w-sm" title={lic.vendor || lic.desc}>{lic.vendor || lic.desc}</td>
                    <td className="px-4 py-2 align-middle text-sm text-gray-700 dark:text-zinc-300">{lic.expiry || '-'}</td>
                    <td className="px-4 py-2 align-middle">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-semibold border ${lic.status === 'Inactive' ? 'bg-red-100 text-red-700 border-red-200 dark:bg-red-900/30 dark:text-red-400 dark:border-red-800' : 'bg-green-100 text-green-700 border-green-200 dark:bg-green-900/30 dark:text-green-400 dark:border-green-800'}`}>
                        {lic.status === 'Inactive' ? 'Inactive' : 'Active'}
                      </span>
                    </td>
                    <td className="px-4 py-2 align-middle text-right">
                      <div className="flex justify-end gap-1">
                        <button onClick={() => openEditModal(lic)} className="p-1.5 text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded transition-colors" title="Modify">
                          <FileEdit className="w-4 h-4" />
                        </button>
                        <button onClick={() => openDeleteModal(lic)} className="p-1.5 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded transition-colors" title="Delete">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
              {currentTableData.length === 0 && (
                <tr>
                  <td colSpan={10} className="px-4 py-12 text-center text-gray-500 dark:text-zinc-400">
                    No records found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Footer Pagination */}
        <div className="flex flex-col gap-4 px-4 py-4 sm:flex-row sm:items-center sm:justify-between border-t border-gray-200 dark:border-zinc-800 font-sans">
          <div className="flex-1 text-center text-sm text-gray-500 dark:text-zinc-400 sm:text-left">
            <span className="font-medium">Showing {Math.min((page - 1) * rowsPerPage + 1, sortedData.length)} to {Math.min(page * rowsPerPage, sortedData.length)} of {sortedData.length} records</span>
          </div>
          
          <div className="flex flex-col items-center gap-4 sm:flex-row sm:gap-6 lg:gap-8">
            <div className="flex items-center gap-2">
              <p className="text-sm font-medium whitespace-nowrap text-gray-800 dark:text-zinc-300">Rows per page</p>
              <div className="relative">
                <select 
                  value={rowsPerPage} 
                  onChange={(e) => { setRowsPerPage(Number(e.target.value)); setPage(1); }}
                  className="appearance-none h-8 w-[70px] rounded-md border border-gray-200 dark:border-zinc-700 bg-transparent dark:bg-zinc-900 pl-3 pr-8 text-sm shadow-sm transition-colors focus:ring-2 focus:ring-blue-500 outline-none text-gray-900 dark:text-zinc-100"
                >
                  <option value={10}>10</option>
                  <option value={20}>20</option>
                  <option value={50}>50</option>
                </select>
                <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-2">
                  <ChevronDown className="h-4 w-4 text-gray-500" />
                </div>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="text-sm font-medium whitespace-nowrap text-gray-800 dark:text-zinc-300">Page {page} of {Math.max(1, totalPages)}</div>
              <div className="flex items-center gap-1">
                <button 
                  onClick={() => setPage(1)} disabled={page === 1}
                  className="rounded-md border border-gray-200 dark:border-zinc-700 bg-white dark:bg-[#111] text-gray-700 dark:text-zinc-300 hover:bg-gray-100 dark:hover:bg-zinc-800 disabled:opacity-50 disabled:cursor-not-allowed hidden h-8 w-8 lg:flex items-center justify-center transition-colors"
                ><ChevronsLeft className="h-4 w-4" /></button>
                <button 
                  onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}
                  className="rounded-md border border-gray-200 dark:border-zinc-700 bg-white dark:bg-[#111] text-gray-700 dark:text-zinc-300 hover:bg-gray-100 dark:hover:bg-zinc-800 disabled:opacity-50 disabled:cursor-not-allowed flex h-8 w-8 items-center justify-center transition-colors"
                ><ChevronLeft className="h-4 w-4" /></button>
                <button 
                  onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages || totalPages === 0}
                  className="rounded-md border border-gray-200 dark:border-zinc-700 bg-white dark:bg-[#111] text-gray-700 dark:text-zinc-300 hover:bg-gray-100 dark:hover:bg-zinc-800 disabled:opacity-50 disabled:cursor-not-allowed flex h-8 w-8 items-center justify-center transition-colors"
                ><ChevronRight className="h-4 w-4" /></button>
                <button 
                  onClick={() => setPage(totalPages)} disabled={page === totalPages || totalPages === 0}
                  className="rounded-md border border-gray-200 dark:border-zinc-700 bg-white dark:bg-[#111] text-gray-700 dark:text-zinc-300 hover:bg-gray-100 dark:hover:bg-zinc-800 disabled:opacity-50 disabled:cursor-not-allowed hidden h-8 w-8 lg:flex items-center justify-center transition-colors"
                ><ChevronsRight className="h-4 w-4" /></button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Edit / Add Modal — 2-step compact form */}
      {isEditModalOpen && selectedLicense && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="bg-white dark:bg-zinc-900 rounded-xl shadow-xl w-full max-w-md border border-gray-100 dark:border-zinc-800 font-sans flex flex-col" style={{ maxHeight: '90vh' }}>

            {/* ── Header ── */}
            <div className="flex justify-between items-center px-5 py-3.5 border-b border-gray-100 dark:border-zinc-800 shrink-0">
              <div>
                <h3 className="font-semibold text-base text-gray-900 dark:text-zinc-100">
                  {isAdding ? "Add New License" : "Modify License"}
                </h3>
                <p className="text-xs text-gray-400 dark:text-zinc-500 mt-0.5">
                  Step {formStep} of 2 — {formStep === 1 ? 'Basic Info' : 'Advanced Settings'}
                </p>
              </div>
              <button type="button" onClick={() => setIsEditModalOpen(false)} className="text-gray-400 hover:text-gray-600 dark:hover:text-zinc-300 p-1 rounded-lg hover:bg-gray-100 dark:hover:bg-zinc-800 transition-colors">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* ── Step indicator ── */}
            <div className="flex px-5 pt-3 pb-0 gap-2 shrink-0">
              {[1, 2].map(s => (
                <div key={s} className="flex items-center gap-2 flex-1">
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold transition-colors ${
                    formStep === s ? 'bg-blue-600 text-white' :
                    formStep > s ? 'bg-emerald-500 text-white' :
                    'bg-gray-200 dark:bg-zinc-700 text-gray-500 dark:text-zinc-400'
                  }`}>
                    {formStep > s ? <Check className="w-3 h-3" /> : s}
                  </div>
                  <span className={`text-xs font-medium ${
                    formStep === s ? 'text-blue-600 dark:text-blue-400' :
                    formStep > s ? 'text-emerald-600 dark:text-emerald-400' :
                    'text-gray-400 dark:text-zinc-500'
                  }`}>
                    {s === 1 ? 'Basic Info' : 'Advanced'}
                  </span>
                  {s < 2 && <div className={`flex-1 h-0.5 rounded-full ${formStep > s ? 'bg-emerald-400' : 'bg-gray-200 dark:bg-zinc-700'}`} />}
                </div>
              ))}
            </div>

            {/* ── Scrollable form body ── */}
            <form onSubmit={handleEditSave} className="flex flex-col flex-1 min-h-0">
              <div className="overflow-y-auto flex-1 px-5 py-4 space-y-3.5">

                {/* ── STEP 1: Basic Info ── */}
                {formStep === 1 && (
                  <>
                    <div>
                      <label className="block text-xs font-medium text-gray-700 dark:text-zinc-300 mb-1">Name <span className="text-red-500">*</span></label>
                      <input required value={formName} onChange={(e) => setFormName(e.target.value)} className="w-full px-3 py-2 text-sm border border-gray-300 dark:border-zinc-700 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none bg-transparent dark:text-zinc-100" placeholder="e.g. CST" />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-medium text-gray-700 dark:text-zinc-300 mb-1">Type <span className="text-red-500">*</span></label>
                        <select
                          required
                          value={formTypeChoice}
                          onChange={(e) => { setFormTypeChoice(e.target.value); if (e.target.value !== "Other") setFormTypeCustom(""); }}
                          className="w-full px-3 py-2 text-sm border border-gray-300 dark:border-zinc-700 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none bg-transparent dark:text-zinc-100 dark:bg-zinc-900"
                        >
                          {typeOptions.map(t => <option key={t} value={t} className="dark:bg-zinc-950">{t}</option>)}
                          <option value="Other" className="dark:bg-zinc-950">Other…</option>
                        </select>
                        {formTypeChoice === "Other" && (
                          <input required type="text" value={formTypeCustom} onChange={(e) => setFormTypeCustom(e.target.value)} placeholder="Custom type..." className="w-full mt-2 px-3 py-2 text-sm border border-gray-300 dark:border-zinc-700 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none bg-transparent dark:text-zinc-100" />
                        )}
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-gray-700 dark:text-zinc-300 mb-1">Region</label>
                        <input value={formRegion} onChange={(e) => setFormRegion(e.target.value)} placeholder="e.g. India" className="w-full px-3 py-2 text-sm border border-gray-300 dark:border-zinc-700 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none bg-transparent dark:text-zinc-100" />
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <label className="block text-xs font-medium text-gray-700 dark:text-zinc-300">Aliases / Match Keys</label>
                      <div className="flex flex-wrap gap-1.5 p-2 border border-gray-300 dark:border-zinc-700 rounded-lg bg-transparent min-h-[40px] items-center focus-within:ring-2 focus-within:ring-blue-500/20 focus-within:border-blue-500">
                        {formAliases.map((tag, idx) => (
                          <span key={idx} className="inline-flex items-center gap-1 px-2 py-0.5 bg-gray-100 dark:bg-zinc-800 text-gray-700 dark:text-zinc-300 text-xs font-medium rounded-full border border-gray-200 dark:border-zinc-700">
                            {tag}
                            <button type="button" onClick={() => setFormAliases(formAliases.filter((_, i) => i !== idx))} className="hover:bg-gray-200 dark:hover:bg-zinc-700 rounded-full p-0.5">
                              <X className="w-3 h-3 text-gray-500 hover:text-gray-700 dark:text-zinc-400" />
                            </button>
                          </span>
                        ))}
                        <input
                          type="text"
                          placeholder={formAliases.length === 0 ? "Enter alias, press Enter or ," : "Add alias..."}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter' || e.key === ',' || e.key === ';') {
                              e.preventDefault();
                              const val = e.currentTarget.value.trim();
                              if (val && !formAliases.includes(val)) setFormAliases([...formAliases, val]);
                              e.currentTarget.value = '';
                            }
                          }}
                          onBlur={(e) => {
                            const val = e.target.value.trim();
                            if (val && !formAliases.includes(val)) setFormAliases([...formAliases, val]);
                            e.target.value = '';
                          }}
                          className="flex-1 min-w-[100px] bg-transparent text-sm outline-none dark:text-zinc-100 placeholder:text-gray-400 dark:placeholder:text-zinc-500 py-0.5 border-none focus:ring-0"
                        />
                      </div>
                    </div>

                    <div className="flex items-center gap-2 pt-1">
                      <input type="checkbox" id="status-checkbox" checked={formStatus} onChange={(e) => setFormStatus(e.target.checked)} className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500" />
                      <label htmlFor="status-checkbox" className="text-sm font-medium text-gray-700 dark:text-zinc-300 select-none">Active</label>
                    </div>
                  </>
                )}

                {/* ── STEP 2: Advanced Settings ── */}
                {formStep === 2 && (
                  <>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-medium text-gray-700 dark:text-zinc-300 mb-1">Servers (Count) <span className="text-red-500">*</span></label>
                        <input required type="number" min="1" value={formSv} onChange={(e) => setFormSv(parseInt(e.target.value) || 1)} className="w-full px-3 py-2 text-sm border border-gray-300 dark:border-zinc-700 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none bg-transparent dark:text-zinc-100" />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-gray-700 dark:text-zinc-300 mb-1">Expiry Date</label>
                        <input type="date" value={formExpiry} onChange={(e) => setFormExpiry(e.target.value)} className="w-full px-3 py-2 text-sm border border-gray-300 dark:border-zinc-700 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none bg-transparent dark:text-zinc-100" />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-medium text-gray-700 dark:text-zinc-300 mb-1">OS</label>
                        <OSSelect value={formOsType} onChange={setFormOsType} />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-gray-700 dark:text-zinc-300 mb-1">Linger Time (mins)</label>
                        <input type="number" min="0" step="1" onKeyDown={(e) => e.preventDefault()} value={formLingerTime} onChange={(e) => setFormLingerTime(e.target.value.replace(/\D/g, ''))} placeholder="e.g. 10" className="w-full px-3 py-2 text-sm border border-gray-300 dark:border-zinc-700 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none bg-transparent dark:text-zinc-100" />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-gray-700 dark:text-zinc-300 mb-1">Dashboard URL</label>
                      <input type="url" value={formDashboardUrl} onChange={(e) => setFormDashboardUrl(e.target.value)} placeholder="https://..." className="w-full px-3 py-2 text-sm border border-gray-300 dark:border-zinc-700 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none bg-transparent dark:text-zinc-100" />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-gray-700 dark:text-zinc-300 mb-1">Vendor <span className="text-red-500">*</span></label>
                      <select
                        required
                        value={formVendorChoice}
                        onChange={(e) => { setFormVendorChoice(e.target.value); if (e.target.value !== "Other") setFormVendorCustom(""); }}
                        className="w-full px-3 py-2 text-sm border border-gray-300 dark:border-zinc-700 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none bg-transparent dark:text-zinc-100 dark:bg-zinc-900"
                      >
                        {vendorOptions.map(v => <option key={v} value={v} className="dark:bg-zinc-950">{v}</option>)}
                        <option value="Other" className="dark:bg-zinc-950">Other…</option>
                      </select>
                      {formVendorChoice === "Other" && (
                        <input required type="text" value={formVendorCustom} onChange={(e) => setFormVendorCustom(e.target.value)} placeholder="Custom vendor..." className="w-full mt-2 px-3 py-2 text-sm border border-gray-300 dark:border-zinc-700 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none bg-transparent dark:text-zinc-100" />
                      )}
                    </div>
                  </>
                )}
              </div>

              {/* ── Footer buttons — always visible ── */}
              <div className="px-5 py-3 border-t border-gray-100 dark:border-zinc-800 flex justify-between items-center shrink-0 bg-white dark:bg-zinc-900 rounded-b-xl">
                <div>
                  {formStep === 2 && (
                    <button type="button" onClick={() => setFormStep(1)} className="px-3 py-2 text-sm text-gray-600 dark:text-zinc-400 hover:text-gray-900 dark:hover:text-zinc-100 flex items-center gap-1.5 transition-colors">
                      <ChevronLeft className="w-4 h-4" /> Back
                    </button>
                  )}
                </div>
                <div className="flex gap-2">
                  <button type="button" onClick={() => setIsEditModalOpen(false)} className="px-4 py-2 border border-gray-300 dark:border-zinc-700 text-gray-700 dark:text-zinc-300 rounded-lg text-sm font-medium hover:bg-gray-50 dark:hover:bg-zinc-800 transition-colors">
                    Cancel
                  </button>
                  {formStep === 1 ? (
                    <button key="next-btn" type="button" onClick={() => setFormStep(2)} className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors shadow-sm flex items-center gap-1.5">
                      Next <ChevronRight className="w-4 h-4" />
                    </button>
                  ) : (
                    <button key="submit-btn" type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors shadow-sm">
                      {isAdding ? "Save License" : "Update License"}
                    </button>
                  )}
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Modal */}
      {isDeleteModalOpen && selectedLicense && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="bg-white dark:bg-zinc-900 rounded-xl shadow-xl w-full max-w-sm border border-gray-100 dark:border-zinc-800 overflow-hidden font-sans">
             <div className="p-6 text-center">
               <div className="w-12 h-12 rounded-full bg-red-100 dark:bg-red-900/30 text-red-600 flex items-center justify-center mx-auto mb-4">
                 <AlertCircle className="w-6 h-6" />
               </div>
               <h3 className="text-lg font-semibold text-gray-900 dark:text-zinc-100 mb-2">Delete License?</h3>
               <p className="text-sm text-gray-500 dark:text-zinc-400">
                 Are you sure you want to delete <span className="font-semibold text-gray-900 dark:text-zinc-300">{selectedLicense.name}</span>? This action cannot be undone.
               </p>
             </div>
             <div className="bg-gray-50 dark:bg-zinc-800/50 p-4 flex justify-end gap-3 rounded-b-xl border-t border-gray-100 dark:border-zinc-800">
                <button onClick={() => setIsDeleteModalOpen(false)} className="px-4 py-2 bg-white dark:bg-zinc-800 border border-gray-300 dark:border-zinc-700 text-gray-700 dark:text-zinc-300 rounded-lg text-sm font-medium hover:bg-gray-50 dark:hover:bg-zinc-700 transition-colors shadow-sm">
                  Cancel
                </button>
                <button onClick={handleDelete} className="px-4 py-2 bg-red-600 text-white rounded-lg text-sm font-medium hover:bg-red-700 transition-colors shadow-sm">
                  Delete
                </button>
             </div>
          </div>
        </div>
      )}
    </div>
  );
}
