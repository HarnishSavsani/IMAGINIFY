import { Outlet, Link, useLocation, useNavigate } from "react-router-dom";
import { LayoutDashboard, Key, AppWindow, Users, Settings, LogOut, Bell, Search, Menu, Moon, Sun, ChevronsUpDown } from "lucide-react";
import { Logo } from "../../components/Logo";
import { useState, useRef, useEffect } from "react";
import { useTheme } from "../../components/ThemeProvider";
import { StorageService } from "../../utils/storage";

export default function AdminLayout() {
  const location = useLocation();
  const navigate = useNavigate();
  const currentPath = location.pathname;
  const { theme, toggleTheme } = useTheme();
  
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  const cdsid = StorageService.getItem<string>('portal_cdsid', 'User');

  useEffect(() => {
    // Strict auth check on all /admin routes
    const savedCdsid = StorageService.getItem<string>('portal_cdsid');
    if (!savedCdsid || savedCdsid === 'User') {
      navigate('/login');
    } else if (location.pathname === '/admin' || location.pathname === '/admin/') {
      navigate('/admin/dashboard');
    }
  }, [navigate, location.pathname]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsProfileMenuOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const navItems = [
    { name: "Dashboard", path: "/admin/dashboard", icon: LayoutDashboard },
    { name: "Licenses", path: "/admin/licenses", icon: Key },
    { name: "Admins", path: "/admin/admins", icon: Users },
  ];

  return (
    <div className="h-screen overflow-hidden bg-[#f4f4f5] dark:bg-zinc-950 flex font-sans">
      {/* Sidebar */}
      <aside className="w-64 bg-white dark:bg-zinc-900 border-r border-gray-200 dark:border-zinc-800 flex-shrink-0 hidden md:flex flex-col">
        <div className="h-16 flex items-center px-6 border-b border-gray-100 dark:border-zinc-800">
          <Logo className="text-xl" />
        </div>
        
        <div className="p-4 flex-1 overflow-y-auto">
          <div className="text-xs font-semibold text-gray-400 dark:text-zinc-500 uppercase tracking-wider mb-4 px-2">
            Main Menu
          </div>
          <nav className="space-y-1">
            {navItems.map((item) => {
              const isActive = currentPath === item.path;
              const Icon = item.icon;
              return (
                <Link
                  key={item.name}
                  to={item.path}
                  className={`flex items-center gap-3 px-3 py-2 rounded-md transition-colors ${
                    isActive 
                      ? "bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 font-medium" 
                      : "text-gray-600 dark:text-zinc-400 hover:bg-gray-50 dark:hover:bg-zinc-800 hover:text-gray-900 dark:hover:text-zinc-200"
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  {item.name}
                </Link>
              );
            })}
          </nav>
        </div>

        <div className="p-4 border-t border-gray-100 dark:border-zinc-800 relative" ref={menuRef}>
          {isProfileMenuOpen && (
            <div className="absolute bottom-full mb-2 left-4 right-4 bg-white dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 rounded-lg shadow-lg py-1 z-50">
              <button 
                onClick={toggleTheme}
                className="w-full flex items-center gap-3 px-4 py-2 text-sm text-gray-700 dark:text-zinc-300 hover:bg-gray-50 dark:hover:bg-zinc-800 transition-colors"
              >
                {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
                {theme === 'dark' ? 'Light Mode' : 'Dark Mode'}
              </button>
              <button 
                onClick={() => {
                  StorageService.removeItem('portal_cdsid');
                  navigate('/');
                }}
                className="w-full flex items-center gap-3 px-4 py-2 text-sm text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/10 transition-colors text-left"
              >
                <LogOut className="w-4 h-4" />
                Log out
              </button>
            </div>
          )}
          <button 
            onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
            className="w-full flex items-center justify-between gap-3 px-3 py-2 cursor-pointer hover:bg-gray-50 dark:hover:bg-zinc-800 rounded-md transition-colors text-left"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-sm uppercase flex-shrink-0">
                {cdsid.substring(0, 2)}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900 dark:text-zinc-100 truncate">{cdsid}</p>
                <p className="text-xs text-gray-500 dark:text-zinc-400 truncate">{cdsid}@visteon.com</p>
              </div>
            </div>
            <ChevronsUpDown className="w-4 h-4 text-gray-400 flex-shrink-0" />
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Header */}
        <header className="h-16 bg-white dark:bg-zinc-900 border-b border-gray-200 dark:border-zinc-800 flex items-center justify-between px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-4">
            <button className="md:hidden p-2 text-gray-400 hover:text-gray-500">
              <Menu className="w-5 h-5" />
            </button>
            <div className="hidden sm:flex flex-col">
            </div>
          </div>
          <div className="flex items-center gap-3 sm:gap-4">
            <div className="relative hidden md:block">
              <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input 
                type="text" 
                placeholder="Search..." 
                className="pl-9 pr-4 py-2 bg-gray-50 dark:bg-zinc-800 border-none rounded-md text-sm focus:ring-2 focus:ring-blue-500 outline-none w-64 text-gray-900 dark:text-zinc-100 placeholder:text-gray-500"
              />
            </div>
            <button className="relative p-2 text-gray-400 hover:text-gray-500 rounded-full hover:bg-gray-100 dark:hover:bg-zinc-800">
              <Bell className="w-5 h-5" />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border-2 border-white dark:border-zinc-900"></span>
            </button>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
