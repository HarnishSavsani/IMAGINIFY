import { useState, useMemo, useEffect } from 'react';
import { Search, Server, ChevronRight, LayoutList, LayoutGrid, SearchX, X } from 'lucide-react';
import { Link } from 'react-router-dom';
import { ApiClient } from '../lib/api';
import { License } from '../types';

const getBadgeStyle = (type: string) => {
  if (type === 'FlexLM') return "bg-blue-100/50 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400 border-blue-200 dark:border-blue-800";
  if (type === 'RLM') return "bg-emerald-100/50 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800";
  if (type === 'Tasking') return "bg-amber-100/50 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400 border-amber-200 dark:border-amber-800";
  if (type === 'DSLS') return "bg-red-100/50 text-red-700 dark:bg-red-900/30 dark:text-red-400 border-red-200 dark:border-red-800";
  let hash = 0;
  for (let i = 0; i < type.length; i++) {
    hash = type.charCodeAt(i) + ((hash << 5) - hash);
  }
  const i = Math.abs(hash) % 4;
  const classes = [
    "bg-purple-100/50 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400 border-purple-200 dark:border-purple-800",
    "bg-cyan-100/50 text-cyan-700 dark:bg-cyan-900/30 dark:text-cyan-400 border-cyan-200 dark:border-cyan-800",
    "bg-indigo-100/50 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-400 border-indigo-200 dark:border-indigo-800",
    "bg-pink-100/50 text-pink-700 dark:bg-pink-900/30 dark:text-pink-400 border-pink-200 dark:border-pink-800",
  ];
  return classes[i];
};

function formatRegions(regions: string[]) {
  if (!Array.isArray(regions)) return "Global";
  return regions.slice(0, 2).join(", ") + (regions.length > 2 ? ` +${regions.length - 2}` : "");
}

export default function Licenses() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("all");
  const [view, setView] = useState<"list" | "grid">("list");
  const [licenses, setLicenses] = useState<License[]>([]);

  const counts = useMemo(() => {
    const activeLicenses = licenses.filter(l => l.status !== 'Inactive');
    const c: Record<string, number> = { all: activeLicenses.length };
    activeLicenses.forEach(l => {
      c[l.type] = (c[l.type] || 0) + 1;
    });
    return c;
  }, [licenses]);

  const CATS = useMemo(() => {
    const KNOWN_LABELS: Record<string, string> = {
      FlexLM: "FlexLM",
      RLM: "RLM",
      Tasking: "Tasking",
      DSLS: "DSLS (Catia)",
    };

    const activeLicenses = licenses.filter(l => l.status !== 'Inactive');
    const uniqueTypes = Array.from(new Set(activeLicenses.map(l => l.type).filter(Boolean)));
    
    uniqueTypes.sort((a, b) => {
      const countA = counts[a] || 0;
      const countB = counts[b] || 0;
      return countB - countA;
    });

    return [
      { id: "all", label: "All licenses" },
      ...uniqueTypes.map(type => ({
        id: type,
        label: KNOWN_LABELS[type] || type
      }))
    ];
  }, [licenses, counts]);

  useEffect(() => {
    ApiClient.getLicenses()
      .then((data) => {
        if (Array.isArray(data) && data.length > 0) {
          setLicenses(data);
        }
      })
      .catch(() => {
        // Keeps MOCK_LICENSES fallback
      });
  }, []);

  const filtered = useMemo(() => {
    const list = licenses.filter(l => {
      if (l.status && l.status === 'Inactive') return false;
      if (category !== "all" && l.type !== category) return false;
      const s = query.toLowerCase().trim();
      if (!s) return true;
      const regArr = Array.isArray(l.reg) ? l.reg : [];
      return l.name.toLowerCase().includes(s) || 
             l.type.toLowerCase().includes(s) || 
             (l.vendor || '').toLowerCase().includes(s) || 
             regArr.some((r: string) => r.toLowerCase().includes(s));
    });
    return list.sort((a, b) => a.name.localeCompare(b.name));
  }, [query, category, licenses]);



  return (
    <div className="min-h-screen pt-24 pb-12 px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-zinc-50 mb-2">License Explorer</h1>
      </div>
      
      <div className="flex flex-col md:flex-row gap-6">
        {/* Sidebar */}
        <div className="w-full md:w-56 flex-shrink-0">
          <div className="flex flex-row overflow-x-auto md:flex-col gap-2 md:gap-1 bg-white dark:bg-[#111] border border-gray-200 dark:border-zinc-800 p-2 rounded-xl no-scrollbar">
            {CATS.map((c) => (
              <button
                key={c.id}
                onClick={() => setCategory(c.id)}
                className={`flex items-center justify-between px-3 py-2 text-sm rounded-lg transition-colors whitespace-nowrap md:whitespace-normal flex-shrink-0 ${
                  category === c.id
                    ? "bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-400 font-medium"
                    : "text-gray-600 dark:text-zinc-400 hover:bg-gray-50 dark:hover:bg-zinc-800/50"
                }`}
              >
                <span>{c.label}</span>
                <span className={`hidden md:inline-block px-2 py-0.5 rounded-full text-xs font-medium ml-2 ${
                  category === c.id
                    ? "bg-blue-100 dark:bg-blue-900/40 text-blue-700 dark:text-blue-400"
                    : "bg-gray-100 dark:bg-zinc-800 text-gray-500 dark:text-zinc-500"
                }`}>
                  {counts[c.id] || 0}
                </span>
                <span className={`md:hidden px-1.5 py-0.5 rounded-full text-[10px] font-medium ml-1.5 ${
                  category === c.id
                    ? "bg-blue-100 dark:bg-blue-900/40 text-blue-700 dark:text-blue-400"
                    : "bg-gray-100 dark:bg-zinc-800 text-gray-500 dark:text-zinc-500"
                }`}>
                  {counts[c.id] || 0}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 bg-white dark:bg-[#111] border border-gray-200 dark:border-zinc-800 rounded-xl overflow-hidden flex flex-col min-w-0">
          
          {/* Header Bar */}
          <div className="p-4 border-b border-gray-200 dark:border-zinc-800 flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between bg-gray-50/50 dark:bg-zinc-900/20">
            <div className="relative flex-1 w-full max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search licenses..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="w-full pl-9 pr-8 py-2 bg-white dark:bg-zinc-900 border border-gray-200 dark:border-zinc-700 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all dark:text-zinc-100"
              />
              {query && (
                <button 
                  onClick={() => setQuery("")}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-zinc-300"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
            
            <div className="flex items-center bg-gray-100 dark:bg-zinc-800 p-1 rounded-lg border border-gray-200 dark:border-zinc-700">
              <button
                onClick={() => setView("list")}
                className={`p-1.5 rounded-md transition-colors ${
                  view === "list" ? "bg-white dark:bg-zinc-700 text-gray-900 dark:text-zinc-100 shadow-sm" : "text-gray-500 dark:text-zinc-400 hover:text-gray-700 dark:hover:text-zinc-300"
                }`}
              >
                <LayoutList className="w-4 h-4" />
              </button>
              <button
                onClick={() => setView("grid")}
                className={`p-1.5 rounded-md transition-colors ${
                  view === "grid" ? "bg-white dark:bg-zinc-700 text-gray-900 dark:text-zinc-100 shadow-sm" : "text-gray-500 dark:text-zinc-400 hover:text-gray-700 dark:hover:text-zinc-300"
                }`}
              >
                <LayoutGrid className="w-4 h-4" />
              </button>
            </div>
          </div>
          
          {query && (
            <div className="px-4 py-2 text-xs text-gray-500 dark:text-zinc-400 border-b border-gray-100 dark:border-zinc-800/50">
              <span>matching <strong className="font-medium text-gray-700 dark:text-zinc-300">"{query}"</strong></span>
            </div>
          )}

          {/* List/Grid Content */}
          <div className="flex-1 overflow-auto bg-gray-50/30 dark:bg-transparent">
            {filtered.length === 0 ? (
              <div className="flex flex-col items-center justify-center p-12 text-center">
                <SearchX className="w-12 h-12 text-gray-300 dark:text-zinc-600 mb-4" />
                <h3 className="text-sm font-medium text-gray-900 dark:text-zinc-100 mb-1">No licenses found</h3>
                <p className="text-sm text-gray-500 dark:text-zinc-400 mb-4">Try adjusting your search or filter</p>
                <button 
                  onClick={() => { setQuery(""); setCategory("all"); }}
                  className="text-sm text-blue-600 hover:text-blue-700 font-medium"
                >
                  Clear filters
                </button>
              </div>
            ) : view === "list" ? (
              <div className="divide-y divide-gray-100 dark:divide-zinc-800">
                {filtered.map(l => (
                  <Link to={`/licenses/${l.id}`} key={l.id} className="flex items-center gap-4 p-4 hover:bg-gray-50 dark:hover:bg-zinc-800/40 transition-colors cursor-pointer group">
                    <div 
                      className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-medium flex-shrink-0 shadow-sm"
                      style={{ backgroundColor: l.col }}
                    >
                      {l.ab}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium text-sm text-gray-900 dark:text-zinc-100 truncate">{l.name}</span>
                        <span className={`text-[10px] px-2 py-0.5 rounded-full border ${getBadgeStyle(l.type)}`}>
                          {l.type}
                        </span>
                      </div>
                      <div className="text-xs text-gray-500 dark:text-zinc-400 truncate">{l.vendor}</div>
                    </div>
                    <div className="hidden sm:flex items-center gap-4 text-xs text-gray-500 dark:text-zinc-400 shrink-0">
                      <div className="w-8 h-8 rounded-lg border border-gray-200 dark:border-zinc-700 bg-gray-50 dark:bg-zinc-800/50 flex items-center justify-center shrink-0 group-hover:bg-blue-600 group-hover:border-blue-600 group-hover:text-white transition-colors text-gray-400 dark:text-zinc-500">
                        <ChevronRight className="w-4 h-4" />
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 p-4">
                {filtered.map(l => (
                  <Link to={`/licenses/${l.id}`} key={l.id} className="block text-left bg-white dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 rounded-xl p-4 hover:border-blue-300 dark:hover:border-blue-800 hover:shadow-md transition-all cursor-pointer group">
                    <div className="flex items-start justify-between mb-3">
                      <div 
                        className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-medium shadow-sm transition-transform group-hover:scale-105"
                        style={{ backgroundColor: l.col }}
                      >
                        {l.ab}
                      </div>
                      <span className={`text-[10px] px-2 py-0.5 rounded-full border ${getBadgeStyle(l.type)}`}>
                        {l.type}
                      </span>
                    </div>
                    <h3 className="font-medium text-sm text-gray-900 dark:text-zinc-100 mb-1 leading-tight">{l.name}</h3>
                    <p className="text-xs text-gray-500 dark:text-zinc-400 mb-4 h-8 line-clamp-2">{l.vendor}</p>
                    <div className="pt-3 border-t border-gray-100 dark:border-zinc-800 flex items-center justify-end text-[11px] text-gray-500 dark:text-zinc-400 min-h-[36px]">
                      <div className="w-6 h-6 rounded border border-gray-200 dark:border-zinc-700 bg-gray-50 dark:bg-zinc-800/50 flex items-center justify-center shrink-0 group-hover:bg-blue-600 group-hover:border-blue-600 group-hover:text-white transition-colors text-gray-400 dark:text-zinc-500">
                        <ChevronRight className="w-3 h-3" />
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
