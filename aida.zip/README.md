# 🚀 AIDA - AI Assistant for Exchange and Process Insights

## 🌟 Project Overview

AIDA is a full-stack assistant designed to help users query exchange-related operational data using natural language. The system combines a FastAPI backend, a Chainlit frontend, database access, and workflow orchestration to let users ask questions such as:

- 🗓️ “What is the schedule for this process?”
- ⚙️ “What is the current filter/query used?”
- 🗺️ “Show me the field mappings for this project.”
- 🚨 “Show recent failures or defect history.”
- 🔁 “Trigger an exchange process for this project.”

The current application is essentially an AI-powered operations copilot for monitoring and understanding exchange workflows, configurations, and failures.

---

## 🧠 What This Project Does

This project acts like a conversational interface for internal exchange operations. It helps users:

- 💬 Chat with the system in plain English
- 🧠 Understand user intent from natural language
- 🧾 Maintain conversational session context
- 🔎 Resolve missing project/process/oem information through clarification flows
- 📦 Retrieve schedule, config, mapping, and failure data from backend services
- 🔄 Trigger exchange jobs and observe progress through a websocket channel

In short, it is a domain-specific AI assistant for exchange process support and operational visibility.

---

## 🏗️ High-Level Architecture

The project has three major layers:

- 🖥️ Frontend: Chainlit-based chat UI
- ⚙️ Backend: FastAPI REST + WebSocket API
- 🗄️ Data Layer: PostgreSQL and Oracle connectivity for configuration and exchange history

### 🔄 Request Flow

1. 👤 A user sends a message from the Chainlit UI.
2. 🧩 The frontend forwards the message to the FastAPI backend.
3. 🧠 The backend classifies the intent and resolves context.
4. 🗄️ The backend queries the database or external services.
5. 📦 The response is formatted and returned to the UI.
6. 🔁 If needed, the UI can ask for clarification or trigger a process.

---

## ▶️ Run Locally

### Backend

Run this from the backend folder:

```powershell
(.venv) PS C:\Users\2528065\Desktop\aida\backend> uvicorn app.main:app --host 127.0.0.1 --port 8001
```

### Frontend

Run this from the frontend folder:

```powershell
(.venv) PS C:\Users\2528065\Desktop\aida\frontend> chainlit run chainlit_app.py --port 8002
```

If your frontend needs to target a different backend port, set this before starting Chainlit:

```powershell
$env:AIDA_BACKEND_URL = "http://localhost:8001"
```

---

## 📁 Project Structure

```text
AIDA/
├── 📄 requirements.txt
├── 📁 backend/
│   └── 📁 app/
│       ├── 📄 main.py
│       ├── 📁 ai/
│       │   └── 📄 llm_service.py
│       ├── 📁 audit/
│       │   ├── 📄 repository.py
│       │   └── 📄 service.py
│       ├── 📁 config/
│       │   └── 📄 settings.py
│       ├── 📁 db/
│       │   ├── 📄 connection.py
│       │   ├── 📄 oracle_connection.py
│       │   └── 📄 schema.sql
│       ├── 📁 exchange_history/
│       │   ├── 📄 repository.py
│       │   └── 📄 service.py
│       ├── 📁 exchange_trigger/
│       │   ├── 📄 agosense_job_service.py
│       │   ├── 📄 connection_manager.py
│       │   ├── 📄 process_service.py
│       │   ├── 📄 process_store.py
│       │   ├── 📄 repo.py
│       │   ├── 📄 tirgger_models.py
│       │   └── 📄 trigger_service.py
│       ├── 📁 ingestion/
│       │   └── 📄 ingest_config.py
│       │   └── 📄 run_ingest.py
│       ├── 📁 repositories/
│       │   └── 📄 config_repository.py
│       ├── 📁 router/
│       │   ├── 📄 context_resolver.py
│       │   ├── 📄 intent_classifier.py
│       │   └── 📄 query_router.py
│       ├── 📁 semantic/
│       │   ├── 📄 config_selector.py
│       │   ├── 📄 semantic_parser.py
│       │   └── 📄 validator.py
│       ├── 📁 services/
│       │   └── 📄 config_service.py
│       ├── 📁 session/
│       │   ├── 📄 session_repository.py
│       │   └── 📄 session_service.py
│       ├── 📁 utils/
│       │   ├── 📄 cron_utils.py
│       │   ├── 📄 defect_parser.py
│       │   ├── 📄 logger.py
│       │   ├── 📄 response_builder.py
│       │   ├── 📄 time_parser.py
│       │   └── 📄 token_intersection.py
├── 📁 data/
│   └── 📁 programs/
│       ├── 📄 FORD23821.json
│       ├── 📄 FORD29262.json
│       ├── 📄 MS22029826.json
│       ├── 📄 MW60123710.json
│       ├── 📄 SCAN28995.json
│       ├── 📄 TASK30896.json
│       ├── 📄 TATA27883.json
│       └── 📄 W61632023.json
└── 📁 frontend/
    ├── 📄 backend_client.py
    ├── 📄 chainlit_app.py
    ├── 📄 chainlit.md
    ├── 📄 ui_renderer.py
    └── 📁 public/
        └── 📁 elements/
            └── 📄 TriggerForm.jsx
```

---

## 🧩 Backend Module Breakdown

### 📌 [backend/app/main.py](backend/app/main.py)

This is the main FastAPI entrypoint. It exposes the API routes and creates the app instance.

Main responsibilities:

- 🌐 Defines the FastAPI application
- 🩺 Exposes a health endpoint
- 🧾 Creates and manages sessions
- 💬 Handles user queries via `/query`
- 📝 Stores feedback via `/feedback`
- 🔁 Provides trigger-related endpoints
- 📡 Exposes a websocket endpoint for job progress updates

Main routes:

- `GET /health`
- `GET /create-session`
- `POST /query`
- `POST /feedback`
- `GET /trigger-options`
- `POST /trigger`
- `POST /process/start`
- `WebSocket /ws/{job_id}`

---

### 🧠 [backend/app/router/query_router.py](backend/app/router/query_router.py)

This is the core orchestration layer for the backend.

Main responsibilities:

- 🧠 Parses the user’s text query
- 🧭 Resolves missing context like project/process/oem
- 🧩 Classifies the user intent
- 🔄 Executes the right service based on the detected intent
- 📝 Handles clarification flows when the request is ambiguous

Key methods:

- `handle_query(session_id, query)`
- `_execute_intent(intent, context, query, session_id)`

---

### 🧭 [backend/app/router/context_resolver.py](backend/app/router/context_resolver.py)

This module tries to infer missing context from the user query and existing session state.

Main responsibilities:

- 🔎 Detects OEM, project, and process from text
- 🧠 Auto-narrows context when only one project/process is available
- ⚠️ Detects ambiguity and returns clarification requirements

---

### 🏷️ [backend/app/router/intent_classifier.py](backend/app/router/intent_classifier.py)

This module is responsible for determining the intent of a natural language query.

It maps user questions into intents like:

- 📅 schedule query
- ⚙️ config check
- 🗺️ mapping query
- 🧾 defect history query
- 🚨 failure summary
- 🔥 top failure reasons

---

### 🧰 [backend/app/services/config_service.py](backend/app/services/config_service.py)

This is the main service for configuration and mapping-related business logic.

Main responsibilities:

- 🏢 Lists OEMs and projects
- 🛠️ Lists processes for a given project
- 🕒 Fetches schedule information
- ⚙️ Retrieves config values
- 🗺️ Fetches field mappings and value mappings
- 🔍 Searches for configuration keys using lightweight query matching

---

### 🗄️ [backend/app/db/connection.py](backend/app/db/connection.py)

This module creates the PostgreSQL connection for the main application database.

---

### 🧾 [backend/app/db/oracle_connection.py](backend/app/db/oracle_connection.py)

This module is used for Oracle-based exchange history access.

---

### 🧑‍💼 [backend/app/session/session_service.py](backend/app/session/session_service.py)

This module manages conversation state and context across requests.

Main responsibilities:

- 🆕 Create a new session
- 📦 Retrieve existing session state
- 🔄 Update the current project/process/oem context
- 📝 Store the last query and previous responses
- 💬 Support clarification/resume workflows

---

### 📚 [backend/app/exchange_history/service.py](backend/app/exchange_history/service.py)

This module handles exchange failure and defect history queries.

Main responsibilities:

- 🧾 Retrieve defect history
- 🚨 Aggregate failure summaries
- 📈 Analyze top failure reasons
- 📊 Produce health-related summaries

---

### 🔁 [backend/app/exchange_trigger/trigger_service.py](backend/app/exchange_trigger/trigger_service.py)

This module triggers external exchange jobs.

Main responsibilities:

- 🚀 Sends trigger requests to target systems
- 🔍 Monitors the execution state of a job
- 📡 Returns progress updates and final status information

---

### ⚙️ [backend/app/exchange_trigger/process_service.py](backend/app/exchange_trigger/process_service.py)

This is the asynchronous process orchestration layer.

Main responsibilities:

- ▶️ Starts a background process
- 🧵 Tracks execution state
- 📡 Broadcasts progress over websocket channels

---

### 🌐 [backend/app/exchange_trigger/connection_manager.py](backend/app/exchange_trigger/connection_manager.py)

This manages WebSocket subscriptions used for job progress updates.

Main responsibilities:

- 🔌 Accept new websocket connections
- 🔌 Disconnect closed clients
- 📣 Broadcast job state to active listeners

---

### 🧠 [backend/app/ai/llm_service.py](backend/app/ai/llm_service.py)

This module likely provides the LLM-related helpers for meta-intent classification or response transformation.

---

### 🧪 [backend/app/ingestion](backend/app/ingestion)

This folder appears to be related to ingestion/config loading workflows.

---

### 🧱 [backend/app/utils](backend/app/utils)

This folder contains helper utilities for:

- 🕒 cron/schedule parsing
- 🧾 defect ID extraction
- 🪵 logging
- 🧠 token intersection
- 📦 response formatting

---

## 🖥️ Frontend Module Breakdown

### 💬 [frontend/chainlit_app.py](frontend/chainlit_app.py)

This is the main Chainlit entrypoint for the chat experience.

Main responsibilities:

- 🪄 Starts the chat UI
- 💬 Handles incoming messages
- 🔗 Sends user messages to the backend
- 🧭 Displays clarification buttons and quick actions
- 🧾 Formats and renders the backend response in the chat UI

Important handlers:

- `set_starters()`
- `start()`
- `handle_message()`
- `render_clarification_buttons()`
- `render_backend_response()`

---

### 🎨 [frontend/ui_renderer.py](frontend/ui_renderer.py)

This module formats backend response payloads into readable UI content.

It renders different styles of output depending on the response type:

- 📅 schedule responses
- ⚙️ config responses
- 🗺️ mapping responses
- 🚨 failure summaries
- ⚠️ clarification prompts

---

### 🔌 [frontend/backend_client.py](frontend/backend_client.py)

This is a simple helper for calling the backend directly from the frontend context.

---

### 📝 [frontend/chainlit.md](frontend/chainlit.md)

This is the default welcome/landing text shown in the Chainlit app.

---

### 🧩 [frontend/public/elements/TriggerForm.jsx](frontend/public/elements/TriggerForm.jsx)

This component appears to support a trigger form experience for process initiation.

---

## 🗃️ Data and Configuration Notes

The backend uses configuration from environment variables through [backend/app/config/settings.py](backend/app/config/settings.py).

Important environment-driven settings include:

- 🗄️ PostgreSQL database credentials
- 🧾 Oracle DSN / credentials
- 🔐 PROD1 and PROD2 trigger endpoint credentials

The project also uses sample program data located in [data/programs](data/programs).

---

## ▶️ How to Run the Project

### 🐍 Backend

From the repository root:

```powershell
cd backend
.\.venv\Scripts\Activate.ps1
uvicorn app.main:app --host 127.0.0.1 --port 8000
```

If the frontend is configured to call the backend on port 8001, use:

```powershell
uvicorn app.main:app --host 127.0.0.1 --port 8001
```

### 💬 Frontend

From the repository root:

```powershell
cd frontend
.\.venv\Scripts\Activate.ps1
chainlit run chainlit_app.py --port 8001
```

You can also choose another port if needed.

### 🩺 Health Check

Once the backend is running, check:

```text
http://127.0.0.1:8000/health
```

or

```text
http://127.0.0.1:8001/health
```

depending on the port used.

---

## ⚠️ Important Notes

- 🔐 Some endpoint URLs and credentials appear to be placeholders.
- 🌐 The frontend and backend currently show a port mismatch in their configuration, so the port should be aligned carefully.
- 🗄️ The system depends on working database connectivity for most operations.
- 🔄 The process trigger and monitoring features rely on external service endpoints.

---

## 🧭 Current Development Status

This repository appears to be a working prototype / internal tool with:

- ✅ Chat-based query handling
- ✅ Context-aware conversation flow
- ✅ Clarification prompts for ambiguous requests
- ✅ Exchange config and mapping retrieval
- ✅ Failure history and summary support
- ✅ Process triggering and progress monitoring
- ⚠️ Some configuration values still appear to need environment setup

---

## 💡 Suggested Next Improvements

- 🧼 Standardize backend/frontend ports
- 🔐 Move hardcoded credentials to a secure secret store
- 🧪 Add automated tests for router and service logic
- 📚 Document all API endpoints in a formal OpenAPI-style spec
- 🧹 Refactor the trigger workflow into a cleaner background job system
- 📈 Add better logging and monitoring

---

## 🧑‍💻 Developer Summary

If you are a new developer joining the project, the fastest way to understand it is:

1. 🧠 Read [backend/app/main.py](backend/app/main.py)
2. 🧭 Read [backend/app/router/query_router.py](backend/app/router/query_router.py)
3. 🗄️ Read [backend/app/services/config_service.py](backend/app/services/config_service.py)
4. 💬 Read [frontend/chainlit_app.py](frontend/chainlit_app.py)
5. 🎨 Read [frontend/ui_renderer.py](frontend/ui_renderer.py)

These files form the core of the application’s behavior.
