import requests

BACKEND_URL = "http://127.0.0.1:8001/query"

def call_backend(session_id, query):

    payload = {
        "session_id": session_id,
        "query": query
    }

    try:
        response = requests.post(BACKEND_URL, json=payload, timeout=5)
        print("Backend status:", response.status_code)
        print("Backend response:", response.text)

        return response.json()

    except Exception as e:
        print("BACKEND CONNECTION ERROR:", str(e))
        return {"status": "error", "message": str(e)}
