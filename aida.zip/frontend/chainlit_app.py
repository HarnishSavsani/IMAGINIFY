import os
import chainlit as cl
from ui_renderer import render_response
import httpx
import websockets
import asyncio
import json
import requests

BACKEND_URL = os.getenv("AIDA_BACKEND_URL", "http://localhost:8001")
WS_URL = os.getenv("AIDA_WS_URL", "ws://localhost:8001")


async def send_to_backend(session_id: str, query: str):
    async with httpx.AsyncClient(timeout=30.0) as client:
        response = await client.post(
            f"{BACKEND_URL}/query",
            json={
                "session_id": session_id,
                "query": query
            }
        )
        return response.json()

@cl.set_starters
async def set_starters():
    return [
        cl.Starter(
            label="Check Exchange Schedule",
            message="Can you provide me the schedule timings",
            icon="https://img.icons8.com/ios/50/calendar--v1.png",
        ),
        cl.Starter(
            label="Recent Failures",
            message="What are the latest failed items for the last 24 hours?",
            icon="https://img.icons8.com/ios/50/error.png",
        ),
        cl.Starter(
            label="Query Check",
            message="Check the current Filter query used in the process",
            icon="https://img.icons8.com/ios/50/settings.png",
        ),
    ]



@cl.on_chat_start
async def start():
    cl.user_session.set("session_id", None)

    # await cl.Message(
    #     content="🚀 AIDA Console is ready — get quick insights on schedules, queries, mappings, and defect sync history. You can also trigger a new process below.",
    #     actions=[
    #         cl.Action(
    #             name="trigger_process_form", # This matches the @cl.action_callback name!
    #             payload={"action": "start"}, 
    #             label="🚀 Open Trigger Formm"
    #         )
    #     ]
    # ).send()

    # await cl.Message(
    #     content="🚀  AIDA Console is ready — get quick insights on schedules, queries, mappings, and defect sync history."
    # ).send()

    # Re-introducing actions here so they stay visible at the top of the conversation stream!
    await cl.Message(
        content="🚀 **AIDA Console is ready** — get quick insights on schedules, queries, mappings, and defect sync history.",
        actions=[
            cl.Action(name="menu_schedule", payload={}, label="⏱️ Check Schedule"),
            cl.Action(name="menu_failures", payload={}, label="❌ Recent Failures"),
            cl.Action(name="menu_query", payload={}, label="⚙️ Query Check"),
            cl.Action(name="trigger_process_form", payload={"action": "start"}, label="🚀 Open Trigger Form")
        ]
    ).send()





@cl.on_message
async def handle_message(message: cl.Message):

    # Check if user explicitly wants the console panel options back
    if message.content.strip().lower() in ["/menu", "menu", "help"]:
        await cl.Message(
            content="Here are your quick-access console actions:",
            actions=[
                cl.Action(name="menu_schedule", payload={}, label="⏱️ Check Schedule"),
                cl.Action(name="menu_failures", payload={}, label="❌ Recent Failures"),
                cl.Action(name="menu_query", payload={}, label="⚙️ Query Check"),
                cl.Action(name="trigger_process_form", payload={"action": "start"}, label="🚀 Open Trigger Form")
            ]
        ).send()
        return

    session_id = cl.user_session.get("session_id")

    response = await send_to_backend(session_id, message.content)


    if response.get("session_id"):
        cl.user_session.set("session_id", response["session_id"])

    # Handle clarification separately
    if response.get("status") == "clarification_required":
        await render_clarification_buttons(response)
        return

    await render_backend_response(response)


async def render_clarification_buttons(response):

    details = response.get("details", {})
    session_id = response.get("session_id")

    actions = []

    # -----------------------
    # OEM SELECTION
    # -----------------------
    if "oem_required" in details:

        for option in details["oem_required"]:
            label = option.get("name")

            actions.append(
                cl.Action(
                    name="clarification_select",
                    payload={
                        "type": "oem",
                        "value": option.get("name"),
                        "session_id": session_id
                    },
                    label=label
                )
            )

        await cl.Message(
            content="Please select an OEM:",
            actions=actions
        ).send()

        return


    # -----------------------
    # PROJECT SELECTION
    # -----------------------
    if "project_required" in details:

        for option in details["project_required"]:
            label = option.get("project_name") or option.get("project_key")

            actions.append(
                cl.Action(
                    name="clarification_select",
                    payload={
                        "type": "project",
                        "value": option.get("project_key"),
                        "session_id": session_id
                    },
                    label=label
                )
            )

        await cl.Message(
            content="Please select a project:",
            actions=actions
        ).send()

        return

    # -----------------------
    # PROCESS SELECTION
    # -----------------------
    if "process_required" in details:

        for option in details["process_required"]:
            label = option.get("process_name")

            actions.append(
                cl.Action(
                    name="clarification_select",
                    payload={
                        "type": "process",
                        "value": option.get("process_name"),
                        "session_id": session_id
                    },
                    label=label
                )
            )

        await cl.Message(
            content="Please select a process:",
            actions=actions
        ).send()

        return


async def send_with_feedback(content: str):
    await cl.Message(
        content=content,
        actions=[
            cl.Action(name="feedback", payload={"type": "like"}, label="👍"),
            cl.Action(name="feedback", payload={"type": "dislike"}, label="👎"),
        ]
    ).send()

async def render_backend_response(response: dict):

    status = response.get("status")
    intent = response.get("intent")
    data = response.get("data", {})

    # --------------------------------------------------
    # CLARIFICATION
    # --------------------------------------------------
    if status == "clarification_required":
        await render_clarification_buttons(response)
        return

    # --------------------------------------------------
    # SUCCESS
    # --------------------------------------------------
    if status == "success":

        # ==========================
        # SCHEDULE
        # ==========================
        if intent == "schedule_query":

            content = f"""
### ⏱ Exchange Schedule

**Project:** {data.get("project_key")}
**Process:** {data.get("process_name")}

**Cron Expression:**  
`{data.get("cron_expression")}`

**Readable Schedule:**
`{data.get("readable_schedule")}`

**Time Zone**
`{data.get("timezone")}`
"""

            await send_with_feedback(content)
            return

        # ==========================
        # FAILURE SUMMARY
        # ==========================
        if intent == "failure_summary_query":

            failures = data.get("failures", [])
            lines = ["### ❌ Recent Failures\n"]

            for f in failures:
                lines.append(
                    f"• **{f['defect_id']}** | {f['direction']} | {f['message']}"
                )

            await send_with_feedback("\n".join(lines))
            return

        # ==========================
        # CONFIG
        # ==========================
        if intent == "config_check":

            content = f"""
### ⚙ Configuration

**Key:** {data.get("config_key")}
**Value:** `{data.get("value")}`
"""
            await send_with_feedback(content)
            return

        # ==========================
        # FILTER
        # ==========================
        if intent == "filter_query":

            content = f"""
### 🔎 Filter Query

**Key:** {data.get("config_key")}
**Value:** `{data.get("value")}`
"""
            await send_with_feedback(content)
            return

        # ==========================
        # MAPPING
        # ==========================
        if intent in ["mapping_query", "mapping_value_query", "mapping_list_query"]:

            if data.get("field"):
                field_mapping = data.get("results", {})
                project_data = field_mapping.get(data.get('project_key'), {})

                lines = []
                lines.append("### 🔁 Field Mapping\n")
                lines.append(f"**Project:** {data.get('project_key')}")
                
                # Check if we have data for this project
                if project_data:
                    # 1. Iterate through Processes
                    for process_name, scenarios in project_data.items():
                        lines.append(f"\n---\n**Process:** `{process_name}`")
                        
                        # 2. Iterate through Scenarios under this Process
                        for scenario_name, mappings in scenarios.items():
                            lines.append(f"#### 🏷️ Scenario: {scenario_name}")
                            
                            # 3. Create a table for the fields within this Scenario
                            lines.append("| Source Field | Destination Field |")
                            lines.append("| :--- | :--- |")
                            
                            for m in mappings:
                                src = m.get('source_field', 'N/A')
                                dest = m.get('destination_field', 'N/A')
                                lines.append(f"| {src} | {dest} |")
                            
                            lines.append("\n") # Padding between scenarios
            
            elif data.get("values"):
                lines = []
                lines.append("### 🔁 Value Mappings\n")
                grouped_scenarios = data.get("values", {})
                for sn, data in grouped_scenarios.items():
                    lines.append(f"#### 🎬 Scenario: `{sn}`")
                    
                    # We assume the lists are indexed correctly 1:1
                    for sf_name, s_values in data["source_fields"].items():
                        # Get the corresponding destination field (assuming 1:1 field mapping)
                        df_name = list(data["destination_fields"].keys())[0] 
                        d_values = data["destination_fields"][df_name]
                        
                        lines.append(f"**Field Mapping:** {sf_name} ➔ {df_name}")
                        lines.append("| Source Value | Destination Value |")
                        lines.append("| :--- | :--- |")
                        
                        for sv, dv in zip(s_values, d_values):
                            lines.append(f"| {sv} | {dv} |")
                    
                    lines.append("\n---\n") # Padding between scenarios
                
                
            else:
                mappings = data.get("mappings", {})
                lines = []
                lines.append("### 🔁 Field Mappings\n")
                lines.append(f"**Project:** {data.get('project_key')}")
                if(data.get("process_name") is not None):
                    lines.append(f"**Process:** {data.get('process_name')}\n")

                for scenario, items in mappings.items():
                    lines.append(f"#### 🧩 Scenario: {scenario}")
                    for m in items:
                        lines.append(
                            f"- **{m['source_field']}** → `{m['destination_field']}`"
                        )
                    lines.append("")

            await send_with_feedback("\n".join(lines))
            return

        # ==========================
        # EXCHANGE HISTORY
        # ==========================
        if intent == "defect_history_query":

            results = data.get("results", {})

            lines = ["### 🧾 Exchange History\n"]

            for defect_id, defect_data in results.items():
                # Extracting the top-level metadata
                created_date = defect_data.get("Created")
                source_id = defect_data.get("sourceid")
                destination_id = defect_data.get("destinationid")
                history_groups = defect_data.get("history", [])

                lines.append(f"## 🔎 {defect_id}")
                lines.append(f"- **Source ID:** {source_id}")
                lines.append(f"- **Destination ID:** {destination_id}")
                lines.append(f"- **Created On:** {created_date}")
                
                # Iterate through each unique direction group
                for group in history_groups:
                    direction = group.get("direction")
                    latest_status = group.get("latest_status")
                    
                    
                    lines.append(f"\n### Direction: {direction}")
                    lines.append(f"- **Latest Status:** {latest_status}")
                    lines.append(f"- **Latest Timestamp:** {group.get('latest_timestamp', 'N/A')}")
                    if latest_status == "Failed":
                        failed_message = group.get("failed_message", "No error message available.")
                        lines.append(f"- **Failure Reason:** {failed_message}")
                    lines.append("- **Recent History (Top 5):**\n")

                    # Iterate through the raw_data list for this specific direction
                    for record in group.get("raw_data", []):
                        timestamp = record.get("processid")
                        status = record.get("status")
                        fail_msg = record.get("failurereason")
                        
                        # Formatting the individual history line
                        line = f"  • {timestamp} | {status}"
                        if fail_msg:
                            line += f" | Error: {fail_msg}"
                        
                        lines.append(line)

                lines.append("---") # Visual separator between different defect IDs

            await send_with_feedback("\n".join(lines))
            return

        # ==========================
        # TRANSFORMATION (LLM)
        # ==========================
        if intent == "transform_previous":

            await send_with_feedback(str(data.get("result")))
            return
        
        if intent == "ai":
            print("data",data)
            print("data type",type(data))
            await send_with_feedback(str(data))
            return

        # ==========================
        # FALLBACK SUCCESS
        # ==========================
        await send_with_feedback(f"```json\n{data}\n```")
        return

    # --------------------------------------------------
    # NOT FOUND
    # --------------------------------------------------
    if status == "not_found":
        await send_with_feedback(f"⚠ {data.get('message', 'No data found.')}")
        return

    # --------------------------------------------------
    # UNKNOWN INTENT
    # --------------------------------------------------
    if status == "unknown_intent":
        await send_with_feedback(
            "⚠ I couldn't understand your request. Please try rephrasing."
        )
        return

    # --------------------------------------------------
    # ERROR
    # --------------------------------------------------
    if status == "error":
        await send_with_feedback(f"❌ {data.get('message')}")
        return
    

    # --------------------------------------------------
    # FINAL FALLBACK
    # --------------------------------------------------
    await send_with_feedback("⚠ Something unexpected happened.")




@cl.action_callback("clarification_select")
async def handle_clarification_selection(action: cl.Action):

    selection_type = action.payload["type"]
    value = action.payload["value"]
    session_id = action.payload["session_id"]

    if selection_type == "oem":
        query = f"__select_oem__={value}"
    elif selection_type == "project":
        query = f"__select_project__={value}"
    elif selection_type == "process":
        query = f"__select_process__={value}"
    else:
        return

    response = await send_to_backend(session_id, query)

    await render_backend_response(response)



@cl.action_callback("feedback")
async def handle_feedback(action: cl.Action):

    session_id = cl.user_session.get("session_id")
    feedback_type = action.payload["type"]

    async with httpx.AsyncClient() as client:
        await client.post(
            f"{BACKEND_URL}/feedback",
            json={
                "session_id": session_id,
                "feedback": feedback_type
            }
        )

    await cl.Message(
        content="Thanks for your feedback! 🙌"
    ).send()



@cl.action_callback("trigger_process_form")
async def handle_trigger_form(action: cl.Action):
    
    # 1. Fetch dynamic options from the FastAPI backend
    async with httpx.AsyncClient(timeout=10.0) as client:
        try:
            opt_response = await client.get(f"{BACKEND_URL}/trigger-options")
            opt_response.raise_for_status()
            form_options = opt_response.json()
        except Exception as e:
            await cl.Message(content=f"❌ **Failed to load form options:** {str(e)}").send()
            return

    # 2. Define the custom element
    element = cl.CustomElement(
        name="TriggerForm", 
        display="inline",
        props=form_options
    )
    
    # 3. Pop the form into the chat UI
    res = await cl.AskElementMessage(
        content="Please fill the form:",
        element=element,
        timeout=120 
    ).send()
    # Note: Use `.send()` if you aren't awaiting the message creation directly, 
    # but AskElementMessage returns the response when awaited.

    # 4. Handle the submission and STREAM the logs
    if res and res.get("submitted"):
        payload = res.get("data")
        print(f"Submitting payload to backend: {payload}")  # Debugging log

        # Initialize an empty message that we will dynamically type text into
        stream_msg = cl.Message(content="")
        await stream_msg.send()

        # Now, stream the logs from the backend
        response = requests.post(
        f"{BACKEND_URL}/process/start",
        json=payload )

        print(f"Backend response: {response.text}")  # Debugging log

        if response.status_code != 200:
            await cl.Message(
                content=f"Backend Error:\n{response.text}"
            ).send()
            return

        job_id = response.json()["job_id"]

        await cl.Message(
            content=f"Started Job: {job_id}"
        ).send()

        asyncio.create_task(listen(job_id))


            
    else:
        await cl.Message(content="❌ Form cancelled or timed out.").send()



async def listen(job_id):
    message = cl.Message(content="Waiting for job status...")
    await message.send()

    try:
        async with websockets.connect(f"{WS_URL}/ws/{job_id}") as ws:
            async for payload in ws:
                data = json.loads(payload)
                
                message.content = f"""
Job : {job_id}
Status : {data['status']}
Progress : {data['progress']}%
Config Set : {data['configset']}
Process : {data['process']}
"""
                await message.update()

                if data["status"] == "COMPLETED":
                    await cl.Message(content="🎉 Finished").send()
                    break
    except Exception as e:
        message.content = f"❌ **WebSocket Connection Error:** {str(e)}"
        await message.update()



# Attach this button to your chat start or starters as needed
async def prompt_trigger_action():
    await cl.Message(
        content="Ready to trigger a new process?",
        actions=[
            cl.Action(
                name="trigger_process_form", 
                payload={"action": "start"}, 
                label="🚀 Open Trigger Form"
            )
        ]
    ).send()



@cl.action_callback("menu_schedule")
async def handle_menu_schedule(action: cl.Action):
    # Mimic the starter message text and pass it to your backend handler
    msg = cl.Message(content="Can you provide me the schedule timings")
    await handle_message(msg)

@cl.action_callback("menu_failures")
async def handle_menu_failures(action: cl.Action):
    msg = cl.Message(content="What are the recent failures for the last 24 hours?")
    await handle_message(msg)

@cl.action_callback("menu_query")
async def handle_menu_query(action: cl.Action):
    msg = cl.Message(content="Check the current Filter query used in the process")
    await handle_message(msg)