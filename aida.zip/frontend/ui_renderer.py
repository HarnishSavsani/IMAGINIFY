def render_response(data):

    status = data.get("status")

    if status == "success":

        # -------- Schedule --------
        if "schedule" in data:
            return render_schedule(data)

        # -------- Config --------
        if "config_key" in data:
            return render_config(data)

        # -------- Mapping --------
        if "mappings" in data:
            return render_mapping(data)

        # -------- Failures --------
        if "failures" in data:
            return render_failures(data)

        # -------- Health --------
        if "health" in data or "summary" in data:
            return render_summary(data)

        return f"```json\n{data}\n```"

    if status == "clarification_required":
        return render_clarification(data)

    if status == "unknown_intent":
        return "❓ I couldn't understand your request."

    if status == "error":
        return f"❌ {data.get('message')}"

    return f"```json\n{data}\n```"


def render_schedule(data):
        return f"""
    ### 📅 Exchange Schedule

    **Project:** {data.get("project_key")}
    **Process:** {data.get("process_name")}

    ⏱ **Cron:** `{data.get("schedule")}`
    """

def render_config(data):
    return f"""
### ⚙ Configuration

**Project:** {data.get("project_key")}
**Process:** {data.get("process_name")}

🔑 **{data.get("config_key")}**
```{data.get("config_value")}```
"""


def render_mapping(data):
    project = data.get("project")
    process = data.get("process")

    content = f"### 🗺 Field Mappings\n\n**Project:** {project}\n**Process:** {process}\n\n"

    mappings = data.get("mappings", {})

    for scenario, details in mappings.items():
        content += f"\n#### 🔹 {scenario}\n"

        fields = details.get("fields", {})
        for field, info in fields.items():
            destinations = ", ".join(info.get("destinations", []))
            content += f"- **{field}** → {destinations}\n"

    return content


def render_failures(data):
    content = "### 🚨 Exchange Failures\n\n"

    summary = data.get("summary", {})
    content += f"**Total Failures:** {summary.get('total_failures')}\n\n"

    for failure in data.get("failures", []):
        content += f"- `{failure['defect_id']}` | {failure['direction']} | {failure['message']}\n"

    return content

def render_summary(data):
    summary = data.get("summary", {})
    content = "### 📊 Summary\n\n"

    for key, value in summary.items():
        content += f"- **{key.replace('_',' ').title()}**: {value}\n"

    return content

def render_clarification(data):

    content = "### ⚠ Clarification Required\n\n"

    details = data.get("details", {})
    missing = data.get("missing")

    # Case 1: Missing fields
    if missing:
        missing_fields = ", ".join(missing)
        content += f"Please provide: **{missing_fields}**\n"
        return content

    # Case 2: Multiple projects
    if "project_required" in details:
        content += "Multiple projects found:\n\n"

        for idx, project in enumerate(details["project_required"], start=1):
            content += (
                f"{idx}. **{project['project_key']}** – "
                f"{project.get('project_name', '')}\n"
            )

        content += "\nPlease specify which project.\n"
        return content

    # Case 3: Multiple processes
    if "process_required" in details:
        content += "Multiple processes found:\n\n"

        for idx, process in enumerate(details["process_required"], start=1):
            content += (
                f"{idx}. **{process['process_name']}** "
                f"(Schedule: {process.get('schedule', 'N/A')})\n"
            )

        content += "\nPlease specify which process.\n"
        return content

    # Fallback
    content += data.get("message", "More information is required.")
    return content


