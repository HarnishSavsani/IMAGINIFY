import React, { useMemo, useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Label } from "@/components/ui/label";

export default function TriggerForm({
  oems = [],
  projects = [],
  processes = [],
}) {
  const [values, setValues] = useState({
    oemId: "",
    projectId: "",
    process: null,
    defectIds: "",
  });

  const projectsByOem = useMemo(() => {
    const grouped = new Map();
    projects.forEach((project) => {
      const key = project.oem_id?.toString();
      if (!key) return;
      if (!grouped.has(key)) grouped.set(key, []);
      grouped.get(key).push(project);
    });
    return grouped;
  }, [projects]);

  const processesByProject = useMemo(() => {
    const grouped = new Map();
    processes.forEach((process) => {
      const key = process.project_id?.toString();
      if (!key) return;
      if (!grouped.has(key)) grouped.set(key, []);
      grouped.get(key).push(process);
    });
    return grouped;
  }, [processes]);

  const handleChange = (id, val) => {
    setValues((v) => ({ ...v, [id]: val }));
  };

  const handleOemChange = (newOemId) => {
    const filteredProjs = projectsByOem.get(newOemId.toString()) || [];
    const firstProj = filteredProjs[0];
    const firstProjId = firstProj ? firstProj.id.toString() : "";
    const filteredProcs = processesByProject.get(firstProjId) || [];
    const firstProcObj = filteredProcs[0] || null;

    setValues((v) => ({
      ...v,
      oemId: newOemId,
      projectId: firstProjId,
      process: firstProcObj,
    }));
  };

  const handleProjectChange = (newProjectId) => {
    const filteredProcs = processesByProject.get(newProjectId.toString()) || [];
    const firstProcObj = filteredProcs[0] || null;

    setValues((v) => ({
      ...v,
      projectId: newProjectId,
      process: firstProcObj,
    }));
  };

  useEffect(() => {
    if (!oems.length) return;
    if (!values.oemId) {
      handleOemChange(oems[0].id.toString());
      return;
    }

    const selectedOemExists = oems.some(
      (oem) => oem.id.toString() === values.oemId.toString(),
    );
    if (!selectedOemExists) {
      handleOemChange(oems[0].id.toString());
    }
  }, [oems, values.oemId]);

  const availableProjects = useMemo(() => {
    if (!values.oemId) return [];
    return projectsByOem.get(values.oemId.toString()) || [];
  }, [projectsByOem, values.oemId]);

  const availableProcesses = useMemo(() => {
    if (!values.projectId) return [];
    return processesByProject.get(values.projectId.toString()) || [];
  }, [processesByProject, values.projectId]);

  const selectClassName =
    "flex h-10 w-full items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50";
  const textareaClassName =
    "flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50";
  const selectClassName =
    "flex h-10 w-full items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50";
  const textareaClassName =
    "flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50";

  return (
    <Card className="w-full max-w-md mt-4">
      <CardHeader>
        <CardTitle>Trigger Process</CardTitle>
        <CardDescription>
          Select the hierarchy and provide defect IDs to sync.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* 1. OEM DROPDOWN */}
        <div className="space-y-2">
          <Label htmlFor="oemId">OEM</Label>
          <select
            id="oemId"
            className={selectClassName}
            value={values.oemId}
            onChange={(e) => handleOemChange(e.target.value)}
          >
            {oems.map((oem) => (
              <option key={oem.id} value={oem.id}>
                {oem.name}
              </option>
            ))}
          </select>
        </div>

        {/* 2. PROJECT DROPDOWN */}
        <div className="space-y-2">
          <Label htmlFor="projectId">Project</Label>
          <select
            id="projectId"
            className={selectClassName}
            value={values.projectId}
            onChange={(e) => handleProjectChange(e.target.value)}
            disabled={availableProjects.length === 0}
          >
            {availableProjects.length === 0 && (
              <option value="">No projects available</option>
            )}
            {availableProjects.map((proj) => (
              <option key={proj.id} value={proj.id}>
                {proj.project_name}
              </option>
            ))}
          </select>
        </div>

        {/* 3. PROCESS DROPDOWN */}
        <div className="space-y-2">
          <Label htmlFor="processSelect">Process Name</Label>
          <select
            id="processSelect"
            className={selectClassName}
            // Bind select to the unique ID of the process object
            value={values.process?.id || ""}
            onChange={(e) => {
              // Find the full object inside availableProcesses matching the chosen ID string
              const selectedProcessObj = availableProcesses.find(
                (proc) => proc.id.toString() === e.target.value.toString(),
              );
              handleChange("process", selectedProcessObj || null);
            }}
            disabled={availableProcesses.length === 0}
          >
            {availableProcesses.length === 0 && (
              <option value="">No processes available</option>
            )}
            {availableProcesses.map((proc) => (
              <option key={proc.id} value={proc.id}>
                {proc.process_name}
              </option>
            ))}
          </select>
        </div>

        {/* 4. DEFECT IDS (TEXTAREA) */}
        <div className="space-y-2">
          <Label htmlFor="defectIds">Defect IDs (Comma separated)</Label>
          <textarea
            id="defectIds"
            className={textareaClassName}
            placeholder="e.g. DEF-123, DEF-456"
            value={values.defectIds}
            onChange={(e) => handleChange("defectIds", e.target.value)}
          />
        </div>
      </CardContent>
      <CardFooter className="flex justify-end gap-2">
        <Button variant="outline" onClick={() => cancelElement()}>
          Cancel
        </Button>
        <Button
          onClick={() => submitElement({ submitted: true, data: values })}
        >
          Submit
        </Button>
      </CardFooter>
    </Card>
  );
}
