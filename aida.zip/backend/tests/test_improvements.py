import sys
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parents[1]))

from app.router.intent_classifier import IntentClassifier
from app.session.session_service import SessionService


def test_classifier_returns_structured_fallback_payload():
    classifier = IntentClassifier()
    result = classifier.classify("Can you show me the current filter for this process?")

    assert result is not None
    assert result["intent"] == "filter_query"
    assert result["confidence"] >= 0.7
    assert "explanation" in result
    assert "suggested_follow_up" in result


def test_session_service_builds_a_compact_conversation_summary():
    service = SessionService()
    summary = service.build_conversation_summary(
        current_summary=None,
        query="Show me the schedule",
        response={"intent": "schedule_query", "data": {"status": "success"}},
    )

    assert summary is not None
    assert "schedule" in summary.lower()
