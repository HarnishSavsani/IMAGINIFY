import time
from fastapi import FastAPI, Body, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from app.db.connection import get_db_connection
from app.session.session_service import SessionService
from app.exchange_trigger.trigger_service import TriggerService
from app.router.query_router import QueryRouter
from app.utils.logger import setup_logger
from typing import Optional,Union
from app.exchange_trigger.tirgger_models import ProcessRequest
from uuid import uuid4
from app.exchange_trigger.process_service import ProcessService
from app.exchange_trigger.connection_manager import ConnectionManager
from app.ai.llm_service import LLMService




# Instantiate your service
llm_service = LLMService()

manager = ConnectionManager()

process_service = ProcessService(
    manager
)

logger = setup_logger()



session_service = SessionService()
router_instance = QueryRouter()
trigger_service = TriggerService()

app = FastAPI()

origins = [
    "http://localhost:8080",
    "http://127.0.0.1:8080",
    "http://localhost:8001", 
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # Change to `origins` if you want to restrict it later
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def add_request_logging(request, call_next):
    started_at = time.perf_counter()
    try:
        response = await call_next(request)
    except Exception:
        logger.exception("Unhandled request error for %s %s", request.method, request.url.path)
        raise

    elapsed_ms = round((time.perf_counter() - started_at) * 1000, 2)
    logger.info(
        "request_complete method=%s path=%s status=%s duration_ms=%.2f",
        request.method,
        request.url.path,
        response.status_code,
        elapsed_ms,
    )
    return response


@app.exception_handler(Exception)
async def handle_unexpected_error(request, exc):
    logger.exception("Unhandled exception for %s %s", request.method, request.url.path)
    return JSONResponse(
        status_code=500,
        content={"status": "error", "message": "An unexpected error occurred while processing your request."}
    )


@app.get("/health")
def health_check():
    try:
        with get_db_connection() as conn:
            # ... do your db check (e.g., cursor = conn.cursor()) ...
            return {"status": "healthy", "database": "connected"}
    except Exception as e:
        return {"status": "unhealthy", "error": str(e)}


@app.get("/create-session")
def create_session():
    return {"session_id": session_service.create_session()}


@app.post("/query")
def query(
    session_id: Optional[str] = Body(None),
    query: str = Body(...)
):
    # Create session if not provided
    if not session_id:
        session_id = session_service.create_session()

    try:
        result = router_instance.handle_query(session_id, query)
    except Exception:
        logger.exception("Query processing failed for session %s", session_id)
        return {
            "status": "error",
            "message": "I hit an internal error while processing your request.",
            "session_id": session_id,
        }

    # Always return session_id to frontend
    if isinstance(result, dict):
        result["session_id"] = session_id


    ##printing the result and session
    # session_data = session_service.get_session(session_id)
    # print("result from the Query router", result)
    # print("Current session ", session_data)
    
    # if result.get("status") != "clarification_required":
    #     # Call the clean response parser if NO clarification is needed
    #     clean_user_message = llm_service.generate_clean_response(
    #         result, session_data
    #     )
    #     print(clean_user_message)
    #     result["data"] = clean_user_message
    #     result["intent"] = "ai"

    return result



@app.post("/feedback")
def store_feedback(
    session_id: str = Body(...),
    feedback: str = Body(...)
):
    return router_instance.handle_feedback(session_id, feedback)

# Add this above your /trigger endpoint in main.py
# main.py
@app.get("/trigger-options")
def get_trigger_options():
    # Replace these lists with your actual database query results
    processes_list = trigger_service.get_process_list()
    # print("Processes for trigger options:", processes_list)  # Debugging log

    oems = processes_list.get("oems", [])
    projects = processes_list.get("projects", [])
    processes = processes_list.get("processes", [])
    
    

    return {
       "oems": oems,
       "projects": projects,
       "processes": processes
    }

@app.post("/trigger")
def trigger_exchange(
    oemId: str = Body(...),
    projectId: str = Body(...),
    process: dict = Body(...),
    defectIds: Optional[Union[str,list]] = Body(None)
):
    # Debugging logs
    print(f"Received trigger request for oemId: {oemId}, projectId: {projectId}, process: {process}")
    print(f"Defect IDs received: {defectIds}")
    processName = process.get("name") if isinstance(process, dict) else str(process)
    return trigger_service.trigger(oemId, projectId, process, defectIds)



@app.post("/process/start")
async def start_process(
        request: ProcessRequest):

    job_id = str(uuid4())

    await process_service.start_process(
        job_id,
        request.oemId,
        request.projectId,
        request.process,
        request.defectIds
    )

    return {
        "job_id": job_id
    }

@app.websocket("/ws/{job_id}")
async def websocket_endpoint(
        websocket: WebSocket,
        job_id: str):

    await manager.connect(
        job_id,
        websocket
    )

    try:

        while True:
            await websocket.receive_text()

    except WebSocketDisconnect:

        manager.disconnect(
            job_id,
            websocket
        )