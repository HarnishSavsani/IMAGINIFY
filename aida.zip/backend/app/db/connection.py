import os
from contextlib import contextmanager
from psycopg2 import pool
from app.utils.logger import setup_logger

logger = setup_logger()


class PooledConnection:
    """Wrap a pooled psycopg2 connection so close() returns it to the pool."""

    def __init__(self, connection, pool_obj):
        self._connection = connection
        self._pool_obj = pool_obj
        self._closed = False

    def __getattr__(self, name):
        if self._closed:
            raise RuntimeError("Connection has already been released back to the pool.")
        return getattr(self._connection, name)

    def close(self):
        if not self._closed:
            self._pool_obj.putconn(self._connection)
            self._closed = True

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()
        return False


try:
    DB_POOL = pool.ThreadedConnectionPool(
        minconn=1,
        maxconn=20,
        host=os.getenv("DB_HOST", "136.16.208.30"),
        port=os.getenv("DB_PORT", "5432"),
        dbname=os.getenv("DB_NAME", "ai_test_db"),
        user=os.getenv("DB_USER", "app"),
        password=os.getenv("DB_PASSWORD", "agosense")
    )
    logger.info("Database connection pool created successfully.")
except Exception as e:
    logger.error(f"Failed to initialize database connection pool: {e}")
    raise


def get_connection():
    """Return a pooled connection object compatible with existing call sites."""
    connection = DB_POOL.getconn()
    return PooledConnection(connection, DB_POOL)


@contextmanager
def get_db_connection():
    """
    Context manager to acquire a connection from the pool and yield it.
    Ensures the connection is returned to the pool automatically after use.
    """
    conn = get_connection()
    try:
        yield conn
    finally:
        conn.close()