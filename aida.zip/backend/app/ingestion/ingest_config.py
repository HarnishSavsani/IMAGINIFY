import json

def ingest_program(file_path: str, cur):
    """
    Ingests a single JSON file using the provided cursor.
    Note: We do NOT commit or close the cursor here.
    """
    with open(file_path) as f:
        program = json.load(f)

    oem_name = program["oem"].upper()
    project_key = program["project key"]
    project_name = program.get("project name")

    # 1. Insert or fetch OEM
    cur.execute("""
        INSERT INTO oems (name)
        VALUES (%s)
        ON CONFLICT (name) DO UPDATE SET name = EXCLUDED.name
        RETURNING id
    """, (oem_name,))
    oem_id = cur.fetchone()[0]

    # 2. Insert or update Project
    cur.execute("""
        INSERT INTO projects (project_key, project_name, oem_id)
        VALUES (%s, %s, %s)
        ON CONFLICT (project_key)
        DO UPDATE SET project_name = EXCLUDED.project_name, oem_id = EXCLUDED.oem_id
        RETURNING id
    """, (project_key, project_name, oem_id))
    project_id = cur.fetchone()[0]

    # 3. Delete old processes (This is safe within a transaction!)
    cur.execute("DELETE FROM processes WHERE project_id = %s", (project_id,))

    # 4. Process Loop
    for process in program.get("process", []):

        # Fetch values
        proc_name = process.get("process name")
        java_name = process.get("java_process_name")
        config_name = process.get("configset_name")

        # STRICT CHECK: If java_name is None or empty string, raise error
        if not java_name:
            raise ValueError(f"CRITICAL: 'java_process_name' missing in file {file_path} for process {proc_name}")

        if not config_name:
            raise ValueError(f"CRITICAL: 'configset_name' missing in file {file_path} for process {proc_name}")

        cur.execute("""
            INSERT INTO processes (project_id, process_name, schedule, instance, java_process_name, configset_name)
            VALUES (%s, %s, %s, %s, %s, %s)
            RETURNING id
        """, (project_id, process.get("process name"), process.get("schedules"), process.get("instance"), java_name, config_name))

        process_id = cur.fetchone()[0]
        config = process.get("config", {})

        # 5. Batch Insert Config Entries
        config_data = [
            (process_id, k, str(v)) 
            for k, v in config.items() 
            if k != "mappings" and isinstance(v, (str, int, bool))
        ]
        if config_data:
            cur.executemany("""
                INSERT INTO config_entries (process_id, config_key, config_value)
                VALUES (%s, %s, %s)
            """, config_data)

        # 6. Mapping Scenarios
        mappings = config.get("mappings", {})
        for scenario_name, scenario in mappings.items():
            cur.execute("""
                INSERT INTO mapping_scenarios (process_id, scenario_name)
                VALUES (%s, %s) RETURNING id
            """, (process_id, scenario_name))
            scenario_id = cur.fetchone()[0]

            # 7 & 8. Attribute & Value Mappings
            for mapping in scenario.get("Attribute Mapping", []):
                cur.execute("""
                    INSERT INTO attribute_mappings (scenario_id, source_field, destination_field)
                    VALUES (%s, %s, %s) RETURNING id
                """, (scenario_id, mapping.get("source"), mapping.get("destination")))
                attr_id = cur.fetchone()[0]

                val_mapping = mapping.get("Value Mapping", {})
                if isinstance(val_mapping, dict):
                    val_data = [(attr_id, sv, dv) for sv, dv in val_mapping.items() if sv and dv]
                    if val_data:
                        cur.executemany("""
                            INSERT INTO value_mappings (attribute_mapping_id, source_value, destination_value)
                            VALUES (%s, %s, %s)
                        """, val_data)