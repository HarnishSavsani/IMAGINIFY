from app.db.connection import get_db_connection
from . import repository


class AuditService:

    def log_query(self, session_id, query, intent, execution_path, status, processing_time):

        conn = get_db_connection()
        try:
            repository.insert_query_audit(
                conn,
                session_id,
                query,
                intent,
                execution_path,
                status,
                processing_time
            )
        finally:
            conn.close()
