from typing import Optional, Dict, List
from app.db.connection import get_connection
from app.utils.cron_utils import build_schedule_response
from app.utils.token_intersection import tokenize
from app.repositories import config_repository as repo


class ConfigService:

    # --------------------------------------------
    # OEM + Project Lookup
    # --------------------------------------------

    def list_oems(self) -> List[Dict]:
        conn = get_connection()
        try:
            return repo.get_oems(conn)
        finally:
            conn.close()

    def list_projects_by_oem(self, oem_name: str) -> List[Dict]:
        if not oem_name:
            return []
        conn = get_connection()
        try:
            return repo.get_projects_by_oem(conn, oem_name)
        finally:
            conn.close()

    def find_project(self, identifier: str) -> List[Dict]:
        """
        Supports both:
        - Exact key match
        - Fuzzy name match
        """
        conn = get_connection()
        try:
            # Try exact key
            exact = repo.find_project_by_key(conn, identifier)
            if exact:
                return [exact]

            # Try fuzzy name
            return repo.find_project_by_name_fuzzy(conn, identifier)

        finally:
            conn.close()

    # --------------------------------------------
    # Process + Schedule
    # --------------------------------------------

    def list_processes(self, project_key: str) -> List[Dict]:
        conn = get_connection()
        try:
            return repo.get_processes(conn, project_key)
        finally:
            conn.close()

    def get_schedule(self, project_key: str, process_name: str) -> Dict:
        """
        Schedule queries require project + process.
        No aggregation allowed.
        """
        conn = get_connection()
        try:
            schedule = repo.get_schedule(conn, project_key, process_name)
        finally:
            conn.close()

        if not schedule:
            return {
                "status": "not_found",
                "message": "Schedule not found for given project and process."
            }

        return build_schedule_response(
            project_key=project_key,
            process_name=process_name,
            cron_expression=schedule,
            timezone="America/New_York"  # change as needed
        )

    # --------------------------------------------
    # Config Key Lookup
    # --------------------------------------------

    def get_config_value(
        self,
        project_key: str,
        process_name: str,
        config_key: str
    ) -> Dict:

        conn = get_connection()
        try:
            value = repo.get_config_value(
                conn,
                project_key,
                process_name,
                config_key
            )
        finally:
            conn.close()

        if not value:
            return {
                "status": "not_found",
                "message": "Config key not found."
            }

        return {
            "status": "success",
            "project_key": project_key,
            "process_name": process_name,
            "config_key": config_key,
            "value": value
        }

    # --------------------------------------------
    # Mapping Queries (Aggregation Allowed)
    # --------------------------------------------

    def get_field_mappings(
        self,
        field_name: str,
        oem_name: Optional[str] = None,
        project_key: Optional[str] = None,
        process_name: Optional[str] = None
    ) -> Dict:

        conn = get_connection()
        try:
            rows = repo.get_field_mappings(
                conn,
                field_name,
                oem_name=oem_name,
                project_key=project_key
            )
        finally:
            conn.close()

        if not rows:
            return {
                "status": "not_found",
                "message": f"No mappings found for field '{field_name}'."
            }

        # Group by project
        grouped = {}

        for r in rows:
            pk = r["project_key"]
            pn = r["process_name"]
            sn = r["scenario_name"]

            # Navigate/Create the hierarchy: Project -> Process -> Scenario
            project_layer = grouped.setdefault(pk, {})
            process_layer = project_layer.setdefault(pn, {})
            scenario_layer = process_layer.setdefault(sn, [])
            
            # Append the field mapping to the scenario list
            scenario_layer.append({
                "source_field": r["source_field"],
                "destination_field": r["destination_field"]
            })
           

        return {
            "status": "success",
            "project_key": project_key,
            "process_name": None,  # since we allow aggregation across processes
            "field": field_name,
            "results": grouped
        }

    # --------------------------------------------
    # Multi-hop Traversal
    # --------------------------------------------

    def get_multi_hop_mappings(
        self,
        field_name: str,
        oem_name: Optional[str] = None,
        project_key: Optional[str] = None
    ) -> Dict:

        conn = get_connection()
        try:
            rows = repo.get_multi_hop_mappings(
                conn,
                field_name,
                oem_name=oem_name,
                project_key=project_key
            )
        finally:
            conn.close()

        if not rows:
            return {
                "status": "not_found",
                "message": f"No multi-hop mappings found for '{field_name}'."
            }

        grouped = {}

        for r in rows:
            pk = r["project_key"]
            grouped.setdefault(pk, []).append({
                "process_name": r["process_name"],
                "source_field": r["source_field"],
                "destination_field": r["destination_field"]
            })

        return {
            "status": "success",
            "field": field_name,
            "results": grouped
        }
    
    def get_config_keys(self, project_key: str, process_name: str):

        conn = get_connection()
        try:
            return repo.get_config_keys(conn, project_key, process_name)
        finally:
            conn.close()


    def get_all_mapping_fields(self, oem_name: str, project_key: str):

        conn = get_connection()
        try:
            return repo.get_all_mapping_fields(conn, oem_name, project_key)
        finally:
            conn.close()


    def get_oem_by_project(self, project_key: str):

        conn = get_connection()
        try:
            return repo.get_oem_by_project(conn, project_key)
        finally:
            conn.close()

    
    def list_all_projects(self):
        conn = get_connection()
        try:
            return repo.get_all_projects(conn)
        finally:
            conn.close()

    def get_all_mappings(self, project_key: str, process_name: str = None):

        conn = get_connection()
        try:
            rows = repo.get_all_attribute_mappings(conn, project_key, process_name)
        finally:
            conn.close()

        if not rows:
            return {
                "status": "not_found",
                "message": "No mappings found."
            }

        # Group by source_field
        grouped = {}

        for r in rows:
            src = r["source_field"]
            grouped.setdefault(src, []).append({
                "destination_field": r["destination_field"],
                "process_name": r.get("process_name")
            })

        return {
            "status": "success",
            "project_key": project_key,
            "process_name": process_name,
            "details": {
                "fields": grouped
            }
        }


    def get_value_mappings(
        self,
        project_key: str,
        field_name: str,
        process_name: str = None,
        limit: int = 100,
        offset: int = 0
    ):

        conn = get_connection()
        try:
            total = repo.count_value_mappings_for_field(
                conn, project_key, field_name, process_name
            )

            values = repo.get_value_mappings_for_field(
                conn, project_key, field_name, process_name, limit, offset
            )

            # Assuming 'values' contains the raw rows from your DB query
            raw_rows = values  

            grouped_scenarios = {}

            for r in raw_rows:
                sn = r["scenario_name"]
                sf = r["source_field"]
                df = r["destination_field"]
                sv = r["source_value"]
                dv = r["destination_value"]
                
                # Initialize scenario if not present
                if sn not in grouped_scenarios:
                    grouped_scenarios[sn] = {
                        "source_fields": {},
                        "destination_fields": {}
                    }
                
                # Group source values under source field
                if sf not in grouped_scenarios[sn]["source_fields"]:
                    grouped_scenarios[sn]["source_fields"][sf] = []
                grouped_scenarios[sn]["source_fields"][sf].append(sv)
                
                # Group destination values under destination field
                if df not in grouped_scenarios[sn]["destination_fields"]:
                    grouped_scenarios[sn]["destination_fields"][df] = []
                grouped_scenarios[sn]["destination_fields"][df].append(dv)

            # Update your return statement
            return {
                "total": total,
                "limit": limit,
                "offset": offset,
                "values": grouped_scenarios
            }
        finally:
            conn.close()

    
    def get_config_value_by_query(self, project_key: str, process_name: str, query: str):

        config_keys = self.get_config_keys(project_key, process_name)

        if not config_keys:
            return {
                "status": "not_found",
                "message": "No configuration found for given project and process."
            }

        query_lower = query.lower()

        # Basic deterministic scoring
        scored = []

        for key in config_keys:
            score = 0
            key_lower = key.lower()

            # Exact phrase match
            if key_lower in query_lower:
                score += 5

            # Token overlap scoring
            for word in query_lower.split():
                if word in key_lower:
                    score += 1

            if score > 0:
                scored.append((key, score))

        if not scored:
            return {
                "status": "unknown_config",
                "message": "No matching config key found."
            }

        # Pick highest scoring key
        scored.sort(key=lambda x: x[1], reverse=True)
        best_key = scored[0][0]

        return self.get_config_value(
            project_key,
            process_name,
            best_key
        )
    
    def get_mapping_by_query(self, oem_name:str ,project_key: str, process_name: str, query: str):

        query_lower = query.lower()

        # If user asks for all mappings
        if "all" in query_lower or "show mappings" in query_lower:
            return self.get_mapping_summary(project_key, process_name)
        

        # Try field-level match
        fields = self.get_all_mapping_fields(oem_name=oem_name, project_key=project_key)


        best_match = None
        best_score = 0

        
        query_tokens = tokenize(query_lower)

        for field in fields:
            field_tokens = set(field.lower().split())
            score = len(query_tokens & field_tokens)

            if score > best_score:
                best_score = score
                best_match = field


        # If we found a good match
        if best_match and best_score > 0:
            # If user explicitly asked for value mapping
            if "value" in query_lower or "values" in query_lower:
                return self.get_value_mappings(
                    project_key=project_key,
                    field_name=best_match,
                    process_name=process_name
                )

            # Otherwise return FIELD mapping only
            return self.get_field_mappings(
                field_name=best_match,
                project_key=project_key
            )


        # Fallback summary
        return self.get_mapping_summary(project_key, process_name)

    

    def get_filter_query(self, project_key: str, process_name: str):

        config = self.get_full_config(project_key, process_name)

        if not config:
            return {
                "status": "not_found",
                "message": "Config not found."
            }

        # Search for filter-related key
        for key, value in config.items():
            if "filter" in key.lower() or "query" in key.lower():
                return {
                    "status": "success",
                    "project_key": project_key,
                    "process_name": process_name,
                    "config_key": key,
                    "value": value
                }

        return {
            "status": "not_found",
            "message": "No filter or query configured."
        }



    def get_full_config(self, project_key: str, process_name: str):

        conn = get_connection()
        try:
            return repo.get_full_config(conn, project_key, process_name)
        finally:
            conn.close()

    
    def get_mapping_summary(self, project_key: str, process_name: str):

        conn = get_connection()
        try:
            rows = repo.get_all_attribute_mappings(
                conn, project_key, process_name
            )
        finally:
            conn.close()

        if not rows:
            return {
                "status": "not_found",
                "message": "No mappings found."
            }

        grouped = {}

        for r in rows:
            grouped.setdefault(r["scenario_name"], []).append({
                "source_field": r["source_field"],
                "destination_field": r["destination_field"]
            })

        return {
            "status": "success",
            "project_key": project_key,
            "process_name": process_name,
            "mappings": grouped
        }
    
    

