import uuid
from datetime import datetime
from psycopg2.extras import Json


# --------------------------------------------------
# Create Session
# --------------------------------------------------

def create_session(conn) -> str:
    session_id = str(uuid.uuid4())

    cur = conn.cursor()
    cur.execute("""
        INSERT INTO sessions (id, updated_at)
        VALUES (%s, %s);
    """, (session_id, datetime.utcnow()))

    conn.commit()
    cur.close()

    return session_id


# --------------------------------------------------
# Get Session
# --------------------------------------------------

def get_session(conn, session_id: str):

    cur = conn.cursor()
    cur.execute("""
        SELECT oem,
               project_key,
               process_name,
               last_query,
               pending_intent,
               last_response
        FROM sessions
        WHERE id = %s;
    """, (session_id,))

    row = cur.fetchone()
    cur.close()

    if not row:
        return None

    return {
        "oem": row[0],
        "project_key": row[1],
        "process_name": row[2],
        "last_query": row[3],
        "pending_intent": row[4],
        "last_response":row[5]
    }


# --------------------------------------------------
# Update Session
# --------------------------------------------------

def update_session(conn, session_id: str, **kwargs):
    # Filter out keys that weren't provided (or manage an explicit sentinel value)
    # But if you want to allow explicitly setting to None, you can use a default dict structure:
    
    updates = []
    values = []
    
    # Map your method arguments to column names
    fields = ['oem', 'project_key', 'process_name', 'last_query', 'pending_intent']
    
    for field in fields:
        if field in kwargs:
            updates.append(f"{field} = %s")
            values.append(kwargs[field])
            
    if 'last_response' in kwargs:
        updates.append("last_response = %s")
        values.append(Json(kwargs['last_response']) if kwargs['last_response'] else None)
        
    # Always update the timestamp
    updates.append("updated_at = %s")
    values.append(datetime.utcnow())
    
    # Append the session_id for the WHERE clause
    values.append(session_id)
    
    if not updates:
        return # Nothing to update
        
    sql = f"""
        UPDATE sessions
        SET {', '.join(updates)}
        WHERE id = %s;
    """
    
    cur = conn.cursor()
    cur.execute(sql, tuple(values))
    conn.commit()
    cur.close()


# def update_session(conn, session_id: str,
#                    oem=None,
#                    project_key=None,
#                    process_name=None,
#                    last_query=None,
#                    pending_intent=None,
#                    last_response = None):

#     cur = conn.cursor()

#     cur.execute("""
#         UPDATE sessions
#         SET oem = COALESCE(%s, oem),
#             project_key = COALESCE(%s, project_key),
#             process_name = COALESCE(%s, process_name),
#             last_query = COALESCE(%s, last_query),
#             pending_intent = COALESCE(%s, pending_intent),
#             last_response = COALESCE(%s,last_response),
#             updated_at = %s
#         WHERE id = %s;
#     """, (
#         oem,
#         project_key,
#         process_name,
#         last_query,
#         pending_intent,
#         Json(last_response) if last_response else None,
#         datetime.utcnow(),
#         session_id
#     ))

#     conn.commit()
#     cur.close()


def insert_feedback(conn, session_id, query, intent, feedback):

    cur = conn.cursor()

    cur.execute("""
        INSERT INTO response_feedback
        (session_id, query, intent, status, feedback)
        VALUES (%s, %s, %s, %s, %s)
    """, (
        session_id,
        query,
        intent,
        None,
        feedback
    ))

    conn.commit()
    cur.close()

