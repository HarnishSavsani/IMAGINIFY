import re
from app.ai.llm_service import LLMService
from app.utils.defect_parser import extract_defect_ids


class IntentClassifier:

    def __init__(self):
        self.llm = LLMService()

    def classify(self, query: str):
        if not query or not query.strip():
            return None

        query_lower = query.lower().strip()
        defect_ids = extract_defect_ids(query)

        if defect_ids:
            return {
                "intent": "defect_history_query",
                "requires": [],
                "required_context": [],
                "aggregation_allowed": False,
                "confidence": 0.99,
                "explanation": "The query mentions defect identifiers, so it looks like a defect history request.",
                "suggested_follow_up": "Would you like the full defect history or a summary of the latest issues?"
            }

        patterns = [
            (
                r"(top|most\s+common|highest|major)\s+(failure|error|issue|reason)",
                "top_failure_reason_query",
                [],
                True,
                0.95,
                "The wording points to a failure-reason analysis request.",
                "Would you like a short explanation of the main cause?"
            ),
            (
                r"(fail|failure|error|issue|problem|unsync|not\s+sync|health)",
                "failure_summary_query",
                [],
                True,
                0.9,
                "The query references failures or health problems, so it fits a failure summary request.",
                "Would you like a recent failure overview or a trend summary?"
            ),
            (
                r"(schedule|timings|cron|run|execute|execution\s+time|when does it run)",
                "schedule_query",
                ["project", "process"],
                False,
                0.94,
                "The request asks about timing or execution scheduling.",
                "Which project and process should I inspect?"
            ),
            (
                r"(filter\s+query|jql|filter\s+used|query used|filter used)",
                "filter_query",
                ["project", "process"],
                False,
                0.93,
                "The wording requests the active filter or query configuration.",
                "Should I return the current filter definition or the related configuration?"
            ),
            (
                r"\b(map|mapped|mapping|mappings|attribute|field\s+map|field mapping)\b",
                "mapping_value_query",
                ["project", "process"],
                False,
                0.88,
                "The request appears to be about field or value mappings.",
                "Would you like the field mapping or the value mapping view?"
            ),
            (
                r"(which\s+field|field\s+mapped|map\s+field|fields\s+used|attribute)",
                "mapping_query",
                ["project", "process"],
                False,
                0.87,
                "The query is specifically asking for mapping details.",
                "Do you want the mapping summary or a specific field mapping?"
            ),
            (
                r"(enabled|transfer|attachment|comment|creation|sync|config|setting)",
                "config_check",
                ["project", "process"],
                False,
                0.8,
                "The request references configuration or settings.",
                "Which configuration item should I look up?"
            ),
            (
                r"(exist|available|present|does this project|is this project)",
                "project_validation",
                ["project"],
                False,
                0.82,
                "The wording asks whether a project exists or is valid.",
                "Would you like me to confirm the project and its available processes?"
            ),
        ]

        for pattern, intent, requires, aggregation_allowed, confidence, explanation, follow_up in patterns:
            if re.search(pattern, query_lower):
                return {
                    "intent": intent,
                    "requires": requires,
                    "required_context": requires,
                    "aggregation_allowed": aggregation_allowed,
                    "confidence": confidence,
                    "explanation": explanation,
                    "suggested_follow_up": follow_up,
                }

        if any(token in query_lower for token in ["show", "tell", "what", "why", "how"]):
            fallback = self._fallback_with_llm(query)
            if fallback:
                return fallback

            return {
                "intent": "unknown_intent",
                "requires": [],
                "required_context": [],
                "aggregation_allowed": False,
                "confidence": 0.35,
                "explanation": "The request was too vague to classify confidently.",
                "suggested_follow_up": "Could you rephrase your request with a bit more detail?"
            }

        return None

    def _fallback_with_llm(self, query: str):
        try:
            llm_result = self.llm.classify_business_intent(query)
        except Exception:
            return None

        intent = llm_result.get("intent")
        if not intent:
            return None

        return {
            "intent": intent,
            "requires": llm_result.get("required_context", []),
            "required_context": llm_result.get("required_context", []),
            "aggregation_allowed": intent in {"failure_summary_query", "top_failure_reason_query"},
            "confidence": max(float(llm_result.get("confidence", 0.0)), 0.4),
            "explanation": llm_result.get("explanation", ""),
            "suggested_follow_up": llm_result.get("suggested_follow_up", "")
        }
