import re
from typing import Dict, Optional
from app.services.config_service import ConfigService
from app.session.session_service import SessionService


class ContextResolver:

    def __init__(self):
        self.config_service = ConfigService()
        self.session_service = SessionService()

    # -------------------------------------------------
    # Main Resolver Entry
    # -------------------------------------------------

    def resolve(self, session_id: str, query: str) -> Dict:

        print("Resolving context for session:", session_id)

        session = self.session_service.get_session(session_id)
        print("Fetching session data in resolver:", session)
        
        if not session:
            return {"error": "Invalid session."}

        # Step 1: Detect entities from query
        detected_oem = self._detect_oem(query)
        detected_project = self._detect_project(query)
        detected_process = self._detect_process(query, session)

        # -------------------------------------------------
        # IMPORTANT FIX:
        # If project detected → override OEM from DB
        # Project always dominates OEM
        # -------------------------------------------------
        if detected_project:
            oem_for_project = self.config_service.get_oem_by_project(detected_project)
            if oem_for_project:
                detected_oem = oem_for_project

        # Step 2: Update session context using policy rules
        updated_context = self.session_service.update_context(
            session_id,
            new_oem=detected_oem,
            new_project=detected_project,
            new_process=detected_process
        )


        # -------------------------------------------------
        # AUTO-NARROWING LOGIC (ADD HERE)
        # -------------------------------------------------


        auto_project = None
        auto_process = None

        # Auto resolve project if OEM has only one project
        if updated_context.get("oem") and not updated_context.get("project_key"):
            projects = self.config_service.list_projects_by_oem(updated_context["oem"])
            if len(projects) == 1:
                auto_project = projects[0]["project_key"]

        # Auto resolve process if project has only one process
        project_for_process = updated_context.get("project_key") or auto_project

        if project_for_process and not updated_context.get("process_name"):
            processes = self.config_service.list_processes(project_for_process)
            if len(processes) == 1:
                auto_process = processes[0]["process_name"]

        # Persist auto-narrowed values to session
        if auto_project is not None or auto_process is not None:
            updated_context = self.session_service.update_context(
                session_id,
                new_project=auto_project,
                new_process=auto_process
            )


        # Step 3: Check ambiguity after narrowing
        ambiguity = self._check_ambiguity(updated_context)


        return {
            "context": updated_context,
            "ambiguity": ambiguity
        }

    # -------------------------------------------------
    # OEM Detection
    # -------------------------------------------------

    def _detect_oem(self, query: str) -> Optional[str]:

        oems = self.config_service.list_oems()
        query_upper = query.upper()

        for oem in oems:
            oem_name = oem["name"].upper()

            # Match full name OR first token
            if oem_name in query_upper:
                return oem["name"]

            first_token = oem_name.split()[0]
            if first_token in query_upper:
                return oem["name"]

        return None



    # -------------------------------------------------
    # Project Detection
    # -------------------------------------------------

    def _detect_project(self, query: str) -> Optional[str]:

        all_projects = self.config_service.list_all_projects()
        query_upper = query.upper()

        # 1️⃣ Exact project key match
        for project in all_projects:
            if project["project_key"].upper() in query_upper:
                return project["project_key"]

        # 2️⃣ Controlled fuzzy match using full project name
        matches = []
        for project in all_projects:
            if project["project_name"] and project["project_name"].upper() in query_upper:
                matches.append(project)

        if len(matches) == 1:
            return matches[0]["project_key"]

        return None



    # -------------------------------------------------
    # Process Detection
    # -------------------------------------------------

    def _detect_process(self, query: str, session: Dict) -> Optional[str]:

        # If project explicitly mentioned in same query,
        # process detection should happen after session update.
        # So we check project from session.
        project_key = session.get("project_key")
        if not project_key:
            return None

        processes = self.config_service.list_processes(project_key)
        query_lower = query.lower()

        # 1️⃣ Direct process name match
        for p in processes:
            if p["process_name"].lower() in query_lower:
                return p["process_name"]

        # 2️⃣ Direction detection (e.g., "ford to visteon")
        direction_match = re.search(r"(\w+)\s+to\s+(\w+)", query_lower)

        if direction_match:
            src = direction_match.group(1)
            dest = direction_match.group(2)
            normalized = f"{src}2{dest}"

            for p in processes:
                if normalized in p["process_name"].lower():
                    return p["process_name"]

        return None

    # -------------------------------------------------
    # Ambiguity Check
    # -------------------------------------------------

    def _check_ambiguity(self, context: Dict) -> Dict:

        oem = context.get("oem")
        project = context.get("project_key")
        process = context.get("process_name")

        result = {}

        # If OEM set but project missing → check if multiple projects exist
        if oem and not project:
            projects = self.config_service.list_projects_by_oem(oem)
            if len(projects) > 1:
                result["project_required"] = projects

        # If project set but process missing → check if multiple processes exist
        if project and not process:
            processes = self.config_service.list_processes(project)
            if len(processes) > 1:
                result["process_required"] = processes

        return result
