import json
import os
import re
from typing import Dict
import requests


class LLMService:

    def __init__(self):
        self.base_url = os.getenv("OLLAMA_BASE_URL", "http://127.0.0.1:11434/api/chat")
        self.model = os.getenv("OLLAMA_MODEL", "qwen2.5:7b")
        self.timeout = int(os.getenv("OLLAMA_TIMEOUT", "60"))
        self.fallback_model = os.getenv("OLLAMA_FALLBACK_MODEL", "qwen2.5:3b")

    # ======================================================
    # SAFE LLM CALL
    # ======================================================

    def _call(self, prompt: str, system_message: str = "You are a JSON-only assistant.") -> str:
        for model_name in [self.model, self.fallback_model]:
            if not model_name:
                continue
            try:
                response = requests.post(
                    self.base_url,
                    json={
                        "model": model_name,
                        "stream": False,
                        "messages": [
                            {"role": "system", "content": system_message},
                            {"role": "user", "content": prompt}
                        ],
                        "options": {
                            "temperature": 0.3,
                            "presence_penalty": 1.2
                        }
                    },
                    timeout=self.timeout
                )

                if response.status_code != 200:
                    print(f"[LLMService Warning] Model {model_name} returned status {response.status_code}: {response.text}")
                    continue

                data = response.json()
                content = data.get("message", {}).get("content", "")
                content = re.sub(r"<think>.*?</think>", "", content, flags=re.DOTALL)
                return content.strip()

            except requests.exceptions.Timeout:
                print(f"[LLMService Warning] Model {model_name} timed out.")
                continue
            except Exception as exc:
                print(f"[LLMService Warning] Model {model_name} failed: {exc}")
                continue

        return ""

    # ======================================================
    # BUSINESS INTENT CLASSIFICATION (HYBRID FALLBACK)
    # ======================================================

    def classify_business_intent(self, query: str) -> Dict:
        prompt = f"""
You are a routing classifier for an exchange operations assistant.

Return ONLY valid JSON.

Possible intents:
- schedule_query
- config_check
- filter_query
- mapping_query
- mapping_value_query
- defect_history_query
- failure_summary_query
- top_failure_reason_query
- project_validation
- unknown_intent

Rules:
- Use schedule_query for questions about timing, cron, run schedule, or execution windows.
- Use config_check for questions about settings, configuration values, or specific parameters.
- Use filter_query for questions about the active filter or query used.
- Use mapping_query for field mapping questions; use mapping_value_query if the user asks about value mappings.
- Use defect_history_query for defect IDs or defect history requests.
- Use failure_summary_query for recent failures, errors, or health issues.
- Use top_failure_reason_query for questions asking for the most common reasons or top issues.
- Use project_validation for questions asking whether a project exists or is valid.
- If the request is unclear, return unknown_intent.

Return format:
{{
  "intent": "<intent_name>",
  "confidence": 0.0-1.0,
  "required_context": ["project", "process"],
  "explanation": "short reason",
  "suggested_follow_up": "short follow-up question"
}}

Query:
"{query}"
"""
        raw = self._call(prompt)

        if not raw:
            return {
                "intent": "unknown_intent",
                "confidence": 0.0,
                "required_context": [],
                "explanation": "No LLM fallback response was available.",
                "suggested_follow_up": "Could you rephrase your request?"
            }

        try:
            parsed = json.loads(raw)
            return {
                "intent": parsed.get("intent", "unknown_intent"),
                "confidence": float(parsed.get("confidence", 0.0)),
                "required_context": parsed.get("required_context", []),
                "explanation": parsed.get("explanation", ""),
                "suggested_follow_up": parsed.get("suggested_follow_up", "")
            }
        except Exception:
            return {
                "intent": "unknown_intent",
                "confidence": 0.0,
                "required_context": [],
                "explanation": "The fallback classifier returned an invalid response.",
                "suggested_follow_up": "Could you rephrase your request?"
            }

    # ======================================================
    # META INTENT CLASSIFICATION
    # ======================================================

    def classify_meta_intent(self, query: str) -> Dict:
        prompt = f"""
You are a routing classifier.

Return ONLY valid JSON.

Possible intents:
- transform_previous
- explain_previous
- summarize_previous
- none

Rules:
- If user refers to "above result", "previous result", "convert", "timezone",
  "explain this", "summarize this", choose appropriate meta intent.
- If user asks new business query like schedule, mapping, filter, config,
  choose "none".
- Never invent new intent names.

Return format:
{{
  "intent": "<intent_name>",
  "confidence": 0.0-1.0
}}

Query:
"{query}"
"""
        # This will safely default to the JSON system assistant prompt
        raw = self._call(prompt)

        if not raw:
            return {"intent": "none", "confidence": 0}

        try:
            parsed = json.loads(raw)
            return {
                "intent": parsed.get("intent", "none"),
                "confidence": float(parsed.get("confidence", 0)),
            }
        except Exception:
            return {"intent": "none", "confidence": 0}

    # ======================================================
    # TRANSFORM PREVIOUS RESULT
    # ======================================================

    def transform_previous(self, previous_data: dict, user_query: str) -> str:
        prompt = f"""
You are an enterprise data assistant.

User request:
"{user_query}"

Previous structured result:
{json.dumps(previous_data, indent=2)}

Perform the requested transformation.

Rules:
- Do not invent fields.
- If converting timezone, convert properly.
- If summarizing, summarize clearly.
- If explaining, explain clearly.
- Return plain text only (no JSON).
"""
        result = self._call(prompt)
        return result if result else "Unable to transform previous result."

    # ======================================================
    # NEW METHOD: PARSE BACKEND DATA AND RETURN CLEAN USER TEXT
    # ======================================================

    def generate_clean_response(
        self, router_result: dict, current_session: dict
    ) -> str:
        """Validates the backend response, checks for unknown intents,

        and builds a human-readable message free of backend jargon.
        """

        # 1. Define the System Rules
        system_rules = """
You are a helpful, professional assistant for a Jira sync tool. Your job is to translate raw backend data into clear, human-readable answers for the user based on their last query.

### Critical Rule 1: No Backend Jargon
Never expose technical backend terminology to the user. Do NOT use words like:
- "intent"
- "session" / "session_id"
- "backend" / "router" / "payload"
- "status" / "success" / "failure"
- "config_key" or "process_name"

### Critical Rule 2: Output Format
- Do NOT return JSON format, curly braces {}, or key-value schemas.
- Return ONLY plain, conversational English sentences answering the user's question directly.

### Processing Guidelines:
1. Validate Data: Check if the response 'status' is 'success'. If the data is missing or indicates an error, politely inform the user that the request could not be processed right now.
2. Formulate the Answer: Look at the user's 'last_query' and use the available data fields to answer it directly. 
3. Fallback Logic (Unrecognized Requests):
   - If the request type or intent is unrecognized (like 'unknown_intent'), look through all available data fields in the history provided to see if the answer is hidden there anyway. If you find it, answer the user naturally.
   - If the information cannot be found anywhere in the provided data, politely inform the user that you don't have that information and ask them to rephrase or reformat their message.

### Tone:
Concise, user-friendly, and completely non-technical. Return plain conversational text only.
"""

        # 2. Package your data into a clear context frame
        context_data = {
            "query_router_output": router_result,
            "current_session_state": current_session,
        }

        user_prompt = f"""
Here is the current operational data:
{json.dumps(context_data, indent=2)}

Based on the 'last_query' provided within the data, formulate the final user-facing response following your system rules.
"""

        # 3. Call your internal endpoint with the custom instructions
        result = self._call(prompt=user_prompt, system_message=system_rules)

        if not result:
            return "I'm sorry, I'm having trouble processing that information right now. Please try again."

        return result