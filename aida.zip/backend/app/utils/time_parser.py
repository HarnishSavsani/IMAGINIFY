from datetime import datetime, timedelta

def extract_time_range(query: str):

    query_lower = query.lower()
    now = datetime.now()

    if "today" in query_lower:
        start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        end = now
        return start, end

    if "last 7 days" in query_lower:
        start = now - timedelta(days=7)
        return start, now

    if "this week" in query_lower:
        start = now - timedelta(days=now.weekday())
        start = start.replace(hour=0, minute=0, second=0, microsecond=0)
        return start, now

    return None, None



def extract_date_from_process_id(process_id: str):
    """
    Extracts date from format YYMMDD... into DD-MM-YYYY.
    Example: '260323061522_STARCtoJira' -> '23-03-2026'
    """
    if not process_id or len(process_id) < 6:
        return "N/A"

    # Slicing the first 6 characters
    yy = process_id[0:2]
    mm = process_id[2:4]
    dd = process_id[4:6]

    # Returning formatted string
    return f"{dd}-{mm}-20{yy}"