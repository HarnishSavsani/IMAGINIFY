def build_response(
    status: str,
    intent: str,
    execution_path: str,
    data: dict = None,
    filters_applied: dict = None,
    message: str = None
):
    return {
        "status": status,
        "intent": intent,
        "execution_path": execution_path,
        "filters_applied": filters_applied or {},
        "message": message,
        "data": data or {}
    }
