from datetime import datetime
from typing import List, Dict
from cron_descriptor import get_description
from croniter import croniter
import pytz


DEFAULT_TIMEZONE = "UTC"


def cron_to_readable(cron_expression: str) -> str:
    """
    Convert cron expression into readable English format.
    """
    try:
        return get_description(cron_expression)
    except Exception:
        return "Invalid cron expression"


def get_next_run_times(
    cron_expression: str,
    count: int = 3,
    timezone: str = DEFAULT_TIMEZONE
) -> List[str]:
    """
    Returns next N run times in readable format.
    """

    try:
        tz = pytz.timezone(timezone)
    except Exception:
        tz = pytz.timezone(DEFAULT_TIMEZONE)

    try:
        now = datetime.now(tz)
        iterator = croniter(cron_expression, now)

        runs = []
        for _ in range(count):
            next_run = iterator.get_next(datetime)
            runs.append(next_run.strftime("%Y-%m-%d %H:%M:%S %Z"))

        return runs

    except Exception:
        return []


def build_schedule_response(
    project_key: str,
    process_name: str,
    cron_expression: str,
    timezone: str = DEFAULT_TIMEZONE
) -> Dict:
    """
    Unified structured schedule response.
    """

    return {
        "status": "success",
        "project_key": project_key,
        "process_name": process_name,
        "cron_expression": cron_expression,
        "readable_schedule": cron_to_readable(cron_expression),
        "timezone": timezone,
        "next_runs": get_next_run_times(
            cron_expression,
            count=3,
            timezone=timezone
        )
    }