
STOP_WORDS = {
    "the", "is", "are", "was", "were", "with", "what",
    "a", "an", "of", "to", "in", "on", "for", "and",
    "or", "this", "that", "these", "those"
}

def tokenize(text):
    return set(
        word.lower() for word in text.split()
        if word.lower() not in STOP_WORDS
    )
