import asyncio

from app.exchange_trigger.process_store import jobs

from app.exchange_trigger.agosense_job_service import trigger_process, monitor_job_progress
from app.config.settings import PROD1_CONFIG, PROD2_CONFIG


class ProcessService:

    def __init__(self, manager):
        self.manager = manager
        self.username = "your_username"
        self.password = "your_password"
        self.trigger_url = "https://your-internal-endpoint:8443/api/trigger"
        self.monitor_url = "https://your-internal-endpoint:8443/api/monitor"
        self.config_set = "your_default_config_set"

    async def start_process(
            self,
            job_id,
            oemId,
            projectId,
            process,
            defectIds):

        
        if process is None:
            raise ValueError("Process cannot be None")
        

        if process.get("instance") == "PROD1":
            print("Starting process for PROD1 environment")
            self.config_set = process.get("configset_name")  
            self.trigger_url = PROD1_CONFIG["trigger_url"]
            self.monitor_url = PROD1_CONFIG["monitor_url"]
            self.username = PROD1_CONFIG["username"]
            self.password = PROD1_CONFIG["password"]
        elif process.get("instance") == "PROD2":
            print("Starting process for PROD2 environment")
            self.config_set = process.get("configset_name")  
            self.trigger_url = PROD2_CONFIG["trigger_url"]
            self.monitor_url = PROD2_CONFIG["monitor_url"]
            self.username = PROD2_CONFIG["username"]
            self.password = PROD2_CONFIG["password"]

        trigger_response = trigger_process(
            job_id,
            process.get('java_process_name'),
            self.config_set,
            self.username,
            self.password,
            self.trigger_url
        )

        if trigger_response != 200:
            raise ValueError("Failed to trigger process")

        jobs[job_id] = {
            "status": "STARTED",
            "progress": 0,
            "job_id": job_id,
            "configset": self.config_set,
            "process": process
        }

        await asyncio.sleep(10) 

        asyncio.create_task(
            self.monitor_process(
                job_id,
                self.config_set,
                process
            )
        )

    async def monitor_process(
            self,
            job_id,
            configset,
            process):

        # execution = await start_external_process(
        #     configset,
        #     process
        # )

        # execution_id = execution[
        #     "execution_id"
        # ]

        progress = 0

        while True:

            # status_response = (
            #     await get_process_status(
            #         execution_id,
            #         progress
            #     )
            # )

            status_response = await monitor_job_progress(
                job_id,
                self.monitor_url,
                self.username,
                self.password
            )

            progress = (
                status_response["progress"]
            )

            print(f"Status Reponse Object: {status_response}")

            jobs[job_id] = {
                "job_id": job_id,
                "status":
                    status_response["status"],
                "progress": progress,
                "total": status_response["total"],
                "succeeded": status_response["succeeded"],
                "failed": status_response["failed"],
                "configset": configset,
                "process": process
            }

            await self.manager.broadcast(
                job_id,
                jobs[job_id]
            )

            if (
                status_response["status"]
                == "COMPLETED"
            ):
                break

            await asyncio.sleep(5)