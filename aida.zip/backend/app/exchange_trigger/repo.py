

def get_processes_list(conn):
    cur = conn.cursor()
    cur.execute("""
        SELECT id, name
        FROM oems;
    """)

    oems = cur.fetchall()

    cur.execute("""
        SELECT id, oem_id, project_key, project_name
        FROM projects;
    """)
    projects = cur.fetchall()

    cur.execute("""
        SELECT id, project_id, process_name, java_process_name, configset_name, instance
        FROM processes;
    """)
    processes = cur.fetchall()
    cur.close()

    return {
        "oems": [{"id": row[0], "name": row[1]} for row in oems],
        "projects": [{"id": row[0], "oem_id": row[1], 
                    "project_key": row[2], "project_name": row[3]} 
                            for row in projects],
        "processes": [{"id": row[0], "project_id": row[1], "process_name": row[2], 
                            "java_process_name": row[3], "configset_name": row[4], "instance": row[5]}
                                     for row in processes]
    }