from typing import List, Dict, Optional


# ---------------------------------------------------
# OEM Queries
# ---------------------------------------------------

def get_oems(conn) -> List[Dict]:
    cur = conn.cursor()
    cur.execute("""
        SELECT id, name
        FROM oems
        ORDER BY name;
    """)
    rows = cur.fetchall()
    cur.close()

    return [{"id": r[0], "name": r[1]} for r in rows]


# ---------------------------------------------------
# Project Queries
# ---------------------------------------------------

def get_projects_by_oem(conn, oem_name: str) -> List[Dict]:
    cur = conn.cursor()
    cur.execute("""
        SELECT p.project_key, p.project_name
        FROM projects p
        JOIN oems o ON p.oem_id = o.id
        WHERE o.name = %s
        ORDER BY p.project_key;
    """, (oem_name.upper(),))
    rows = cur.fetchall()
    cur.close()

    return [{"project_key": r[0], "project_name": r[1]} for r in rows]


def find_project_by_key(conn, project_key: str) -> Optional[Dict]:
    cur = conn.cursor()
    cur.execute("""
        SELECT project_key, project_name
        FROM projects
        WHERE project_key = %s;
    """, (project_key,))
    row = cur.fetchone()
    cur.close()

    if not row:
        return None

    return {"project_key": row[0], "project_name": row[1]}


def find_project_by_name_fuzzy(conn, name_fragment: str) -> List[Dict]:
    cur = conn.cursor()
    cur.execute("""
        SELECT project_key, project_name
        FROM projects
        WHERE project_name ILIKE %s
        ORDER BY project_name;
    """, (f"%{name_fragment}%",))
    rows = cur.fetchall()
    cur.close()

    return [{"project_key": r[0], "project_name": r[1]} for r in rows]


# ---------------------------------------------------
# Process Queries
# ---------------------------------------------------

def get_processes(conn, project_key: str) -> List[Dict]:
    cur = conn.cursor()
    cur.execute("""
        SELECT pr.process_name, pr.schedule
        FROM processes pr
        JOIN projects p ON pr.project_id = p.id
        WHERE p.project_key = %s
        ORDER BY pr.process_name;
    """, (project_key,))
    rows = cur.fetchall()
    cur.close()

    return [
        {"process_name": r[0], "schedule": r[1]}
        for r in rows
    ]


def get_schedule(conn, project_key: str, process_name: str) -> Optional[str]:
    cur = conn.cursor()
    cur.execute("""
        SELECT pr.schedule
        FROM processes pr
        JOIN projects p ON pr.project_id = p.id
        WHERE p.project_key = %s
        AND pr.process_name = %s;
    """, (project_key, process_name))

    row = cur.fetchone()
    cur.close()

    return row[0] if row else None


# ---------------------------------------------------
# Config Key Lookup
# ---------------------------------------------------

def get_config_value(conn, project_key: str, process_name: str, config_key: str) -> Optional[str]:
    cur = conn.cursor()
    cur.execute("""
        SELECT ce.config_value
        FROM config_entries ce
        JOIN processes pr ON ce.process_id = pr.id
        JOIN projects p ON pr.project_id = p.id
        WHERE p.project_key = %s
        AND pr.process_name = %s
        AND ce.config_key = %s;
    """, (project_key, process_name, config_key))

    row = cur.fetchone()
    cur.close()

    return row[0] if row else None


# ---------------------------------------------------
# Mapping Queries (Single-hop)
# ---------------------------------------------------

def get_field_mappings(
    conn,
    field_name: str,
    oem_name: Optional[str] = None,
    project_key: Optional[str] = None
) -> List[Dict]:

    cur = conn.cursor()

    query = """
        SELECT
            p.project_key,
            pr.process_name,
            am.source_field,
            am.destination_field,
            ms.scenario_name
        FROM attribute_mappings am
        JOIN mapping_scenarios ms ON am.scenario_id = ms.id
        JOIN processes pr ON ms.process_id = pr.id
        JOIN projects p ON pr.project_id = p.id
        JOIN oems o ON p.oem_id = o.id
        WHERE (am.source_field = %s OR am.destination_field = %s)
    """

    params = [field_name, field_name]

    if oem_name:
        query += " AND o.name = %s"
        params.append(oem_name.upper())

    if project_key:
        query += " AND p.project_key = %s"
        params.append(project_key)

    query += " ORDER BY p.project_key, pr.process_name;"

    cur.execute(query, tuple(params))
    rows = cur.fetchall()
    cur.close()

    return [
        {
            "project_key": r[0],
            "process_name": r[1],
            "source_field": r[2],
            "destination_field": r[3],
            "scenario_name": r[4]
        }
        for r in rows
    ]


# ---------------------------------------------------
# Multi-hop Traversal (Recursive CTE)
# ---------------------------------------------------

def get_multi_hop_mappings(
    conn,
    field_name: str,
    oem_name: Optional[str] = None,
    project_key: Optional[str] = None
) -> List[Dict]:

    cur = conn.cursor()

    base_query = """
        WITH RECURSIVE traversal AS (
            SELECT
                am.source_field,
                am.destination_field,
                p.project_key,
                pr.process_name
            FROM attribute_mappings am
            JOIN mapping_scenarios ms ON am.scenario_id = ms.id
            JOIN processes pr ON ms.process_id = pr.id
            JOIN projects p ON pr.project_id = p.id
            JOIN oems o ON p.oem_id = o.id
            WHERE am.source_field = %s
    """

    params = [field_name]

    if oem_name:
        base_query += " AND o.name = %s"
        params.append(oem_name.upper())

    if project_key:
        base_query += " AND p.project_key = %s"
        params.append(project_key)

    base_query += """
            UNION
            SELECT
                am.source_field,
                am.destination_field,
                p.project_key,
                pr.process_name
            FROM attribute_mappings am
            JOIN mapping_scenarios ms ON am.scenario_id = ms.id
            JOIN processes pr ON ms.process_id = pr.id
            JOIN projects p ON pr.project_id = p.id
            JOIN oems o ON p.oem_id = o.id
            JOIN traversal t
                ON am.source_field = t.destination_field
        )
        SELECT * FROM traversal
        ORDER BY project_key, process_name;
    """

    cur.execute(base_query, tuple(params))
    rows = cur.fetchall()
    cur.close()

    return [
        {
            "source_field": r[0],
            "destination_field": r[1],
            "project_key": r[2],
            "process_name": r[3],
        }
        for r in rows
    ]

def get_config_keys(conn, project_key: str, process_name: str):
    cur = conn.cursor()
    cur.execute("""
        SELECT ce.config_key
        FROM config_entries ce
        JOIN processes pr ON ce.process_id = pr.id
        JOIN projects p ON pr.project_id = p.id
        WHERE p.project_key = %s
        AND pr.process_name = %s;
    """, (project_key, process_name))

    rows = cur.fetchall()
    cur.close()

    return [r[0] for r in rows]


def get_all_mapping_fields(conn, oem_name=None, project_key=None):

    query = """
        SELECT DISTINCT am.source_field, am.destination_field
        FROM attribute_mappings am
        JOIN mapping_scenarios ms ON am.scenario_id = ms.id
        JOIN processes pr ON ms.process_id = pr.id
        JOIN projects p ON pr.project_id = p.id
        JOIN oems o ON p.oem_id = o.id
        WHERE 1=1
    """

    params = []

    if oem_name:
        query += " AND o.name = %s"
        params.append(oem_name.upper())

    if project_key:
        query += " AND p.project_key = %s"
        params.append(project_key)

    cur = conn.cursor()
    cur.execute(query, tuple(params))
    rows = cur.fetchall()
    cur.close()

    fields = set()
    for r in rows:
        fields.add(r[0])
        fields.add(r[1])

    return list(fields)

def get_oem_by_project(conn, project_key: str):
    cur = conn.cursor()
    cur.execute("""
        SELECT o.name
        FROM projects p
        JOIN oems o ON p.oem_id = o.id
        WHERE p.project_key = %s;
    """, (project_key,))
    row = cur.fetchone()
    cur.close()
    return row[0] if row else None

def get_all_projects(conn):
    cur = conn.cursor()
    cur.execute("""
        SELECT project_key, project_name
        FROM projects;
    """)
    rows = cur.fetchall()
    cur.close()

    return [
        {"project_key": r[0], "project_name": r[1]}
        for r in rows
    ]

def get_all_attribute_mappings(conn, project_key: str, process_name: str = None):

    query = """
        SELECT 
            ms.scenario_name,
            am.source_field,
            am.destination_field,
            COUNT(vm.id) as value_count
        FROM attribute_mappings am
        JOIN mapping_scenarios ms ON am.scenario_id = ms.id
        JOIN processes pr ON ms.process_id = pr.id
        JOIN projects p ON pr.project_id = p.id
        LEFT JOIN value_mappings vm 
               ON vm.attribute_mapping_id = am.id
        WHERE p.project_key = %s
    """

    params = [project_key]

    if process_name:
        query += " AND pr.process_name = %s"
        params.append(process_name)

    query += """
        GROUP BY ms.scenario_name, am.source_field, am.destination_field
        ORDER BY ms.scenario_name;
    """

    cur = conn.cursor()
    cur.execute(query, tuple(params))
    rows = cur.fetchall()
    cur.close()

    return [
        {
            "scenario_name": r[0],
            "source_field": r[1],
            "destination_field": r[2],
            "value_mapping_count": r[3]
        }
        for r in rows
    ]



def get_value_mappings_for_field(
    conn,
    project_key: str,
    field_name: str,
    process_name: str = None,
    limit: int = 100,
    offset: int = 0
):

    query = """
        SELECT 
            ms.scenario_name,
            am.source_field,
            am.destination_field,
            vm.source_value,
            vm.destination_value
        FROM value_mappings vm
        JOIN attribute_mappings am ON vm.attribute_mapping_id = am.id
        JOIN mapping_scenarios ms ON am.scenario_id = ms.id
        JOIN processes pr ON ms.process_id = pr.id
        JOIN projects p ON pr.project_id = p.id
        WHERE p.project_key = %s
        AND am.source_field = %s
    """

    params = [project_key, field_name]

    if process_name:
        query += " AND pr.process_name = %s"
        params.append(process_name)

    query += """
        ORDER BY ms.scenario_name
        LIMIT %s OFFSET %s
    """

    params.extend([limit, offset])

    cur = conn.cursor()
    cur.execute(query, tuple(params))
    rows = cur.fetchall()
    cur.close()

    return [
        {
            "scenario_name": r[0],
            "source_field": r[1],
            "destination_field": r[2],
            "source_value": r[3],
            "destination_value": r[4]
        }
        for r in rows
    ]


def count_value_mappings_for_field(
    conn,
    project_key: str,
    field_name: str,
    process_name: str = None
):

    query = """
        SELECT COUNT(*)
        FROM value_mappings vm
        JOIN attribute_mappings am ON vm.attribute_mapping_id = am.id
        JOIN mapping_scenarios ms ON am.scenario_id = ms.id
        JOIN processes pr ON ms.process_id = pr.id
        JOIN projects p ON pr.project_id = p.id
        WHERE p.project_key = %s
        AND am.source_field = %s
    """

    params = [project_key, field_name]

    if process_name:
        query += " AND pr.process_name = %s"
        params.append(process_name)

    cur = conn.cursor()
    cur.execute(query, tuple(params))
    count = cur.fetchone()[0]
    cur.close()

    return count

def get_full_config(conn, project_key: str, process_name: str):

    cur = conn.cursor()

    cur.execute("""
        SELECT ce.config_key, ce.config_value
        FROM config_entries ce
        JOIN processes p ON ce.process_id = p.id
        JOIN projects pr ON p.project_id = pr.id
        WHERE pr.project_key = %s
          AND p.process_name = %s
    """, (project_key, process_name))

    rows = cur.fetchall()
    cur.close()

    if not rows:
        return None

    config_dict = {}
    for key, value in rows:
        config_dict[key] = value

    return config_dict


