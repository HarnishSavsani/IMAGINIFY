# 📘 Detailed Project Information

## 🎯 Purpose

This repository contains AIDA, an AI-powered assistant for exchange operations. The application lets users ask natural-language questions about exchange schedules, configuration, mappings, defect history, failures, and process triggering.

## 🧱 Architecture Summary

- 🧠 Backend: FastAPI
- 💬 Frontend: Chainlit
- 🗄️ Databases: PostgreSQL and Oracle
- 🔄 Workflow: chat → intent detection → context resolution → data retrieval → response rendering

## 🧩 Core Backend Responsibilities

- Route incoming requests
- Classify intent
- Resolve ambiguity
- Manage session state
- Retrieve configuration and mappings
- Query exchange history and failures
- Trigger and monitor processes

## 🧩 Core Frontend Responsibilities

- Provide a chat-like experience
- Send requests to the backend
- Render responses clearly
- Show clarification actions
- Support starter prompts and process actions

## 📂 Folder-by-Folder Notes

### 📁 backend/app

This is the main Python package for the backend.

- [backend/app/main.py](backend/app/main.py): API entrypoint and route definitions
- [backend/app/router](backend/app/router): intent and context handling
- [backend/app/services](backend/app/services): business logic for config and mappings
- [backend/app/session](backend/app/session): session and conversation state
- [backend/app/exchange_history](backend/app/exchange_history): defect and failure history logic
- [backend/app/exchange_trigger](backend/app/exchange_trigger): process triggering and websocket progress tracking
- [backend/app/db](backend/app/db): database connections
- [backend/app/utils](backend/app/utils): helper utilities

### 📁 frontend

This folder contains the user-facing chat experience.

- [frontend/chainlit_app.py](frontend/chainlit_app.py): main chat application
- [frontend/ui_renderer.py](frontend/ui_renderer.py): response rendering helpers
- [frontend/backend_client.py](frontend/backend_client.py): backend client helper
- [frontend/public/elements/TriggerForm.jsx](frontend/public/elements/TriggerForm.jsx): UI element for triggering jobs

### 📁 data/programs

This folder stores JSON program definitions used by the application.

## 🔑 Main Functions by File

- [backend/app/main.py](backend/app/main.py): FastAPI app and routes
- [backend/app/router/query_router.py](backend/app/router/query_router.py): main query orchestration flow
- [backend/app/router/context_resolver.py](backend/app/router/context_resolver.py): context inference and ambiguity detection
- [backend/app/router/intent_classifier.py](backend/app/router/intent_classifier.py): intent mapping from text
- [backend/app/services/config_service.py](backend/app/services/config_service.py): config, mapping, schedule logic
- [backend/app/session/session_service.py](backend/app/session/session_service.py): session context persistence
- [backend/app/exchange_history/service.py](backend/app/exchange_history/service.py): history and failure queries
- [backend/app/exchange_trigger/trigger_service.py](backend/app/exchange_trigger/trigger_service.py): trigger and monitor external jobs
- [backend/app/exchange_trigger/process_service.py](backend/app/exchange_trigger/process_service.py): background process orchestration
- [backend/app/exchange_trigger/connection_manager.py](backend/app/exchange_trigger/connection_manager.py): websocket broadcast manager
- [frontend/chainlit_app.py](frontend/chainlit_app.py): main chat application handlers
- [frontend/ui_renderer.py](frontend/ui_renderer.py): UI response formatting

## 🚨 Current Caveats

- 🔐 Some credentials and URLs are placeholders
- 🌐 Port alignment between frontend and backend should be verified
- 🗄️ Database connectivity is required for most features
- 🔁 Triggering depends on external systems

## ✅ Recommended Reading Order

1. [backend/app/main.py](backend/app/main.py)
2. [backend/app/router/query_router.py](backend/app/router/query_router.py)
3. [backend/app/services/config_service.py](backend/app/services/config_service.py)
4. [frontend/chainlit_app.py](frontend/chainlit_app.py)
5. [frontend/ui_renderer.py](frontend/ui_renderer.py)
