import requests

url = "http://chiprx022.vistcorp.ad.visteon.com:9000/api/views/searchjobs/3f37fbcb-2ec6-41ac-8ae1-a7c947f7ed51/6adeedad8470567f13e1ab74/status"

r = requests.get(
    url,
    auth=("admin", "Gr@ylog123")
)

data = r.json()

pivot = data["results"]["9090a1f0-72c6-4a44-aa7f-543e26ece63b"][
    "search_types"
]["ada976e7-04f2-4aac-80ee-8ed9d5ef8a41"]

for row in pivot["rows"]:
    if not row["key"]:
        continue

    feature = row["key"][0]

    values = {
        item["key"][0]: item["value"]
        for item in row["values"]
    }

    print({
        "feature": feature,
        "average": values.get("Average"),
        "peak": values.get("Peak usage"),
        "license": values.get("Total License")
    })