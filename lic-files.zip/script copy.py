import uuid
from datetime import datetime

import pandas as pd
import requests
import urllib3

urllib3.disable_warnings(
    urllib3.exceptions.InsecureRequestWarning
)


class GraylogClient:

    def __init__(self, base_url, username, password):
        self.base_url = base_url.rstrip("/")
        self.auth = (username, password)

    def execute_pivot(
        self,
        query,
        stream_id,
        group_by,
        metrics,
        days=30,
        limit=100
    ):

        payload = {
            "queries": [
                {
                    "id": str(uuid.uuid4()),
                    "timerange": {
                        "type": "relative",
                        "from": days * 24 * 60 * 60
                    },
                    "query": {
                        "type": "elasticsearch",
                        "query_string": query
                    },
                    "search_types": [
                        {
                            "id": str(uuid.uuid4()),
                            "name": "chart",
                            "type": "pivot",
                            "rollup": True,
                            "streams": [stream_id],
                            "row_groups": [
                                {
                                    "type": "values",
                                    "fields": group_by,
                                    "limit": limit,
                                    "skip_empty_values": True
                                }
                            ],
                            "column_groups": [],
                            "series": metrics,
                            "sort": []
                        }
                    ]
                }
            ]
        }

        response = requests.post(
            f"{self.base_url}/api/views/search/sync",
            json=payload,
            auth=self.auth,
            verify=False,
            headers={
                "Accept": "application/json",
                "X-Requested-By": "python"
            }
        )

        response.raise_for_status()

        return self._parse_response(response.json())

    def _parse_response(self, response_json):

        result = next(iter(response_json["results"].values()))

        search_type = next(
            iter(result["search_types"].values())
        )

        rows = []

        for row in search_type["rows"]:

            if not row["key"]:
                continue

            record = {
                "Feature": row["key"][0]
            }

            for value in row["values"]:
                record[value["key"][0]] = value["value"]

            rows.append(record)

        return rows


def convert_timestamp(epoch_ms):

    if epoch_ms is None:
        return ""

    return datetime.fromtimestamp(
        epoch_ms / 1000
    ).strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]


def print_table(title, rows):

    if not rows:
        print(f"\n{title}")
        print("No Data")
        return

    cleaned = []

    for row in rows:

        r = row.copy()

        for k, v in r.items():

            if (
                isinstance(v, (int, float))
                and "Used" in k
                and v > 1000000000000
            ):
                r[k] = convert_timestamp(v)

        cleaned.append(r)

    df = pd.DataFrame(cleaned)

    print("\n")
    print("=" * 80)
    print(title)
    print("=" * 80)
    print(df.to_string(index=False))


# ------------------------------------------------------------------
# CONFIG
# ------------------------------------------------------------------

GRAYLOG_URL = "http://chiprx022.vistcorp.ad.visteon.com:9000"

USERNAME = "admin"
PASSWORD = "Gr@ylog123"

client = GraylogClient(
    GRAYLOG_URL,
    USERNAME,
    PASSWORD
)

# ------------------------------------------------------------------
# WIDGET 1 - Peak Usage
# ------------------------------------------------------------------

peak_usage = client.execute_pivot(
    query='filebeat_fields_lic_type:"catia" AND filebeat_feature:("HD2" OR "ST1")',

    stream_id="6a1d6baf2f35ae99a4a2991d",

    group_by=["filebeat_feature"],

    metrics=[
        {
            "type": "avg",
            "id": "Average",
            "field": "filebeat_in_use"
        },
        {
            "type": "max",
            "id": "Peak Usage",
            "field": "filebeat_in_use"
        },
        {
            "type": "max",
            "id": "Total License",
            "field": "filebeat_total_issued"
        }
    ],

    days=30
)

# ------------------------------------------------------------------
# WIDGET 2 - Active Users
# ------------------------------------------------------------------

active_users = client.execute_pivot(
    query='feature:("HD2" OR "ST1")',

    stream_id="6a2294ddf89e97321b715ad5",

    group_by=["feature"],

    metrics=[
        {
            "type": "card",
            "id": "Count",
            "field": "user"
        }
    ],

    days=30
)

# ------------------------------------------------------------------
# WIDGET 3 - Last Used
# ------------------------------------------------------------------

last_used = client.execute_pivot(
    query='_exists_:filebeat_in_use AND filebeat_feature:("HD2" OR "ST1")',

    stream_id="6a1d6baf2f35ae99a4a2991d",

    group_by=["filebeat_feature"],

    metrics=[
        {
            "type": "max",
            "id": "Last Used",
            "field": "timestamp"
        }
    ],

    days=30
)

# ------------------------------------------------------------------
# DISPLAY
# ------------------------------------------------------------------

print_table("KEY KPI PEAK USAGE", peak_usage)

print_table("UNIQUE ACTIVE USERS", active_users)

print_table("KEY KPI LAST USED", last_used)