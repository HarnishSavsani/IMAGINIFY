import json
import redis

def check_redis_counts():
    print("Connecting to local Redis instance...")
    
    try:
        client = redis.Redis(host='localhost', port=6379, decode_responses=True)
        keys = client.keys("license:live:*")
        
        if not keys:
            print("No 'license:live:*' keys found in Redis.")
            print("Ensure your main.py script is running and pushing data.")
            return

        print(f"Found {len(keys)} feature keys in Redis. Validating counts silently...\n")
        
        mismatches_list = []
        perfect_matches = 0
        
        for key in keys:
            raw_data = client.get(key)
            if not raw_data: continue
                
            data = json.loads(raw_data)
            group = data.get("group", "Unknown")
            feature = data.get("feature", "Unknown")
            in_use = data.get("in_use", 0)
            users_array = data.get("users", [])
            
            # Calculate true total by summing the 'licenses_used'
            extracted_user_count = sum(u.get("licenses_used", 1) for u in users_array)
            
            if in_use == extracted_user_count:
                perfect_matches += 1
            else:
                mismatches_list.append({
                    "group": group,
                    "feature": feature,
                    "in_use": in_use,
                    "extracted": extracted_user_count
                })
                
        print(f"Validation Complete: {perfect_matches} Perfect Matches, {len(mismatches_list)} Mismatches.")
        
        # Print the consolidated mismatch table at the bottom
        if mismatches_list:
            print("\n" + "=" * 75)
            print("❌ MISMATCHES SUMMARY")
            print("=" * 75)
            print(f"{'GROUP':<20} | {'FEATURE':<30} | {'IN_USE':<7} | {'USERS':<7}")
            print("-" * 75)
            
            for m in mismatches_list:
                # Truncate strings gracefully to keep table aligned
                grp_str = m['group'][:18]
                feat_str = m['feature'][:28]
                print(f"{grp_str:<20} | {feat_str:<30} | {m['in_use']:<7} | {m['extracted']:<7}")
                
            print("=" * 75)
            print("\nWARNING: Investigate the raw command outputs to adjust the parser.")
            
    except redis.ConnectionError:
        print("CRITICAL ERROR: Could not connect to Redis. Is the Redis server running?")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

if __name__ == "__main__":
    check_redis_counts()