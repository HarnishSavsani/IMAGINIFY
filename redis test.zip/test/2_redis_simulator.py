import redis
import json
import time
import glob
import os
from loguru import logger

# Connect to the Redis instance your NodeJS/React frontend is looking at
r = redis.Redis(host='localhost', port=6379, decode_responses=True)

def push_state_to_redis(file_path):
    """Reads a JSON state file and pushes it to Redis with a 120s TTL."""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
            
        for key, payload in data.items():
            # We push with a 120-second TTL, exactly like executor.py!
            r.setex(key, 120, json.dumps(payload))
            
        logger.info(f"✅ Pushed {len(data)} keys to Redis from {os.path.basename(file_path)}")
    except Exception as e:
        logger.error(f"❌ Failed to push {file_path}: {e}")

def run_simulator():
    # Find all 5 state files in the folder and sort them numerically
    files = sorted(glob.glob("mock_data/state_*.json"))
    
    if not files:
        logger.error("❌ No JSON files found in 'mock_data/' directory!")
        return

    logger.info(f"🚀 Starting Simulator! Found {len(files)} states. Pushing every 60 seconds...")

    # Infinite Loop (Loops exactly like your while True in main.py)
    state_index = 0
    while True:
        # Get current file
        current_file = files[state_index]
        
        # Push to Redis
        push_state_to_redis(current_file)
        
        # Move to the next state (Loop back to 0 if we hit the end of the 5 files)
        state_index = (state_index + 1) % len(files)
        
        # Wait 60 seconds before pushing the next state
        time.sleep(60)

if __name__ == "__main__":
    run_simulator()