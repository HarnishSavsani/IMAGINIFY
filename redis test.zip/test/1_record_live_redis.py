import redis
import json
import os
import time
from datetime import datetime

# Connect to your actual Production Redis
# (Add password="YourPassword" here if you enabled it in your redis.conf!)
r = redis.Redis(host='localhost', port=6379, decode_responses=True)

def record_real_data():
    folder_name = "real_data_snapshots"
    os.makedirs(folder_name, exist_ok=True)
    
    print(f"🎥 Started recording real Redis data. Taking a snapshot every 5 minutes...")
    
    snapshot_count = 1
    while True:
        keys = r.keys('license:live:*')
        
        if not keys:
            print("⚠️ No live licenses found in Redis at the moment.")
        else:
            snapshot_data = {}
            for k in keys:
                # Fetch the exact, unaltered real data
                snapshot_data[k] = json.loads(r.get(k))
                
            # Create a timestamped filename
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            file_name = f"{folder_name}/snapshot_{snapshot_count:03d}_{timestamp}.json"
            
            with open(file_name, 'w', encoding='utf-8') as f:
                json.dump(snapshot_data, f, indent=2)
                
            print(f"✅ [{datetime.now().strftime('%H:%M:%S')}] Saved real data to: {file_name}")
            snapshot_count += 1
            
        # Wait exactly 5 minutes (300 seconds) before taking the next snapshot
        time.sleep(300)

if __name__ == "__main__":
    try:
        record_real_data()
    except KeyboardInterrupt:
        print("\n🛑 Recording stopped by user.")