import os
import json
import uuid
from flask import Flask, request, jsonify, Response
from flask_cors import CORS
from groq import Groq
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
# Enable CORS for the frontend origin
CORS(app, resources={r"/api/*": {"origins": "*"}}) 

# Initialize Groq client
client = Groq(api_key=os.getenv("GROQ_API_KEY"))

DB_FILE = "chats.json"

def load_db():
    if os.path.exists(DB_FILE):
        with open(DB_FILE, "r") as f:
            return json.load(f)
    return {"users": [{"id": "user1", "name": "Default User"}], "chats": {}}

def save_db(data):
    with open(DB_FILE, "w") as f:
        json.dump(data, f, indent=2)

@app.route("/api/users", methods=["GET"])
def get_users():
    db = load_db()
    return jsonify(db["users"])

@app.route("/api/users", methods=["POST"])
def create_user():
    data = request.json
    name = data.get("name", "New User")
    db = load_db()
    user_id = str(uuid.uuid4())
    db["users"].append({"id": user_id, "name": name})
    save_db(db)
    return jsonify({"id": user_id, "name": name})

@app.route("/api/chats/<user_id>", methods=["GET"])
def get_chats(user_id):
    db = load_db()
    user_chats = []
    for chat_id, chat in db["chats"].items():
        if chat.get("user_id") == user_id:
            user_chats.append({
                "id": chat_id,
                "title": chat.get("title", "New Chat"),
                "updated_at": chat.get("updated_at", "")
            })
    return jsonify(user_chats)

@app.route("/api/chats", methods=["POST"])
def create_chat():
    data = request.json
    user_id = data.get("user_id")
    if not user_id:
        return jsonify({"error": "user_id required"}), 400
        
    db = load_db()
    chat_id = str(uuid.uuid4())
    db["chats"][chat_id] = {
        "user_id": user_id,
        "title": "New Chat",
        "messages": [],
        "updated_at": "now"
    }
    save_db(db)
    return jsonify({"id": chat_id, "title": "New Chat", "messages": []})

@app.route("/api/chats/<chat_id>", methods=["GET"])
def get_chat(chat_id):
    db = load_db()
    chat = db["chats"].get(chat_id)
    if not chat:
        return jsonify({"error": "Not found"}), 404
    return jsonify(chat)

@app.route("/api/chat", methods=["POST"])
def chat():
    try:
        data = request.json
        if not data:
            return jsonify({"error": "Invalid request. No JSON payload found."}), 400
        
        chat_id = data.get("chat_id")
        user_message = data.get("message")
        model = data.get("model", "llama-3.3-70b-versatile")
        
        if not user_message or not chat_id:
            return jsonify({"error": "message and chat_id are required."}), 400

        db = load_db()
        chat_data = db["chats"].get(chat_id)
        if not chat_data:
            return jsonify({"error": "Chat not found."}), 404
            
        # Append user message
        chat_data["messages"].append(user_message)
        
        # update title if it's the first message
        if len(chat_data["messages"]) == 1:
            chat_data["title"] = user_message["content"][:30] + "..."

        # Insert our custom System Prompt so Grox knows how to use the UI components
        system_prompt = {
            "role": "system",
            "content": (
                "You are Grox, a highly intelligent AI assistant in an AI Studio layout. "
                "CRITICAL INSTRUCTION: If the user EVER asks about a location, asks 'where is X', asks to 'show a map', or discusses maps in any way, "
                "you MUST output a map markdown block containing information about the location. "
                "Format it EXACTLY like this, with NO OTHER CODE BLOCKS used for the map data:\n"
                "```map\n"
                "[Insert basic ASCII representation or map logic descriptions here]\n"
                "```\n"
                "Also, if the user asks for any images or pictures, simply return standard markdown image tags like `![description](https://image.pollinations.ai/prompt/description)`, and the frontend will automatically convert them into beautiful image cards."
            )
        }
        messages_to_send = [system_prompt] + chat_data["messages"]

        # Optional: enable streaming
        stream = data.get("stream", True)
        
        if stream:
            chat_completion = client.chat.completions.create(
                messages=messages_to_send,
                model=model,
                stream=True
            )
            
            def generate():
                full_response = ""
                for chunk in chat_completion:
                    if chunk.choices[0].delta.content is not None:
                        content = chunk.choices[0].delta.content
                        full_response += content
                        # Yield in SSE format
                        yield f"data: {json.dumps({'content': content})}\n\n"
                
                # Save assistant message after stream completes
                db = load_db()
                db["chats"][chat_id]["messages"].append({"role": "assistant", "content": full_response})
                save_db(db)
                        
            return Response(generate(), mimetype='text/event-stream')
            
        else:
            chat_completion = client.chat.completions.create(
                messages=messages_to_send,
                model=model,
                stream=False
            )
            assistant_content = chat_completion.choices[0].message.content
            chat_data["messages"].append({"role": "assistant", "content": assistant_content})
            save_db(db)
            return jsonify({
                "content": assistant_content
            })
            
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(port=5001, debug=True)
