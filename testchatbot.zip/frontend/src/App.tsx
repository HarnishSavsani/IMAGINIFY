import { useState, useRef, useEffect } from 'react';
import { Send, User as UserIcon, Sparkles, Mic, Plus, Square, RefreshCw, Maximize2, TerminalSquare, LayoutTemplate, MapPin, MessageSquare, ChevronDown, Check, Menu, PanelRightClose, PanelRightOpen } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

// Models taken from the provided screenshots
const MODELS = [
  { id: 'llama-3.3-70b-versatile', name: 'Llama 3.3 70B' },
  { id: 'qwen/qwen3-32b', name: 'Qwen 3 32B' },
  { id: 'openai/gpt-oss-120b', name: 'GPT OSS 120B' },
  { id: 'llama-3.1-8b-instant', name: 'Llama 3.1 8B' },
  { id: 'canopylabs/orpheus-v1-english', name: 'Orpheus V1' },
];

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

interface ChatSession {
  id: string;
  title: string;
  updated_at: string;
  messages?: Message[];
}

interface UserProfile {
  id: string;
  name: string;
}

// Custom Grox Icon matches AI Studio style triangles
const GroxIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M12 2L2 22H22L12 2Z" fill="white"/>
  </svg>
);

const AIStudioIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" className="text-blue-500">
     <path d="M12 2L15 9L22 12L15 15L12 22L9 15L2 12L9 9L12 2Z" />
  </svg>
);

const API_BASE = "http://localhost:5001/api";

function App() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [selectedModel, setSelectedModel] = useState(MODELS[0].id);
  const [isLoading, setIsLoading] = useState(false);
  
  // Canvas State: Default closed. Open only when Map is triggered or forced
  const [isCanvasOpen, setIsCanvasOpen] = useState(false);
  const [activeCanvas, setActiveCanvas] = useState<'preview' | 'code' | 'map' | null>(null);
  const [canvasContent, setCanvasContent] = useState<string>('');
  
  // Users & Chat History State
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [chats, setChats] = useState<ChatSession[]>([]);
  const [currentChatId, setCurrentChatId] = useState<string | null>(null);

  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Initial load users
  useEffect(() => {
    fetch(`${API_BASE}/users`)
      .then(r => r.json())
      .then(data => {
        setUsers(data);
        if (data.length > 0) {
          setCurrentUser(data[0]);
        }
      })
      .catch(err => console.error("Failed to load users", err));
  }, []);

  // Load chats when user changes
  useEffect(() => {
    if (currentUser) {
      loadChats(currentUser.id);
    }
  }, [currentUser]);

  const loadChats = async (userId: string) => {
    try {
      const r = await fetch(`${API_BASE}/chats/${userId}`);
      const data = await r.json();
      setChats(data);
      if (data.length > 0) {
         loadSingleChat(data[0].id);
      } else {
         createNewChat(userId);
      }
    } catch (e) { console.error(e); }
  };

  const createNewChat = async (userId: string) => {
    try {
      const r = await fetch(`${API_BASE}/chats`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user_id: userId })
      });
      const newChat = await r.json();
      setChats(prev => [newChat, ...prev]);
      setCurrentChatId(newChat.id);
      setMessages([]);
      setIsCanvasOpen(false);
      setActiveCanvas(null);
    } catch (e) { console.error(e); }
  };

  const loadSingleChat = async (chatId: string) => {
    try {
      const r = await fetch(`${API_BASE}/chats/${chatId}`);
      if (r.ok) {
        const data = await r.json();
        setCurrentChatId(chatId);
        setMessages(data.messages || []);
        setIsCanvasOpen(false);
      }
    } catch (e) { console.error(e); }
  }

  // Parse latest message for magic canvas triggers (like map)
  useEffect(() => {
    const lastAssistantMessage = messages.slice().reverse().find(m => m.role === 'assistant');
    if (lastAssistantMessage && lastAssistantMessage.content) {
      const content = lastAssistantMessage.content;
      if (content.includes('```map')) {
        setActiveCanvas('map');
        setCanvasContent(content);
        // User requesting a map -> Auto open Canvas!
        setIsCanvasOpen(true);
      }
    }
  }, [messages]);

  const handleInput = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInput(e.target.value);
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 150)}px`;
    }
  };

  const handleSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!input.trim() || isLoading || !currentChatId) return;

    const userMessage: Message = { role: 'user', content: input };
    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    if (textareaRef.current) textareaRef.current.style.height = 'auto';
    setIsLoading(true);

    try {
      setMessages((prev) => [...prev, { role: 'assistant', content: '' }]);

      const response = await fetch(`${API_BASE}/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: currentChatId,
          model: selectedModel,
          message: userMessage,
          stream: true,
        }),
      });

      if (!response.ok) throw new Error('Network error');

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();

      if (reader) {
        let isFirstMessage = messages.length === 0;

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          const chunk = decoder.decode(value);
          const lines = chunk.split('\n');
          
          for (const line of lines) {
            if (line.startsWith('data: ')) {
              try {
                const data = JSON.parse(line.slice(6));
                if (data.content) {
                  setMessages((prev) => {
                    const newMessages = [...prev];
                    const lastIndex = newMessages.length - 1;
                    newMessages[lastIndex] = {
                      ...newMessages[lastIndex],
                      content: newMessages[lastIndex].content + data.content,
                    };
                    return newMessages;
                  });
                }
              } catch (e) {}
            }
          }
        }
        
        // Refresh chat list to update titles if this was the first message
        if (isFirstMessage && currentUser) {
          fetch(`${API_BASE}/chats/${currentUser.id}`)
            .then(r => r.json())
            .then(data => setChats(data));
        }

      }
    } catch (error) {
      setMessages((prev) => [
        ...prev,
        { role: 'assistant', content: 'An error occurred while processing your request.' },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const stopGeneration = () => {
     setIsLoading(false);
  };

  const createUser = async () => {
    const name = prompt("Enter new user name:");
    if (!name) return;
    const r = await fetch(`${API_BASE}/users`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name })
    });
    const newUser = await r.json();
    setUsers([...users, newUser]);
    setCurrentUser(newUser);
    setUserDropdownOpen(false);
  }

  // Custom markdown renderers for specific layout requests
  const MarkdownComponents = {
    // Treat any image exactly as an isolated custom card per user preference: "if i ask fro any images then only show in card formate"
    img({node, ...props}: any) {
      return (
        <div className="custom-card flex flex-col items-center justify-center p-4">
           <img className="max-w-full rounded-lg shadow-sm" {...props} />
           {props.alt && <span className="text-xs text-gray-400 mt-2 font-medium">{props.alt}</span>}
        </div>
      )
    },
    code({node, inline, className, children, ...props}: any) {
      const match = /language-(\w+)/.exec(className || '')
      const language = match ? match[1] : '';
      
      // If code block is specifically marked as `map`, provide a snippet UI and let them open canvas manually
      if (!inline && language === 'map') {
        return (
          <div className="custom-card flex flex-col gap-3">
             <div className="flex items-center gap-2 font-bold text-lg text-gray-800">
               <MapPin className="text-red-500"/> Location Map Request
             </div>
             <p className="text-gray-600 text-sm">Interactive map logic has been generated.</p>
             <button onClick={() => { setActiveCanvas('map'); setIsCanvasOpen(true); }} className="bg-blue-600 text-white rounded px-4 py-2 mt-2 font-medium text-sm hover:bg-blue-700 transition w-max">
               Open Map in Canvas
             </button>
          </div>
        )
      } 
      return !inline ? (
        <pre className={className} {...props}>
          <code className={className} {...props}>
            {children}
          </code>
        </pre>
      ) : (
        <code className={className} {...props}>
          {children}
        </code>
      )
    }
  };

  return (
    <div className="h-screen w-full flex bg-[#1e1f22] text-[#f2f3f5] font-sans overflow-hidden">
      
      {/* HISTORY SIDEBAR (Hidden by default, optional toggle) */}
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div 
            initial={{ width: 0, opacity: 0 }}
            animate={{ width: 260, opacity: 1 }}
            exit={{ width: 0, opacity: 0 }}
            className="flex-shrink-0 bg-[#111214] border-r border-[#3f4147] flex flex-col h-full overflow-hidden"
          >
            {/* User Selector Header */}
            <div className="p-4 border-b border-[#3f4147] relative">
               <button 
                  onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                  className="w-full flex items-center justify-between bg-[#1e1f22] hover:bg-[#2b2d31] border border-[#3f4147] rounded-lg px-3 py-2 text-sm transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <UserIcon size={16} className="text-[#949ba4]" />
                    <span className="truncate max-w-[130px] font-medium text-gray-200">
                      {currentUser?.name || "Loading..."}
                    </span>
                  </div>
                  <ChevronDown size={14} className="text-[#949ba4]" />
               </button>

               {/* Dropdown for users */}
               {userDropdownOpen && (
                 <div className="absolute top-16 left-4 right-4 bg-[#2b2d31] border border-[#3f4147] rounded-lg shadow-xl z-50 py-1">
                    {users.map(u => (
                      <button 
                        key={u.id}
                        onClick={() => { setCurrentUser(u); setUserDropdownOpen(false); }}
                        className="w-full flex items-center justify-between px-3 py-2 text-sm text-left hover:bg-[#3f4147] transition-colors"
                      >
                         <span>{u.name}</span>
                         {currentUser?.id === u.id && <Check size={14} className="text-blue-500" />}
                      </button>
                    ))}
                    <div className="border-t border-[#3f4147] my-1"></div>
                    <button 
                       onClick={createUser} 
                       className="w-full flex items-center gap-2 px-3 py-2 text-sm text-left hover:bg-[#3f4147] text-blue-400 transition-colors"
                    >
                      <Plus size={14} /> Add User
                    </button>
                 </div>
               )}
            </div>

            {/* Chat History List */}
            <div className="flex-1 overflow-y-auto p-2 scroll-smooth">
               <div className="mb-4">
                 <button 
                   onClick={() => currentUser && createNewChat(currentUser.id)}
                   className="w-full flex flex-col p-3 rounded-lg border border-[#3f4147] border-dashed hover:bg-[#1e1f22] transition-colors text-center text-[#949ba4] text-sm font-medium"
                 >
                    <Plus size={16} className="mx-auto mb-1 text-[#f2f3f5]" />
                    New Chat
                 </button>
               </div>
               
               <div className="space-y-1">
                 <div className="px-2 py-1 text-[11px] font-bold text-[#949ba4] uppercase tracking-wider">Recent Chats</div>
                 {chats.map(chat => (
                    <button 
                      key={chat.id}
                      onClick={() => loadSingleChat(chat.id)}
                      className={`w-full text-left px-3 py-2 rounded flex flex-col transition-colors group ${currentChatId === chat.id ? 'bg-[#2b2d31] text-white' : 'hover:bg-[#1e1f22] text-[#949ba4]'}`}
                    >
                       <span className="text-[13px] font-medium truncate w-full flex items-center gap-2">
                         <MessageSquare size={14} className={currentChatId === chat.id ? 'text-blue-500' : 'text-[#949ba4]'} />
                         {chat.title}
                       </span>
                    </button>
                 ))}
               </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* MAIN CHAT AREA */}
      <div className={`flex flex-col flex-1 border-r border-[#3f4147] bg-[#1e1f22] h-full transition-all duration-300 shadow-xl z-20`}>
        
        {/* Chat Header */}
        <header className="flex items-center justify-between p-4 border-b border-[#3f4147] h-14 flex-shrink-0">
          <div className="flex items-center gap-3">
            <button 
               onClick={() => setIsSidebarOpen(!isSidebarOpen)} 
               className="p-1.5 hover:bg-[#2b2d31] rounded-md transition-colors text-[#949ba4] hover:text-white"
            >
              <Menu size={18} />
            </button>
            <div className="flex items-center gap-2">
              <AIStudioIcon />
              <h1 className="font-medium text-[15px] tracking-wide text-gray-200">Grox AI Studio</h1>
            </div>
          </div>
          <div className="flex items-center gap-3">
             <select
              value={selectedModel}
              onChange={(e) => setSelectedModel(e.target.value)}
              className="bg-[#2b2d31] text-xs text-[#949ba4] border border-[#3f4147] rounded outline-none hover:bg-[#3f4147] p-1.5 cursor-pointer max-w-[150px] truncate"
            >
              {MODELS.map(m => (
                <option key={m.id} value={m.id}>{m.name}</option>
              ))}
            </select>

            <button 
              onClick={() => setIsCanvasOpen(!isCanvasOpen)}
              className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-lg transition-colors border ${isCanvasOpen ? 'bg-blue-500/10 text-blue-400 border-blue-500/30' : 'bg-[#2b2d31] text-[#949ba4] border-[#3f4147] hover:bg-[#3f4147] hover:text-white'}`}
            >
               {isCanvasOpen ? <PanelRightClose size={14} /> : <PanelRightOpen size={14} />}
               Canvas
            </button>
          </div>
        </header>

        {/* Chat History & Messages */}
        <main className="flex-1 overflow-y-auto px-4 py-6 scroll-smooth">
          {messages.length === 0 ? (
             <div className="opacity-70 mt-4 px-2 text-sm text-[#949ba4] flex flex-col items-center justify-center h-full text-center">
                <GroxIcon />
                <h2 className="text-xl font-bold mt-4 text-white">How can I assist you?</h2>
                <p className="mt-2 max-w-sm">I use standard markdown for text. If you ask for an image, it will display as a beautiful isolated card. The Canvas mapping module is hidden by default.</p>
             </div>
          ) : (
             <div className="space-y-6 max-w-3xl mx-auto w-full">
              <AnimatePresence initial={false}>
                {messages.map((message, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.2 }}
                    className="flex flex-col w-full"
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-6 h-6 rounded flex items-center justify-center bg-[#2b2d31]">
                        {message.role === 'user' ? (
                          <UserIcon size={14} className="text-[#949ba4]" />
                        ) : (
                          <GroxIcon />
                        )}
                      </div>
                      <span className="font-semibold text-[13px] text-gray-300">
                        {message.role === 'user' ? currentUser?.name || 'User' : 'Grox'}
                      </span>
                    </div>

                    <div className="pl-8 text-[14px] leading-relaxed markdown-body text-gray-300 w-full overflow-x-hidden">
                      {message.role === 'assistant' && message.content === '' ? (
                         <div className="flex items-center gap-2 h-6 text-[#949ba4]">
                           <Sparkles size={14} className="animate-pulse" />
                           <span className="text-xs">Generating...</span>
                         </div>
                      ) : (
                        <ReactMarkdown 
                          remarkPlugins={[remarkGfm]}
                          components={MarkdownComponents}
                        >
                          {message.content || ' '}
                        </ReactMarkdown>
                      )}
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          )}
          <div ref={messagesEndRef} className="h-4" />
        </main>

        {/* Action Prompt Area */}
        <div className="p-4 flex-shrink-0 bg-[#1e1f22] max-w-3xl mx-auto w-full">
           <div className="relative flex flex-col bg-[#2b2d31] border border-[#3f4147] rounded-xl focus-within:border-blue-500/50 shadow-inner overflow-hidden transition-colors">
              <textarea
                ref={textareaRef}
                value={input}
                onChange={handleInput}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSubmit();
                  }
                }}
                placeholder="Message Grox..."
                className="w-full max-h-48 min-h-[50px] bg-transparent text-[#f2f3f5] p-3 resize-none outline-none focus:ring-0 text-[14px] placeholder-[#949ba4]"
                rows={1}
              />
              <div className="flex items-center justify-between p-2">
                 <div className="flex items-center gap-1.5 text-[#949ba4]">
                    <button type="button" className="p-1.5 hover:text-white hover:bg-[#3f4147] rounded-lg transition-colors" title="AI Magic">
                      <Sparkles className="w-4 h-4" />
                    </button>
                    <button type="button" className="p-1.5 hover:text-white hover:bg-[#3f4147] rounded-lg transition-colors" title="Voice Input">
                      <Mic className="w-4 h-4" />
                    </button>
                    <button type="button" className="p-1.5 hover:text-white hover:bg-[#3f4147] rounded-lg transition-colors" title="Attach Context">
                      <Plus className="w-4 h-4" />
                    </button>
                 </div>
                 
                 <div className="flex items-center gap-2">
                   {isLoading ? (
                     <button
                        onClick={stopGeneration}
                        className="p-1.5 text-red-400 hover:bg-red-400/10 rounded-lg transition-colors flex items-center justify-center border border-red-400/30"
                      >
                        <Square className="w-4 h-4" fill="currentColor"/>
                      </button>
                   ) : (
                     <button
                        onClick={handleSubmit}
                        disabled={!input.trim()}
                        className="p-1.5 text-blue-400 hover:bg-blue-400/10 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <Send className="w-4 h-4" />
                      </button>
                   )}
                 </div>
              </div>
           </div>
        </div>
      </div>

      {/* RIGHT SIDEBAR (Canvas Array - COLLAPSIBLE) */}
      <AnimatePresence>
        {isCanvasOpen && (
          <motion.div 
             initial={{ width: 0, opacity: 0 }}
             animate={{ width: "45%", opacity: 1 }}
             exit={{ width: 0, opacity: 0 }}
             className="flex flex-col flex-shrink-0 h-full bg-[#1e1f22] overflow-hidden"
          >
            {/* Canvas Toolbar */}
            <header className="h-14 flex items-center justify-between px-4 border-b border-[#3f4147] min-w-[300px]">
                <div className="flex items-center bg-[#2b2d31] rounded-full p-1 border border-[#3f4147]">
                   <button 
                      onClick={() => setActiveCanvas('preview')} 
                      className={`px-3 py-1 text-xs rounded-full flex items-center gap-2 transition-colors ${activeCanvas !== 'code' ? 'bg-[#3f4147] text-white' : 'text-[#949ba4] hover:text-white'}`}
                    >
                      <span className="w-1.5 h-1.5 bg-green-400 rounded-full"></span> Preview
                   </button>
                   <button 
                      onClick={() => setActiveCanvas('code')}
                      className={`px-3 py-1 text-xs rounded-full transition-colors ${activeCanvas === 'code' ? 'bg-[#3f4147] text-white' : 'text-[#949ba4] hover:text-white'}`}
                    >
                     Code
                   </button>
                </div>

                <div className="flex items-center gap-1 bg-[#2b2d31] rounded-lg border border-[#3f4147] p-1 text-[#949ba4]">
                   <button className="p-1 hover:text-white hover:bg-[#3f4147] rounded transition-colors" title="Toggle Layout">
                      <LayoutTemplate className="w-4 h-4" />
                   </button>
                   <div className="w-[1px] h-4 bg-[#3f4147] mx-1"></div>
                   <button className="p-1 hover:text-white hover:bg-[#3f4147] rounded transition-colors" title="Reload">
                      <RefreshCw className="w-4 h-4" />
                   </button>
                   <button onClick={() => setIsCanvasOpen(false)} className="p-1 hover:text-red-400 hover:bg-red-400/10 rounded transition-colors" title="Close Canvas">
                      <PanelRightClose className="w-4 h-4" />
                   </button>
                </div>
            </header>

            {/* Canvas Body */}
            <main className="flex-1 overflow-hidden p-3 relative min-w-[300px]">
               <div className="w-full h-full bg-[#f9fafb] rounded-xl shadow-2xl border border-gray-300 overflow-y-auto text-gray-800 relative">
                  
                  {!activeCanvas ? (
                    <div className="flex flex-col items-center justify-center h-full text-center p-8 opacity-60">
                       <TerminalSquare className="w-16 h-16 text-blue-500 mb-4 opacity-50 stroke-1" />
                       <h2 className="text-xl font-semibold mb-2 text-gray-800">No active canvas</h2>
                       <p className="text-gray-500 text-sm max-w-sm">Ask Grox to map a location to see the interactive Canvas.</p>
                    </div>
                  ) : activeCanvas === 'map' ? (
                    <div className="p-6">
                       <div className="flex items-center justify-between mb-4">
                          <h2 className="text-xl font-bold flex items-center gap-2">
                            <MapPin className="text-red-500"/> Canvas Map Render
                          </h2>
                          <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded font-medium">Interactive Mode</span>
                       </div>
                       <div className="w-full h-[400px] bg-[#e5e7eb] rounded-xl flex items-center justify-center border border-gray-300 relative overflow-hidden shadow-inner">
                          {/* Fake Map Grid */}
                          <div className="absolute inset-0" style={{ backgroundImage: 'linear-gradient(#cbd5e1 1px, transparent 1px), linear-gradient(90deg, #cbd5e1 1px, transparent 1px)', backgroundSize: '30px 30px', opacity: 0.6 }}></div>
                          <div className="z-10 bg-white/95 p-4 rounded-xl shadow-lg font-medium text-gray-800 border border-gray-200 backdrop-blur-md flex flex-col gap-2 relative ring-4 ring-blue-500/20">
                             <div className="flex items-center gap-2 pb-2 border-b border-gray-100">
                               <MapPin className="text-red-500 w-5 h-5"/> 
                               <span>Location Insight</span>
                             </div>
                             <span className="text-sm font-normal text-gray-500 leading-relaxed max-w-xs block">Map module initialized from the conversation context. Rendered specifically for this session.</span>
                          </div>
                       </div>
                       <div className="mt-6 text-sm text-gray-600 bg-gray-50 p-4 rounded-lg border border-gray-200">
                         <p className="font-semibold text-gray-800 mb-2 font-mono">MAP_OBJECT_DATA::LOG</p>
                         <pre className="whitespace-pre-wrap leading-relaxed text-[13px]">{canvasContent.replace(/```map/g, '').replace(/```/g, '')}</pre>
                       </div>
                    </div>
                  ) : (
                    <div className="p-8 font-mono text-sm">
                       <pre>{canvasContent}</pre>
                    </div>
                  )}

               </div>
            </main>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}

export default App;
